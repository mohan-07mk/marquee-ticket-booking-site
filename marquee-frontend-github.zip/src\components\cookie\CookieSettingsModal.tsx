import { useEffect, useState } from 'react';
import { BarChart3, Check, Cookie, Shield, X } from 'lucide-react';
import { useCookieConsent } from '@/context/CookieContext';

export function CookieSettingsModal() {
  const { isModalOpen, analyticsEnabled, closeSettings, acceptAll, acceptEssential, saveCustom } = useCookieConsent();
  const [analytics, setAnalytics] = useState<boolean>(analyticsEnabled);

  useEffect(() => {
    setAnalytics(analyticsEnabled);
  }, [analyticsEnabled, isModalOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isModalOpen) {
        closeSettings();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isModalOpen, closeSettings]);

  if (!isModalOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-sm transition-opacity animate-in fade-in duration-200"
        onClick={closeSettings}
      />

      {/* Modal Container */}
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="cookie-settings-title"
        className="relative z-10 w-full max-w-xl overflow-hidden rounded-3xl border border-line bg-surface p-6 shadow-2xl shadow-black/90 backdrop-blur-2xl animate-in zoom-in-95 duration-200 sm:p-8"
      >
        <div className="flex items-center justify-between border-b border-line pb-4">
          <div className="flex items-center gap-3">
            <div className="rounded-xl bg-red-500/10 p-2 text-red-500">
              <Cookie className="h-5 w-5" />
            </div>
            <div>
              <h2 id="cookie-settings-title" className="font-display text-xl font-bold text-white">
                Cookie Preferences
              </h2>
              <p className="text-xs text-muted">Manage your privacy and cookie choices for Marquee</p>
            </div>
          </div>

          <button
            type="button"
            onClick={closeSettings}
            className="rounded-full p-2 text-muted transition hover:bg-white/10 hover:text-white"
            aria-label="Close modal"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="mt-6 space-y-5 max-h-[60vh] overflow-y-auto pr-1">
          {/* Category 1: Essential Cookies */}
          <div className="rounded-2xl border border-line bg-white/[0.02] p-4 sm:p-5">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <Shield className="h-5 w-5 text-emerald-400 shrink-0" />
                <h3 className="text-sm font-semibold text-white">Essential Cookies</h3>
              </div>
              <span className="rounded-full bg-emerald-500/10 px-3 py-1 text-xs font-semibold text-emerald-400 border border-emerald-500/20">
                Always Active
              </span>
            </div>
            <p className="mt-2 text-xs leading-relaxed text-muted sm:text-sm">
              Necessary for the website to function properly. These enable core features such as authentication, secure session handling, seat reservation states, and Razorpay checkout integration.
            </p>
          </div>

          {/* Category 2: Analytics Cookies */}
          <div className="rounded-2xl border border-line bg-white/[0.02] p-4 sm:p-5">
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <BarChart3 className="h-5 w-5 text-sky-400 shrink-0" />
                <div>
                  <h3 className="text-sm font-semibold text-white">Analytics Cookies</h3>
                  <p className="text-[11px] text-muted">Optional</p>
                </div>
              </div>

              {/* Toggle Switch */}
              <button
                type="button"
                role="switch"
                aria-checked={analytics}
                onClick={() => setAnalytics(!analytics)}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  analytics ? 'bg-red-600' : 'bg-line'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                    analytics ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
            <p className="mt-2 text-xs leading-relaxed text-muted sm:text-sm">
              Allow us to collect aggregated, anonymous statistics to improve page load times and user experience. No personal data, passwords, or payment details are ever tracked or stored.
            </p>
          </div>
        </div>

        {/* Buttons */}
        <div className="mt-8 flex flex-col-reverse gap-2 border-t border-line pt-5 sm:flex-row sm:items-center sm:justify-end sm:gap-3">
          <button
            type="button"
            onClick={acceptEssential}
            className="rounded-xl border border-line bg-white/5 px-4 py-2.5 text-xs font-medium text-white transition hover:bg-white/10 sm:text-sm"
          >
            Reject Optional
          </button>

          <button
            type="button"
            onClick={() => saveCustom(analytics)}
            className="inline-flex items-center justify-center rounded-xl bg-white/10 px-4 py-2.5 text-xs font-semibold text-white transition hover:bg-white/20 sm:text-sm"
          >
            <Check className="mr-1.5 h-4 w-4 text-emerald-400" />
            Save Preferences
          </button>

          <button
            type="button"
            onClick={acceptAll}
            className="rounded-xl bg-red-600 px-5 py-2.5 text-xs font-semibold text-white shadow-lg shadow-red-600/30 transition hover:bg-red-500 sm:text-sm"
          >
            Accept All
          </button>
        </div>
      </div>
    </div>
  );
}
