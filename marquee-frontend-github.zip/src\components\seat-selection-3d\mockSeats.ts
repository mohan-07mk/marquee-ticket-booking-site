import { buildSeatLayout } from '@/data/seats';
import type { Screen, Show } from '@/types';

/**
 * Local mock data for previewing the auditorium on its own (for example in a
 * story or a scratch route). The real seat page passes the seats it already
 * loads from `api.seats.getLayout`, so nothing here is used in production flow.
 */
export const mockScreen: Screen = {
  id: 'mock-screen',
  theatreId: 'mock-theatre',
  name: 'Screen 1',
  rows: 10,
  seatsPerRow: 14,
  capacity: 140,
  formats: ['2D'],
};

const mockShow: Show = {
  id: 'mock-show',
  movieId: 'mock-movie',
  theatreId: 'mock-theatre',
  screenId: 'mock-screen',
  date: '2030-01-01',
  time: '19:30',
  format: '2D',
  language: 'English',
  price: 200,
  premiumPrice: 300,
  status: 'active',
};

export const mockSeats = buildSeatLayout(mockShow, mockScreen);
