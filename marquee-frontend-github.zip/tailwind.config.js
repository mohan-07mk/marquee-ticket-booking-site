/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        base: '#000000',
        surface: '#141414',
        raised: '#1d1d1d',
        line: '#2b2b2b',
        muted: '#9b9b9b',
        brand: { DEFAULT: '#e11d2e', hover: '#f0303f', dark: '#9f1220' },
        gold: '#f5b942',
      },
      fontFamily: {
        display: ['"Big Shoulders Display"', 'Impact', '"Arial Narrow"', 'sans-serif'],
        sans: ['"DM Sans"', 'system-ui', '-apple-system', 'Segoe UI', 'sans-serif'],
      },
      keyframes: {
        'fade-in': { from: { opacity: '0' }, to: { opacity: '1' } },
        'pop-in': {
          from: { opacity: '0', transform: 'translateY(8px) scale(.98)' },
          to: { opacity: '1', transform: 'translateY(0) scale(1)' },
        },
        'toast-in': {
          from: { opacity: '0', transform: 'translateX(24px)' },
          to: { opacity: '1', transform: 'translateX(0)' },
        },
        shimmer: { '100%': { transform: 'translateX(100%)' } },
        'draw-check': { to: { strokeDashoffset: '0' } },
        'ring-pulse': {
          '0%': { transform: 'scale(.9)', opacity: '.7' },
          '100%': { transform: 'scale(1.5)', opacity: '0' },
        },
      },
      animation: {
        'fade-in': 'fade-in .35s ease-out both',
        'pop-in': 'pop-in .25s ease-out both',
        'toast-in': 'toast-in .28s ease-out both',
        shimmer: 'shimmer 1.6s infinite',
        'draw-check': 'draw-check .6s .25s ease-out forwards',
        'ring-pulse': 'ring-pulse 1.6s ease-out infinite',
      },
    },
  },
  plugins: [],
};
