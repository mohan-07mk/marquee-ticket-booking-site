import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { BadgeIndianRupee, Clock, Play, QrCode, Star, Ticket, Armchair } from 'lucide-react';
import { MovieGrid } from '@/components/MovieGrid';
import { MovieCard } from '@/components/MovieCard';
import { SectionHeader } from '@/components/SectionHeader';
import { TrailerModal } from '@/components/TrailerModal';
import { Button, buttonClasses } from '@/components/ui/Button';
import { ErrorState } from '@/components/ui/States';
import { Skeleton } from '@/components/ui/Skeleton';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { api } from '@/services/api';
import type { Movie } from '@/types';
import { cn } from '@/utils/cn';
import { formatDuration } from '@/utils/format';

export default function Home() {
  useDocumentTitle();
  const { data, loading, error, reload } = useAsync(() => api.movies.list(), []);
  const [trailer, setTrailer] = useState<Movie | null>(null);

  const nowShowing = useMemo(() => (data ?? []).filter((m) => m.status === 'now_showing'), [data]);
  const comingSoon = useMemo(() => (data ?? []).filter((m) => m.status === 'coming_soon'), [data]);
  const featured = useMemo(() => [...nowShowing].sort((a, b) => b.popularity - a.popularity).slice(0, 4), [nowShowing]);
  const popular = useMemo(() => [...nowShowing].sort((a, b) => b.popularity - a.popularity).slice(0, 5), [nowShowing]);

  if (error) {
    return (
      <div className="container-page py-24">
        <ErrorState message={error} onRetry={reload} />
      </div>
    );
  }

  return (
    <>
      {loading || !featured.length ? <HeroSkeleton /> : <Hero movies={featured} onTrailer={setTrailer} />}

      <div className="container-page space-y-20 pt-16 sm:space-y-24 sm:pt-20">
        <section>
          <SectionHeader title="Now showing" subtitle="Fresh in cinemas this week" to="/movies" linkLabel="See all movies" />
          <MovieGrid movies={nowShowing.slice(0, 8)} loading={loading} />
        </section>

        <section>
          <SectionHeader title="Coming soon" subtitle="Get notified the moment booking opens" />
          <div className="no-scrollbar -mx-4 flex snap-x gap-5 overflow-x-auto px-4 pb-2 sm:mx-0 sm:px-0">
            {loading
              ? Array.from({ length: 4 }, (_, i) => <Skeleton key={i} className="h-[440px] w-52 shrink-0" />)
              : comingSoon.map((m) => (
                  <div key={m.id} className="w-44 shrink-0 snap-start sm:w-52">
                    <MovieCard movie={m} />
                  </div>
                ))}
          </div>
        </section>

        <section>
          <SectionHeader title="Most popular this week" subtitle="Ranked by tickets booked" />
          <ol className="grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-3 lg:grid-cols-5">
            {loading
              ? Array.from({ length: 5 }, (_, i) => <Skeleton key={i} className="aspect-[2/3]" />)
              : popular.map((m, i) => (
                  <li key={m.id}>
                    <Link to={`/movies/${m.id}`} className="group flex items-end gap-1">
                      <span
                        aria-hidden="true"
                        className="font-display text-[6.5rem] font-black leading-[0.72] text-transparent transition-colors [-webkit-text-stroke:2px_#4a4a4a] group-hover:[-webkit-text-stroke-color:#e11d2e]"
                      >
                        {i + 1}
                      </span>
                      <div className="min-w-0 flex-1">
                        <img
                          src={m.posterUrl}
                          alt={`${m.title} poster`}
                          loading="lazy"
                          className="aspect-[2/3] w-full rounded-2xl border border-line object-cover transition duration-300 group-hover:-translate-y-1 group-hover:border-brand/60"
                        />
                      </div>
                    </Link>
                    <p className="mt-2 line-clamp-1 pl-1 text-sm font-medium">
                      <span className="sr-only">Number {i + 1}: </span>
                      {m.title}
                    </p>
                  </li>
                ))}
          </ol>
        </section>

        <WhyChooseUs />
      </div>

      <TrailerModal movie={trailer} open={!!trailer} onClose={() => setTrailer(null)} />
    </>
  );
}

/* ------------------------------------------------------------------ */

function Hero({ movies, onTrailer }: { movies: Movie[]; onTrailer: (m: Movie) => void }) {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const active = movies[index];

  useEffect(() => {
    if (paused) return;
    const t = window.setInterval(() => setIndex((i) => (i + 1) % movies.length), 7000);
    return () => window.clearInterval(t);
  }, [paused, movies.length]);

  return (
    <section
      className="relative -mt-[68px] overflow-hidden"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocus={() => setPaused(true)}
      onBlur={() => setPaused(false)}
      aria-roledescription="carousel"
      aria-label="Featured movies"
    >
      {movies.map((m, i) => (
        <img
          key={m.id}
          src={m.backdropUrl}
          alt=""
          aria-hidden="true"
          className={cn('absolute inset-0 h-full w-full object-cover transition-opacity duration-1000', i === index ? 'opacity-100' : 'opacity-0')}
        />
      ))}
      <div className="absolute inset-0 bg-gradient-to-r from-black via-black/75 to-black/10" />
      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/60" />

      <div className="container-page relative flex min-h-[600px] items-end pb-28 pt-40 sm:min-h-[680px] lg:pb-32">
        <div key={active.id} className="max-w-2xl animate-fade-in">
          <div className="flex flex-wrap items-center gap-2.5 text-sm">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1 font-semibold backdrop-blur">
              <Star className="h-4 w-4 fill-gold text-gold" />
              {active.rating.toFixed(1)}
            </span>
            <span className="rounded-full border border-white/25 px-3 py-1 font-medium">{active.certificate}</span>
            <span className="inline-flex items-center gap-1.5 text-white/80">
              <Clock className="h-4 w-4" />
              {formatDuration(active.durationMin)}
            </span>
          </div>

          <h1 className="mt-4 font-display text-6xl font-black leading-[0.88] sm:text-8xl">{active.title}</h1>

          <div className="mt-4 flex flex-wrap gap-2">
            {active.genres.map((g) => (
              <span key={g} className="rounded-full border border-white/25 px-3 py-1 text-sm text-white/85">
                {g}
              </span>
            ))}
            <span className="rounded-full border border-white/25 px-3 py-1 text-sm text-white/85">{active.languages.join(', ')}</span>
          </div>

          <p className="mt-5 line-clamp-3 max-w-xl text-base leading-relaxed text-white/75 sm:text-lg">{active.description}</p>

          <div className="mt-8 flex flex-wrap gap-3">
            <Link to={`/booking?movieId=${active.id}`} className={buttonClasses({ size: 'lg' })}>
              <Ticket className="h-5 w-5" />
              Book Tickets
            </Link>
            <Button size="lg" variant="outline" className="bg-black/30 backdrop-blur" leftIcon={<Play className="h-5 w-5 fill-white" />} onClick={() => onTrailer(active)}>
              Watch Trailer
            </Button>
          </div>
        </div>

        {/* Poster + selector */}
        <div className="absolute bottom-10 right-4 hidden items-end gap-4 sm:right-6 md:flex lg:right-8">
          {movies.map((m, i) => (
            <button
              key={m.id}
              onClick={() => setIndex(i)}
              aria-label={`Show ${m.title}`}
              aria-current={i === index}
              className={cn(
                'overflow-hidden rounded-xl border-2 transition duration-300',
                i === index ? 'w-20 border-brand shadow-[0_0_28px_rgba(225,29,46,.55)]' : 'w-14 border-white/15 opacity-60 hover:opacity-100',
              )}
            >
              <img src={m.posterUrl} alt="" className="aspect-[2/3] w-full object-cover" />
            </button>
          ))}
        </div>
        <div className="absolute inset-x-0 bottom-8 flex justify-center gap-2 md:hidden">
          {movies.map((m, i) => (
            <button
              key={m.id}
              onClick={() => setIndex(i)}
              aria-label={`Show ${m.title}`}
              className={cn('h-1.5 rounded-full transition-all', i === index ? 'w-8 bg-brand' : 'w-3 bg-white/30')}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

function HeroSkeleton() {
  return (
    <section className="relative -mt-[68px] min-h-[600px] bg-surface sm:min-h-[680px]">
      <div className="container-page flex min-h-[600px] items-end pb-28 sm:min-h-[680px]">
        <div className="w-full max-w-2xl space-y-4">
          <Skeleton className="h-6 w-56" />
          <Skeleton className="h-24 w-full" />
          <Skeleton className="h-20 w-4/5" />
          <div className="flex gap-3">
            <Skeleton className="h-[52px] w-44" />
            <Skeleton className="h-[52px] w-44" />
          </div>
        </div>
      </div>
    </section>
  );
}

const reasons = [
  { icon: Armchair, title: 'See the seat before you pay', text: 'Live seat maps show what is free, row by row, with the price of each zone up front.' },
  { icon: BadgeIndianRupee, title: 'Pay the way you like', text: 'UPI, cards and net banking share one quick checkout, and the total never changes at the last step.' },
  { icon: QrCode, title: 'Your ticket is instant', text: 'The QR ticket is ready the moment you pay. No printouts and no queue at the counter.' },
  { icon: Ticket, title: 'Every booking in one place', text: 'Upcoming and past shows sit in a single list, with the ticket one tap away.' },
];

function WhyChooseUs() {
  return (
    <section className="grid gap-12 lg:grid-cols-[1fr_1.5fr] lg:gap-20">
      <div>
        <h2 className="font-display text-4xl font-extrabold leading-[0.95] sm:text-6xl">Less waiting.
          <br />More watching.</h2>
        <p className="mt-5 max-w-md text-muted">
          We built Marquee around the few minutes between deciding on a film and sitting down for it, and made them as short as possible.
        </p>
        <Link to="/movies" className={buttonClasses({ variant: 'secondary', className: 'mt-7' })}>
          Find a movie
        </Link>
      </div>
      <dl className="grid gap-x-10 gap-y-10 sm:grid-cols-2">
        {reasons.map(({ icon: Icon, title, text }) => (
          <div key={title} className="border-t border-line pt-5">
            <Icon className="h-6 w-6 text-brand-hover" />
            <dt className="mt-4 text-lg font-semibold">{title}</dt>
            <dd className="mt-1.5 text-sm leading-relaxed text-muted">{text}</dd>
          </div>
        ))}
      </dl>
    </section>
  );
}
