import type { Format, Show } from '@/types';
import { addDays, toDateKey } from '@/utils/format';
import { premiumPriceFor, standardPrice } from '@/utils/pricing';
import { hashString } from '@/utils/random';
import { movies } from './movies';
import { theatres } from './theatres';

/**
 * MOCK DATA - shows (one row per screening).
 * Generated for the next 7 days from today so the demo always has bookable shows.
 * Replace with: supabase.from('shows').select('*')
 */
export const SHOW_SLOTS = ['10:00', '13:15', '16:30', '19:45', '22:30'];
export const SHOW_DAYS = 7;

export function generateShows(days = SHOW_DAYS): Show[] {
  const today = new Date();
  const shows: Show[] = [];
  const nowShowing = movies.filter((m) => m.status === 'now_showing');
  const activeTheatres = theatres.filter((t) => t.status === 'active');

  nowShowing.forEach((movie, mi) => {
    let chosen = activeTheatres.filter((t) => hashString(movie.id + t.id) % 3 !== 0);
    if (chosen.length < 3) chosen = activeTheatres.slice(0, 3);

    chosen.forEach((theatre, ti) => {
      const compatible = theatre.screens.filter((s) => s.formats.some((f) => movie.formats.includes(f)));
      if (!compatible.length) return;
      const screen = compatible[(mi + ti) % compatible.length];
      const formats = screen.formats.filter((f) => movie.formats.includes(f)) as Format[];

      for (let d = 0; d < days; d++) {
        const date = toDateKey(addDays(today, d));
        const start = (mi + ti + d) % 3;
        for (let k = 0; k < 3; k++) {
          const time = SHOW_SLOTS[start + k];
          const format = formats[(k + mi) % formats.length];
          const price = standardPrice(format, theatre.id, time);
          shows.push({
            id: `sh-${movie.id}-${theatre.id}-${date}-${time.replace(':', '')}`,
            movieId: movie.id,
            theatreId: theatre.id,
            screenId: screen.id,
            date,
            time,
            format,
            language: movie.languages[(k + d) % movie.languages.length],
            price,
            premiumPrice: premiumPriceFor(price),
            status: 'active',
          });
        }
      }
    });
  });

  return shows;
}

export const shows: Show[] = generateShows();
