import { useState, type FormEvent } from 'react';
import type { Format, Movie, MovieStatus } from '@/types';
import { useToast } from '@/context/ToastContext';
import { api } from '@/services/api';
import { toDateKey } from '@/utils/format';
import { Button } from '../ui/Button';
import { ChipSelect } from '../ui/ChipSelect';
import { Field, Input, Select, Textarea } from '../ui/Field';
import { Modal } from '../ui/Modal';

const GENRES = ['Action', 'Adventure', 'Comedy', 'Drama', 'Family', 'Fantasy', 'Romance', 'Sci-Fi', 'Thriller'];
const LANGUAGES = ['English', 'Hindi', 'Malayalam', 'Tamil', 'Telugu'];
const FORMATS: Format[] = ['2D', '3D', 'IMAX'];

interface Props {
  open: boolean;
  movie: Movie | null;
  onClose: () => void;
  onSaved: () => void;
}

export function MovieFormModal({ open, movie, onClose, onSaved }: Props) {
  if (!open) return null;
  return <Inner key={movie?.id ?? 'new'} movie={movie} onClose={onClose} onSaved={onSaved} />;
}

function Inner({ movie, onClose, onSaved }: Omit<Props, 'open'>) {
  const toast = useToast();
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [posterFile, setPosterFile] = useState<File | null>(null);
  const [backdropFile, setBackdropFile] = useState<File | null>(null);
  const [posterPreview, setPosterPreview] = useState<string>(movie?.posterUrl?.startsWith('data:') ? '' : (movie?.posterUrl ?? ''));
  const [backdropPreview, setBackdropPreview] = useState<string>(movie?.backdropUrl?.startsWith('data:') ? '' : (movie?.backdropUrl ?? ''));

  const [f, setF] = useState({
    title: movie?.title ?? '',
    description: movie?.description ?? '',
    languages: movie?.languages ?? ([] as string[]),
    genres: movie?.genres ?? ([] as string[]),
    formats: movie?.formats ?? (['2D'] as Format[]),
    durationMin: String(movie?.durationMin ?? 120),
    releaseDate: movie?.releaseDate ?? toDateKey(new Date()),
    rating: String(movie?.rating ?? 0),
    certificate: movie?.certificate ?? 'UA',
    status: (movie?.status ?? 'coming_soon') as MovieStatus,
    director: movie?.director ?? '',
    cast: movie?.cast?.join(', ') ?? '',
    trailerUrl: movie?.trailerUrl ?? '',
    posterUrl: movie?.posterUrl?.startsWith('data:') ? '' : (movie?.posterUrl ?? ''),
    backdropUrl: movie?.backdropUrl?.startsWith('data:') ? '' : (movie?.backdropUrl ?? ''),
  });

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const next: Record<string, string> = {};
    if (!f.title.trim()) next.title = 'Give the movie a title.';
    if (!f.description.trim()) next.description = 'Add a short description.';
    if (!f.languages.length) next.languages = 'Pick at least one language.';
    if (!f.genres.length) next.genres = 'Pick at least one genre.';
    if (!f.formats.length) next.formats = 'Pick at least one format.';
    const dur = Number(f.durationMin);
    if (!dur || dur < 30 || dur > 300) next.durationMin = 'Duration should be 30 to 300 minutes.';
    const rating = Number(f.rating);
    if (Number.isNaN(rating) || rating < 0 || rating > 10) next.rating = 'Rating is between 0 and 10.';
    if (!f.releaseDate) next.releaseDate = 'Choose a release date.';
    setErrors(next);
    if (Object.keys(next).length) return;

    setSaving(true);
    try {
      const payload = {
        title: f.title.trim(),
        description: f.description.trim(),
        languages: f.languages,
        genres: f.genres,
        formats: f.formats,
        durationMin: dur,
        releaseDate: f.releaseDate,
        rating,
        certificate: f.certificate,
        status: f.status,
        director: f.director.trim() || 'To be announced',
        cast: f.cast.split(',').map((c) => c.trim()).filter(Boolean),
        trailerUrl: f.trailerUrl.trim(),
        posterUrl: f.posterUrl.trim(),
        backdropUrl: f.backdropUrl.trim(),
        posterFile: posterFile ?? undefined,
        backdropFile: backdropFile ?? undefined,
      };
      if (movie) await api.movies.update(movie.id, payload);
      else await api.movies.create(payload);
      toast.success(movie ? 'Movie updated' : 'Movie added', payload.title);
      onSaved();
      onClose();
    } catch (err) {
      toast.error('Couldn’t save the movie', err instanceof Error ? err.message : undefined);
      setSaving(false);
    }
  };

  return (
    <Modal
      open
      onClose={saving ? () => undefined : onClose}
      title={movie ? 'Edit movie' : 'Add movie'}
      description="Upload poster and landscape backdrop images or supply custom image URLs."
      size="lg"
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={saving}>
            Cancel
          </Button>
          <Button type="submit" form="movie-form" loading={saving}>
            {saving ? 'Saving...' : movie ? 'Save changes' : 'Add movie'}
          </Button>
        </>
      }
    >
      <form id="movie-form" onSubmit={submit} noValidate className="grid gap-5 sm:grid-cols-2">
        <Field label="Title" htmlFor="m-title" error={errors.title} className="sm:col-span-2">
          <Input id="m-title" value={f.title} invalid={!!errors.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
        </Field>
        <Field label="Description" htmlFor="m-desc" error={errors.description} className="sm:col-span-2">
          <Textarea id="m-desc" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
        </Field>
        <Field label="Languages" error={errors.languages} className="sm:col-span-2">
          <ChipSelect label="Languages" options={LANGUAGES} value={f.languages} onChange={(languages) => setF({ ...f, languages })} />
        </Field>
        <Field label="Genres" error={errors.genres} className="sm:col-span-2">
          <ChipSelect label="Genres" options={GENRES} value={f.genres} onChange={(genres) => setF({ ...f, genres })} />
        </Field>
        <Field label="Formats" error={errors.formats} className="sm:col-span-2">
          <ChipSelect label="Formats" options={FORMATS} value={f.formats} onChange={(formats) => setF({ ...f, formats })} />
        </Field>
        <Field label="Duration (minutes)" htmlFor="m-dur" error={errors.durationMin}>
          <Input id="m-dur" type="number" min={30} max={300} value={f.durationMin} invalid={!!errors.durationMin} onChange={(e) => setF({ ...f, durationMin: e.target.value })} />
        </Field>
        <Field label="Release date" htmlFor="m-date" error={errors.releaseDate}>
          <Input id="m-date" type="date" value={f.releaseDate} invalid={!!errors.releaseDate} onChange={(e) => setF({ ...f, releaseDate: e.target.value })} />
        </Field>
        <Field label="Rating (0 to 10)" htmlFor="m-rating" error={errors.rating}>
          <Input id="m-rating" type="number" step="0.1" min={0} max={10} value={f.rating} invalid={!!errors.rating} onChange={(e) => setF({ ...f, rating: e.target.value })} />
        </Field>
        <Field label="Certificate" htmlFor="m-cert">
          <Select id="m-cert" value={f.certificate} onChange={(e) => setF({ ...f, certificate: e.target.value })}>
            <option>U</option>
            <option>UA</option>
            <option>A</option>
          </Select>
        </Field>
        <Field label="Status" htmlFor="m-status">
          <Select id="m-status" value={f.status} onChange={(e) => setF({ ...f, status: e.target.value as MovieStatus })}>
            <option value="now_showing">Now showing</option>
            <option value="coming_soon">Coming soon</option>
            <option value="inactive">Inactive</option>
          </Select>
        </Field>
        <Field label="Director" htmlFor="m-dir">
          <Input id="m-dir" value={f.director} onChange={(e) => setF({ ...f, director: e.target.value })} />
        </Field>
        <Field label="Cast" htmlFor="m-cast" hint="Separate names with commas." className="sm:col-span-2">
          <Input id="m-cast" value={f.cast} onChange={(e) => setF({ ...f, cast: e.target.value })} />
        </Field>

        {/* Trailer URL Field */}
        <Field label="Trailer URL (YouTube)" htmlFor="m-trailer" hint="e.g. https://www.youtube.com/watch?v=... or https://youtu.be/..." className="sm:col-span-2">
          <Input
            id="m-trailer"
            type="url"
            placeholder="https://www.youtube.com/watch?v=..."
            value={f.trailerUrl}
            onChange={(e) => setF({ ...f, trailerUrl: e.target.value })}
          />
        </Field>

        {/* Poster Image Section */}
        <Field label="Poster Image" htmlFor="m-poster-file" hint="PNG, JPG, WEBP formats." className="sm:col-span-2">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            {posterPreview ? (
              <img src={posterPreview} alt="Poster preview" className="h-28 w-20 shrink-0 rounded-xl border border-line object-cover" />
            ) : (
              <div className="grid h-28 w-20 shrink-0 place-items-center rounded-xl border border-dashed border-line bg-surface text-xs text-muted">
                No poster
              </div>
            )}
            <div className="flex-1 space-y-2">
              <input
                id="m-poster-file"
                type="file"
                accept="image/png,image/jpeg,image/webp"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    setPosterFile(file);
                    setPosterPreview(URL.createObjectURL(file));
                  }
                }}
                className="block w-full cursor-pointer text-xs text-muted file:mr-3 file:rounded-lg file:border-0 file:bg-white/10 file:px-3 file:py-1.5 file:text-xs file:font-medium file:text-white hover:file:bg-white/20"
              />
              <Input
                type="url"
                placeholder="Or paste Poster Image URL (https://...)"
                value={f.posterUrl}
                onChange={(e) => {
                  const val = e.target.value;
                  setF({ ...f, posterUrl: val });
                  if (!posterFile) setPosterPreview(val);
                }}
              />
            </div>
          </div>
        </Field>

        {/* Backdrop / Landscape Image Section */}
        <Field label="Landscape / Backdrop Image" htmlFor="m-backdrop-file" hint="PNG, JPG, WEBP formats." className="sm:col-span-2">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            {backdropPreview ? (
              <img src={backdropPreview} alt="Backdrop preview" className="h-24 w-40 shrink-0 rounded-xl border border-line object-cover" />
            ) : (
              <div className="grid h-24 w-40 shrink-0 place-items-center rounded-xl border border-dashed border-line bg-surface text-xs text-muted">
                No backdrop
              </div>
            )}
            <div className="flex-1 space-y-2">
              <input
                id="m-backdrop-file"
                type="file"
                accept="image/png,image/jpeg,image/webp"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    setBackdropFile(file);
                    setBackdropPreview(URL.createObjectURL(file));
                  }
                }}
                className="block w-full cursor-pointer text-xs text-muted file:mr-3 file:rounded-lg file:border-0 file:bg-white/10 file:px-3 file:py-1.5 file:text-xs file:font-medium file:text-white hover:file:bg-white/20"
              />
              <Input
                type="url"
                placeholder="Or paste Backdrop Image URL (https://...)"
                value={f.backdropUrl}
                onChange={(e) => {
                  const val = e.target.value;
                  setF({ ...f, backdropUrl: val });
                  if (!backdropFile) setBackdropPreview(val);
                }}
              />
            </div>
          </div>
        </Field>
      </form>
    </Modal>
  );
}
