import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';

export function SectionHeader({
  title,
  subtitle,
  to,
  linkLabel = 'See all',
  action,
}: {
  title: string;
  subtitle?: string;
  to?: string;
  linkLabel?: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-6 flex items-end justify-between gap-4">
      <div>
        <h2 className="font-display text-3xl font-extrabold leading-none sm:text-4xl">{title}</h2>
        {subtitle && <p className="mt-2 text-sm text-muted">{subtitle}</p>}
      </div>
      {to && (
        <Link
          to={to}
          className="inline-flex shrink-0 items-center gap-1 rounded-lg px-2 py-1 text-sm font-medium text-white/70 transition hover:text-white"
        >
          {linkLabel}
          <ChevronRight className="h-4 w-4" />
        </Link>
      )}
      {action}
    </div>
  );
}
