import { Link } from 'react-router-dom';
import { useCookieConsent } from '@/context/CookieContext';
import { Logo } from './Logo';

export function Footer() {
  const { openSettings } = useCookieConsent();

  return (
    <footer className="mt-24 border-t border-line bg-surface/40">
      <div className="container-page grid gap-10 py-14 md:grid-cols-[1.6fr_repeat(3,1fr)]">
        <div className="max-w-sm">
          <Logo />
          <p className="mt-4 text-sm leading-relaxed text-muted">
            Pick a film, choose your seats and walk straight in. Marquee keeps every step of booking a night out to a few taps.
          </p>
        </div>

        <nav aria-label="Explore">
          <h3 className="mb-3 text-sm font-semibold text-white">Explore</h3>
          <ul className="space-y-2">
            <li>
              <Link to="/movies" className="text-sm text-muted transition hover:text-white">
                Movies
              </Link>
            </li>
            <li>
              <Link to="/theatres" className="text-sm text-muted transition hover:text-white">
                Theatres
              </Link>
            </li>
            <li>
              <Link to="/my-bookings" className="text-sm text-muted transition hover:text-white">
                My bookings
              </Link>
            </li>
          </ul>
        </nav>

        <nav aria-label="Account & Team">
          <h3 className="mb-3 text-sm font-semibold text-white">Account</h3>
          <ul className="space-y-2">
            <li>
              <Link to="/login" className="text-sm text-muted transition hover:text-white">
                Log in
              </Link>
            </li>
            <li>
              <Link to="/register" className="text-sm text-muted transition hover:text-white">
                Create account
              </Link>
            </li>
            <li>
              <Link to="/admin" className="text-sm text-muted transition hover:text-white">
                Admin dashboard
              </Link>
            </li>
          </ul>
        </nav>

        <nav aria-label="Legal & Privacy">
          <h3 className="mb-3 text-sm font-semibold text-white">Legal</h3>
          <ul className="space-y-2">
            <li>
              <Link to="/privacy-policy" className="text-sm text-muted transition hover:text-white">
                Privacy Policy
              </Link>
            </li>
            <li>
              <Link to="/terms-and-conditions" className="text-sm text-muted transition hover:text-white">
                Terms &amp; Conditions
              </Link>
            </li>
            <li>
              <button
                type="button"
                onClick={openSettings}
                className="text-left text-sm text-muted transition hover:text-white focus:outline-none"
              >
                Cookie Settings
              </button>
            </li>
          </ul>
        </nav>
      </div>

      <div className="border-t border-line">
        <div className="container-page flex flex-col gap-2 py-6 text-xs text-muted sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} Marquee. All rights reserved.</p>
          <div className="flex flex-wrap items-center gap-4">
            <Link to="/privacy-policy" className="transition hover:text-white">
              Privacy
            </Link>
            <Link to="/terms-and-conditions" className="transition hover:text-white">
              Terms
            </Link>
            <button type="button" onClick={openSettings} className="transition hover:text-white">
              Cookie Settings
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
