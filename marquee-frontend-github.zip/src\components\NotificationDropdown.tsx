import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Bell,
  BellOff,
  CheckCheck,
  CreditCard,
  Film,
  Sparkles,
  Ticket,
  Trash2,
  Tv,
  X,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { api } from '@/services/api';
import type { Booking } from '@/types';
import { formatCurrency } from '@/utils/format';

export interface AppNotification {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  type: 'booking' | 'payment' | 'theatre' | 'system' | 'promo';
  read: boolean;
  link?: string;
}

function formatRelativeTime(dateInput: string): string {
  try {
    const d = new Date(dateInput);
    const now = Date.now();
    const diffSec = Math.floor((now - d.getTime()) / 1000);
    if (isNaN(diffSec) || diffSec < 60) return 'Just now';
    const diffMin = Math.floor(diffSec / 60);
    if (diffMin < 60) return `${diffMin}m ago`;
    const diffHours = Math.floor(diffMin / 60);
    if (diffHours < 24) return `${diffHours}h ago`;
    const diffDays = Math.floor(diffHours / 24);
    return `${diffDays}d ago`;
  } catch {
    return 'Recently';
  }
}

interface NotificationDropdownProps {
  variant?: 'admin' | 'user';
  className?: string;
}

export function NotificationDropdown({ variant = 'admin', className = '' }: NotificationDropdownProps) {
  const { user } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const storageKeyRead = `marquee_read_notifs_${variant}`;
  const storageKeyDismissed = `marquee_dismissed_notifs_${variant}`;

  // Close when clicking outside
  useEffect(() => {
    if (!open) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (!dropdownRef.current?.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [open]);

  // Load and merge notifications
  useEffect(() => {
    let isMounted = true;

    async function loadNotifications() {
      let readIds: string[] = [];
      let dismissedIds: string[] = [];
      try {
        readIds = JSON.parse(localStorage.getItem(storageKeyRead) || '[]');
        dismissedIds = JSON.parse(localStorage.getItem(storageKeyDismissed) || '[]');
      } catch {
        // ignore storage parse errors
      }

      const list: AppNotification[] = [];

      if (variant === 'admin') {
        try {
          const bookings = await api.bookings.listAll();
          const recentBookings = (bookings || []).slice(0, 6);
          recentBookings.forEach((b: Booking) => {
            const seatsCount = b.seats?.length || 1;
            const isConfirmed = b.status === 'confirmed';
            list.push({
              id: `bkg-${b.id}`,
              title: isConfirmed ? `New Booking: ${b.movieTitle}` : `Booking Cancelled: ${b.movieTitle}`,
              message: `${b.customerName || 'Customer'} · ${formatCurrency(b.amount)} · ${seatsCount} seat${seatsCount > 1 ? 's' : ''} (${b.theatreName})`,
              timestamp: b.createdAt || new Date().toISOString(),
              type: isConfirmed ? 'booking' : 'payment',
              read: readIds.includes(`bkg-${b.id}`),
              link: '/admin/bookings',
            });
          });
        } catch {
          // fallback to seed if bookings fetch fails
        }

        // Static system alerts for admin
        const adminSystemAlerts: AppNotification[] = [
          {
            id: 'admin-sys-3d',
            title: '3D Screen Video Active',
            message: 'Live YouTube screen video links configured for theatre auditoriums.',
            timestamp: new Date(Date.now() - 1000 * 60 * 12).toISOString(),
            type: 'theatre',
            read: readIds.includes('admin-sys-3d'),
            link: '/admin/theatres',
          },
          {
            id: 'admin-sys-pay',
            title: 'Razorpay Gateway Verified',
            message: 'Online checkout integration & webhook verification active.',
            timestamp: new Date(Date.now() - 1000 * 60 * 45).toISOString(),
            type: 'payment',
            read: readIds.includes('admin-sys-pay'),
            link: '/admin/revenue',
          },
          {
            id: 'admin-sys-cloud',
            title: 'Supabase Database Connected',
            message: 'Movies, theatres, shows, seats, and user accounts synced.',
            timestamp: new Date(Date.now() - 1000 * 60 * 120).toISOString(),
            type: 'system',
            read: readIds.includes('admin-sys-cloud'),
            link: '/admin',
          },
        ];

        adminSystemAlerts.forEach((a) => list.push(a));
      } else {
        // Customer / User notifications
        if (user) {
          try {
            const userBookings = await api.bookings.listForUser(user.id);
            (userBookings || []).slice(0, 5).forEach((b: Booking) => {
              list.push({
                id: `usr-bkg-${b.id}`,
                title: `Booking Confirmed: ${b.movieTitle}`,
                message: `${b.theatreName} · ${b.date} at ${b.time} · Seat(s): ${b.seats?.join(', ') || 'Reserved'}`,
                timestamp: b.createdAt || new Date().toISOString(),
                type: 'booking',
                read: readIds.includes(`usr-bkg-${b.id}`),
                link: '/my-bookings',
              });
            });
          } catch {
            // ignore
          }
        }

        // Feature and promo notices
        const userNotices: AppNotification[] = [
          {
            id: 'usr-promo-3d',
            title: 'Try 3D Cinema View',
            message: 'Preview your exact seat view and watch live trailers right on the 3D screen!',
            timestamp: new Date(Date.now() - 1000 * 60 * 30).toISOString(),
            type: 'promo',
            read: readIds.includes('usr-promo-3d'),
            link: '/movies',
          },
          {
            id: 'usr-promo-welcome',
            title: 'Welcome to Marquee',
            message: 'Seamless movie booking with real-time seat availability and fast checkout.',
            timestamp: new Date(Date.now() - 1000 * 60 * 180).toISOString(),
            type: 'system',
            read: readIds.includes('usr-promo-welcome'),
            link: '/movies',
          },
        ];

        userNotices.forEach((n) => list.push(n));
      }

      // Filter out dismissed notifications
      const visible = list.filter((item) => !dismissedIds.includes(item.id));
      if (isMounted) {
        setNotifications(visible);
      }
    }

    loadNotifications();
    return () => {
      isMounted = false;
    };
  }, [variant, user, storageKeyRead, storageKeyDismissed]);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const markAllAsRead = () => {
    const allIds = notifications.map((n) => n.id);
    try {
      localStorage.setItem(storageKeyRead, JSON.stringify(allIds));
    } catch {
      // ignore
    }
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    toast.success('Marked all as read');
  };

  const markSingleAsRead = (id: string, link?: string) => {
    let readIds: string[] = [];
    try {
      readIds = JSON.parse(localStorage.getItem(storageKeyRead) || '[]');
      if (!readIds.includes(id)) {
        readIds.push(id);
        localStorage.setItem(storageKeyRead, JSON.stringify(readIds));
      }
    } catch {
      // ignore
    }

    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
    if (link) {
      setOpen(false);
      navigate(link);
    }
  };

  const dismissNotification = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    let dismissedIds: string[] = [];
    try {
      dismissedIds = JSON.parse(localStorage.getItem(storageKeyDismissed) || '[]');
      if (!dismissedIds.includes(id)) {
        dismissedIds.push(id);
        localStorage.setItem(storageKeyDismissed, JSON.stringify(dismissedIds));
      }
    } catch {
      // ignore
    }
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const clearAll = () => {
    const allIds = notifications.map((n) => n.id);
    try {
      localStorage.setItem(storageKeyDismissed, JSON.stringify(allIds));
    } catch {
      // ignore
    }
    setNotifications([]);
    toast.info('Notifications cleared');
  };

  const getIcon = (type: AppNotification['type']) => {
    switch (type) {
      case 'booking':
        return <Ticket className="h-4 w-4 text-brand" />;
      case 'payment':
        return <CreditCard className="h-4 w-4 text-emerald-400" />;
      case 'theatre':
        return <Tv className="h-4 w-4 text-purple-400" />;
      case 'promo':
        return <Film className="h-4 w-4 text-sky-400" />;
      case 'system':
      default:
        return <Sparkles className="h-4 w-4 text-amber-400" />;
    }
  };

  return (
    <div className={`relative ${className}`} ref={dropdownRef}>
      {/* Trigger Bell Button */}
      <button
        onClick={() => setOpen((prev) => !prev)}
        className="relative grid h-10 w-10 place-items-center rounded-xl border border-line bg-surface/60 text-white/70 transition hover:border-white/30 hover:bg-surface hover:text-white focus:outline-none focus:ring-2 focus:ring-brand/40"
        aria-label={`Notifications (${unreadCount} unread)`}
        aria-expanded={open}
        type="button"
      >
        <Bell className="h-5 w-5" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-brand px-1 text-[10px] font-bold text-white shadow-lg animate-pulse">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {/* Floating Dropdown */}
      {open && (
        <div className="absolute right-0 top-12 z-50 w-80 sm:w-96 animate-pop-in rounded-2xl border border-line bg-[#141419]/95 p-0 backdrop-blur-2xl shadow-2xl shadow-black/80 ring-1 ring-white/10">
          {/* Header */}
          <div className="flex items-center justify-between border-b border-line/60 px-4 py-3">
            <div className="flex items-center gap-2">
              <span className="font-semibold text-white">Notifications</span>
              {unreadCount > 0 ? (
                <span className="rounded-full bg-brand/20 px-2 py-0.5 text-xs font-semibold text-brand">
                  {unreadCount} new
                </span>
              ) : (
                <span className="rounded-full bg-white/10 px-2 py-0.5 text-xs font-medium text-white/50">
                  All caught up
                </span>
              )}
            </div>
            {unreadCount > 0 && (
              <button
                onClick={markAllAsRead}
                className="flex items-center gap-1 text-xs font-medium text-white/60 transition hover:text-brand"
                title="Mark all notifications as read"
                type="button"
              >
                <CheckCheck className="h-3.5 w-3.5" />
                Mark all read
              </button>
            )}
          </div>

          {/* Notifications List */}
          <div className="max-h-80 overflow-y-auto divide-y divide-line/30 overscroll-contain">
            {notifications.length === 0 ? (
              <div className="flex flex-col items-center justify-center px-6 py-10 text-center">
                <div className="grid h-12 w-12 place-items-center rounded-full bg-white/5 text-muted mb-3">
                  <BellOff className="h-6 w-6" />
                </div>
                <p className="text-sm font-semibold text-white">No notifications</p>
                <p className="mt-1 text-xs text-muted">You’re all caught up with recent updates.</p>
              </div>
            ) : (
              notifications.map((item) => (
                <div
                  key={item.id}
                  onClick={() => markSingleAsRead(item.id, item.link)}
                  className={`group relative flex cursor-pointer items-start gap-3 p-3.5 transition hover:bg-white/5 ${
                    !item.read ? 'bg-brand/5' : ''
                  }`}
                >
                  {/* Icon Box */}
                  <div className="mt-0.5 grid h-8 w-8 flex-shrink-0 place-items-center rounded-lg border border-white/10 bg-white/5">
                    {getIcon(item.type)}
                  </div>

                  {/* Text Content */}
                  <div className="flex-1 min-w-0 pr-4">
                    <div className="flex items-center gap-1.5 justify-between">
                      <p className={`truncate text-xs font-semibold ${!item.read ? 'text-white' : 'text-white/80'}`}>
                        {item.title}
                      </p>
                      <span className="flex-shrink-0 text-[10px] text-white/40">
                        {formatRelativeTime(item.timestamp)}
                      </span>
                    </div>
                    <p className="mt-0.5 text-xs text-white/60 line-clamp-2 leading-relaxed">
                      {item.message}
                    </p>
                  </div>

                  {/* Actions / Unread Dot */}
                  <div className="flex flex-col items-center gap-1 flex-shrink-0">
                    {!item.read && (
                      <span className="h-2 w-2 rounded-full bg-brand" title="Unread" />
                    )}
                    <button
                      onClick={(e) => dismissNotification(e, item.id)}
                      className="opacity-0 group-hover:opacity-100 p-1 text-white/40 hover:text-white transition rounded"
                      title="Dismiss"
                      type="button"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer */}
          {notifications.length > 0 && (
            <div className="flex items-center justify-between border-t border-line/60 bg-white/[0.02] px-4 py-2.5">
              <button
                onClick={clearAll}
                className="flex items-center gap-1.5 text-xs text-white/50 transition hover:text-red-400"
                type="button"
              >
                <Trash2 className="h-3 w-3" />
                Clear all
              </button>
              <button
                onClick={() => {
                  setOpen(false);
                  navigate(variant === 'admin' ? '/admin/bookings' : '/my-bookings');
                }}
                className="text-xs font-semibold text-brand transition hover:underline"
                type="button"
              >
                {variant === 'admin' ? 'View all bookings →' : 'View my tickets →'}
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
