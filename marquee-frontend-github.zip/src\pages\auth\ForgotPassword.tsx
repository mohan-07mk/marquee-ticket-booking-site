import { useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, MailCheck, Mail } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Field, Input } from '@/components/ui/Field';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { api } from '@/services/api';
import { isEmail } from '@/utils/validators';

export default function ForgotPassword() {
  useDocumentTitle('Reset password');
  const [email, setEmail] = useState('');
  const [error, setError] = useState<string>();
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!isEmail(email)) {
      setError('Enter a valid email address.');
      return;
    }
    setError(undefined);
    setLoading(true);
    await api.auth.forgotPassword(email.trim());
    setLoading(false);
    setSent(true);
  };

  return (
    <div className="animate-fade-in">
      <Link to="/login" className="mb-8 inline-flex items-center gap-1.5 text-sm text-muted transition hover:text-white">
        <ArrowLeft className="h-4 w-4" />
        Back to log in
      </Link>

      {sent ? (
        <div>
          <span className="mb-5 grid h-14 w-14 place-items-center rounded-2xl bg-emerald-500/15 text-emerald-400">
            <MailCheck className="h-7 w-7" />
          </span>
          <h1 className="font-display text-5xl font-extrabold leading-none">Check your inbox</h1>
          <p className="mt-3 text-muted">
            If an account exists for <span className="font-medium text-white">{email}</span>, a reset link is on its way. It can take a minute to arrive.
          </p>
          <Button variant="outline" size="lg" className="mt-8 w-full" onClick={() => setSent(false)}>
            Use a different email
          </Button>
        </div>
      ) : (
        <>
          <h1 className="font-display text-5xl font-extrabold leading-none">Reset your password</h1>
          <p className="mt-3 text-muted">Enter the email you signed up with and we’ll send you a link to choose a new password.</p>
          <form onSubmit={submit} noValidate className="mt-8 space-y-5">
            <Field label="Email" htmlFor="email" error={error}>
              <Input id="email" type="email" autoComplete="email" placeholder="you@example.com" icon={<Mail className="h-4 w-4" />} value={email} invalid={!!error} onChange={(e) => setEmail(e.target.value)} />
            </Field>
            <Button type="submit" size="lg" className="w-full" loading={loading}>
              Send reset link
            </Button>
          </form>
        </>
      )}
    </div>
  );
}
