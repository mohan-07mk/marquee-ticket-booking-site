import { lazy, Suspense } from 'react';
import { Route, Routes } from 'react-router-dom';
import { RequireAdmin, RequireAuth } from '@/components/guards/AuthGuards';
import { AdminLayout } from '@/layouts/AdminLayout';
import { AuthLayout } from '@/layouts/AuthLayout';
import { CustomerLayout } from '@/layouts/CustomerLayout';
import Booking from '@/pages/Booking';
import BookingSuccess from '@/pages/BookingSuccess';
import Checkout from '@/pages/Checkout';
import Home from '@/pages/Home';
import MovieDetails from '@/pages/MovieDetails';
import Movies from '@/pages/Movies';
import MyBookings from '@/pages/MyBookings';
import NotFound from '@/pages/NotFound';
import SeatSelection from '@/pages/SeatSelection';
import Theatres from '@/pages/Theatres';
import ForgotPassword from '@/pages/auth/ForgotPassword';
import Login from '@/pages/auth/Login';
import Register from '@/pages/auth/Register';
import ResetPassword from '@/pages/auth/ResetPassword';
import PrivacyPolicy from '@/pages/PrivacyPolicy';
import TermsAndConditions from '@/pages/TermsAndConditions';
import { Skeleton } from '@/components/ui/Skeleton';

// The admin area (and its charting library) is only downloaded when someone opens /admin.
const Dashboard = lazy(() => import('@/pages/admin/Dashboard'));
const MoviesAdmin = lazy(() => import('@/pages/admin/MoviesAdmin'));
const TheatresAdmin = lazy(() => import('@/pages/admin/TheatresAdmin'));
const ShowsAdmin = lazy(() => import('@/pages/admin/ShowsAdmin'));
const BookingsAdmin = lazy(() => import('@/pages/admin/BookingsAdmin'));
const UsersAdmin = lazy(() => import('@/pages/admin/UsersAdmin'));
const Revenue = lazy(() => import('@/pages/admin/Revenue'));

const AdminFallback = () => (
  <div className="space-y-4">
    <Skeleton className="h-28 w-full" />
    <Skeleton className="h-72 w-full" />
  </div>
);

/**
 * ROUTE MAP
 * Customer  : /  /movies  /movies/:id  /theatres  /booking  /booking/seats  /checkout  /booking-success  /my-bookings
 * Auth      : /login  /register  /forgot-password
 * Admin     : /admin  /admin/movies  /admin/theatres  /admin/shows  /admin/bookings  /admin/users  /admin/revenue
 *
 * Protected routes:
 * - /checkout, /booking-success, /my-bookings require authentication (RequireAuth)
 * - /admin/* routes require admin role (RequireAdmin)
 */
export function AppRoutes() {
  return (
    <Routes>
      <Route element={<CustomerLayout />}>
        <Route index element={<Home />} />
        <Route path="movies" element={<Movies />} />
        <Route path="movies/:id" element={<MovieDetails />} />
        <Route path="theatres" element={<Theatres />} />
        <Route path="booking" element={<Booking />} />
        <Route path="booking/seats" element={<SeatSelection />} />
        <Route
          path="checkout"
          element={
            <RequireAuth>
              <Checkout />
            </RequireAuth>
          }
        />
        <Route
          path="booking-success"
          element={
            <RequireAuth>
              <BookingSuccess />
            </RequireAuth>
          }
        />
        <Route
          path="booking-confirmation/:bookingId"
          element={
            <RequireAuth>
              <BookingSuccess />
            </RequireAuth>
          }
        />
        <Route
          path="my-bookings"
          element={
            <RequireAuth>
              <MyBookings />
            </RequireAuth>
          }
        />
        <Route path="privacy-policy" element={<PrivacyPolicy />} />
        <Route path="terms-and-conditions" element={<TermsAndConditions />} />
        <Route path="*" element={<NotFound />} />
      </Route>

      <Route element={<AuthLayout />}>
        <Route path="login" element={<Login />} />
        <Route path="register" element={<Register />} />
        <Route path="forgot-password" element={<ForgotPassword />} />
        <Route path="reset-password" element={<ResetPassword />} />
      </Route>

      <Route
        path="admin"
        element={
          <RequireAdmin>
            <Suspense fallback={<AdminFallback />}>
              <AdminLayout />
            </Suspense>
          </RequireAdmin>
        }
      >
        <Route
          index
          element={
            <Suspense fallback={<AdminFallback />}>
              <Dashboard />
            </Suspense>
          }
        />
        <Route path="movies" element={<Suspense fallback={<AdminFallback />}><MoviesAdmin /></Suspense>} />
        <Route path="theatres" element={<Suspense fallback={<AdminFallback />}><TheatresAdmin /></Suspense>} />
        <Route path="shows" element={<Suspense fallback={<AdminFallback />}><ShowsAdmin /></Suspense>} />
        <Route path="bookings" element={<Suspense fallback={<AdminFallback />}><BookingsAdmin /></Suspense>} />
        <Route path="users" element={<Suspense fallback={<AdminFallback />}><UsersAdmin /></Suspense>} />
        <Route path="revenue" element={<Suspense fallback={<AdminFallback />}><Revenue /></Suspense>} />
      </Route>
    </Routes>
  );
}
