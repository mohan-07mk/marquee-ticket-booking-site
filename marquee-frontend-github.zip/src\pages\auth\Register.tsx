import { useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Eye, EyeOff, Lock, Mail, Phone, User } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Field, Input } from '@/components/ui/Field';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { isEmail, isPhone } from '@/utils/validators';
import { GoogleButton, OrDivider } from './GoogleButton';

type Errors = Partial<Record<'name' | 'email' | 'phone' | 'password' | 'confirm', string>>;

export default function Register() {
  useDocumentTitle('Create account');
  const { register, loginWithGoogle } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '', confirm: '' });
  const [errors, setErrors] = useState<Errors>({});
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) => setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const next: Errors = {};
    if (form.name.trim().length < 2) next.name = 'Enter your full name.';
    if (!isEmail(form.email)) next.email = 'Enter a valid email address.';
    if (!isPhone(form.phone)) next.phone = 'Enter a valid phone number (10 digits or more).';
    if (form.password.length < 6) next.password = 'Use at least 6 characters.';
    if (form.confirm !== form.password) next.confirm = 'Passwords don’t match.';
    setErrors(next);
    if (Object.keys(next).length) return;

    setLoading(true);
    try {
      const user = await register({ name: form.name.trim(), email: form.email.trim(), phone: form.phone.trim(), password: form.password });
      toast.success(`Welcome to Marquee, ${user.name.split(' ')[0]}`, 'Your account is ready.');
      navigate('/');
    } catch (err) {
      toast.error('Couldn’t create your account', err instanceof Error ? err.message : undefined);
      setLoading(false);
    }
  };

  const google = async () => {
    setGoogleLoading(true);
    try {
      await loginWithGoogle();
      // OAuth will redirect
    } catch (err) {
      toast.error('Could not sign up with Google', err instanceof Error ? err.message : undefined);
      setGoogleLoading(false);
    }
  };

  return (
    <div className="animate-fade-in">
      <h1 className="font-display text-5xl font-extrabold leading-none">Create your account</h1>
      <p className="mt-3 text-muted">Save your details once and check out in a couple of taps.</p>

      <div className="mt-8">
        <GoogleButton label="Sign up with Google" onClick={google} loading={googleLoading} />
      </div>
      <OrDivider />

      <form onSubmit={submit} noValidate className="space-y-4">
        <Field label="Full name" htmlFor="name" error={errors.name}>
          <Input id="name" autoComplete="name" placeholder="Your name" icon={<User className="h-4 w-4" />} value={form.name} invalid={!!errors.name} onChange={set('name')} />
        </Field>
        <Field label="Email" htmlFor="email" error={errors.email}>
          <Input id="email" type="email" autoComplete="email" placeholder="you@example.com" icon={<Mail className="h-4 w-4" />} value={form.email} invalid={!!errors.email} onChange={set('email')} />
        </Field>
        <Field label="Phone" htmlFor="phone" error={errors.phone}>
          <Input id="phone" type="tel" autoComplete="tel" placeholder="+91 98765 43210" icon={<Phone className="h-4 w-4" />} value={form.phone} invalid={!!errors.phone} onChange={set('phone')} />
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Password" htmlFor="password" error={errors.password}>
            <Input
              id="password"
              type={show ? 'text' : 'password'}
              autoComplete="new-password"
              placeholder="6+ characters"
              icon={<Lock className="h-4 w-4" />}
              value={form.password}
              invalid={!!errors.password}
              onChange={set('password')}
              rightSlot={
                <button type="button" onClick={() => setShow((s) => !s)} aria-label={show ? 'Hide passwords' : 'Show passwords'} className="rounded-lg p-2 text-muted transition hover:text-white">
                  {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              }
            />
          </Field>
          <Field label="Confirm password" htmlFor="confirm" error={errors.confirm}>
            <Input id="confirm" type={show ? 'text' : 'password'} autoComplete="new-password" placeholder="Repeat it" icon={<Lock className="h-4 w-4" />} value={form.confirm} invalid={!!errors.confirm} onChange={set('confirm')} />
          </Field>
        </div>
        <Button type="submit" size="lg" className="mt-2 w-full" loading={loading}>
          Create account
        </Button>
      </form>

      <p className="mt-6 text-center text-sm text-muted">
        Already have an account?{' '}
        <Link to="/login" className="font-semibold text-white underline-offset-4 hover:underline">
          Log in
        </Link>
      </p>
    </div>
  );
}
