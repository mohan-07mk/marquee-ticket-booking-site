import type { ReactNode } from 'react';
import { cn } from '@/utils/cn';

type Tone = 'neutral' | 'brand' | 'success' | 'warning' | 'danger' | 'gold' | 'info';

const tones: Record<Tone, string> = {
  neutral: 'border-white/15 bg-white/10 text-white/85',
  brand: 'border-brand/40 bg-brand/15 text-red-300',
  success: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300',
  warning: 'border-amber-500/30 bg-amber-500/10 text-amber-300',
  danger: 'border-red-500/30 bg-red-500/10 text-red-300',
  gold: 'border-gold/40 bg-gold/10 text-gold',
  info: 'border-sky-500/30 bg-sky-500/10 text-sky-300',
};

export function Badge({ tone = 'neutral', className, children }: { tone?: Tone; className?: string; children: ReactNode }) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 whitespace-nowrap rounded-full border px-2.5 py-0.5 text-xs font-medium',
        tones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}

const statusMap: Record<string, { label: string; tone: Tone }> = {
  now_showing: { label: 'Now showing', tone: 'success' },
  coming_soon: { label: 'Coming soon', tone: 'info' },
  inactive: { label: 'Inactive', tone: 'neutral' },
  active: { label: 'Active', tone: 'success' },
  blocked: { label: 'Blocked', tone: 'danger' },
  confirmed: { label: 'Confirmed', tone: 'success' },
  completed: { label: 'Completed', tone: 'neutral' },
  cancelled: { label: 'Cancelled', tone: 'danger' },
};

export function StatusBadge({ status }: { status: string }) {
  const s = statusMap[status] ?? { label: status, tone: 'neutral' as Tone };
  return <Badge tone={s.tone}>{s.label}</Badge>;
}
