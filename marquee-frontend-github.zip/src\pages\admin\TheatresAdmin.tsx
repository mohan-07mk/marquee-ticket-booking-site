import { useMemo, useState } from 'react';
import { Film, Pencil, Plus, Search, Trash2 } from 'lucide-react';
import { AdminPageHeader, Toolbar } from '@/components/admin/AdminPageHeader';
import { CinemaScreenSettings } from '@/components/admin/CinemaScreenSettings';
import { DataTable, type Column } from '@/components/admin/DataTable';
import { TheatreFormModal } from '@/components/admin/TheatreFormModal';
import { StatusBadge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';
import { Input, Select } from '@/components/ui/Field';
import { ErrorState } from '@/components/ui/States';
import { useToast } from '@/context/ToastContext';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { api } from '@/services/api';
import type { Theatre } from '@/types';

export default function TheatresAdmin() {
  useDocumentTitle('Manage theatres');
  const toast = useToast();
  const { data, loading, error, reload } = useAsync(() => api.theatres.list({ includeInactive: true }), []);
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('all');
  const [editing, setEditing] = useState<Theatre | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [toDelete, setToDelete] = useState<Theatre | null>(null);
  const [busy, setBusy] = useState(false);

  const rows = useMemo(
    () =>
      (data ?? [])
        .filter((t) => !q.trim() || `${t.name} ${t.location}`.toLowerCase().includes(q.trim().toLowerCase()))
        .filter((t) => status === 'all' || t.status === status),
    [data, q, status],
  );

  const remove = async () => {
    if (!toDelete) return;
    setBusy(true);
    try {
      await api.theatres.remove(toDelete.id);
      toast.success('Theatre deleted', toDelete.name);
      setToDelete(null);
      reload();
    } catch (e) {
      toast.error('Couldn’t delete the theatre', e instanceof Error ? e.message : undefined);
    } finally {
      setBusy(false);
    }
  };

  const columns: Column<Theatre>[] = [
    {
      key: 'name',
      header: 'Theatre',
      mobile: 'title',
      cell: (t) => (
        <div>
          <p className="font-medium">{t.name}</p>
          <p className="text-xs text-muted">{t.location}</p>
        </div>
      ),
    },
    { key: 'screens', header: 'Screens', cell: (t) => t.screens.length },
    {
      key: 'screenViewLink',
      header: '3D Screen Video',
      cell: (t) => {
        const link = t.screenViewLink || (typeof window !== 'undefined' ? localStorage.getItem(`marquee.theatre_screen_link_${t.id}`) : '');
        return link ? (
          <span className="inline-flex items-center gap-1 rounded-md bg-brand/10 border border-brand/30 px-2 py-0.5 text-xs text-brand truncate max-w-[150px]" title={link}>
            <Film className="h-3 w-3 shrink-0" />
            Custom Video
          </span>
        ) : (
          <span className="text-xs text-muted">Movie Trailer</span>
        );
      },
    },
    { key: 'cap', header: 'Seats per screen', cell: (t) => t.screens.map((s) => s.capacity).join(', ') },
    { key: 'total', header: 'Total seats', cell: (t) => t.screens.reduce((s, x) => s + x.capacity, 0).toLocaleString('en-IN') },
    { key: 'status', header: 'Status', cell: (t) => <StatusBadge status={t.status} /> },
    {
      key: 'actions',
      header: 'Actions',
      mobile: 'actions',
      className: 'text-right',
      cell: (t) => (
        <div className="flex justify-end gap-1">
          <Button
            variant="ghost"
            size="icon"
            aria-label={`Edit ${t.name}`}
            onClick={() => {
              setEditing(t);
              setFormOpen(true);
            }}
          >
            <Pencil className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" aria-label={`Delete ${t.name}`} className="hover:text-red-400" onClick={() => setToDelete(t)}>
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <>
      <AdminPageHeader
        title="Theatre management"
        description="Venues, screens and how many seats each one holds."
        action={
          <Button
            leftIcon={<Plus className="h-4 w-4" />}
            onClick={() => {
              setEditing(null);
              setFormOpen(true);
            }}
          >
            Add theatre
          </Button>
        }
      />
      <Toolbar>
        <Input aria-label="Search theatres" placeholder="Search by name or location" icon={<Search className="h-4 w-4" />} value={q} onChange={(e) => setQ(e.target.value)} className="lg:w-80" />
        <Select aria-label="Status" value={status} onChange={(e) => setStatus(e.target.value)} className="lg:w-52">
          <option value="all">All statuses</option>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
        </Select>
      </Toolbar>

      {error ? <ErrorState message={error} onRetry={reload} /> : <DataTable columns={columns} rows={rows} rowKey={(t) => t.id} loading={loading && !data} emptyTitle="No theatres found" />}

      <div className="mt-10 border-t border-line/60 pt-8">
        <CinemaScreenSettings />
      </div>

      <TheatreFormModal open={formOpen} theatre={editing} onClose={() => setFormOpen(false)} onSaved={reload} />
      <ConfirmDialog
        open={!!toDelete}
        title="Delete this theatre?"
        description={toDelete ? `“${toDelete.name}” and all of its scheduled shows will be removed. This can’t be undone.` : ''}
        confirmLabel="Delete theatre"
        loading={busy}
        onConfirm={remove}
        onCancel={() => setToDelete(null)}
      />
    </>
  );
}
