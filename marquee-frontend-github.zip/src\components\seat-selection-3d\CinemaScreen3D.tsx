import { useEffect, useMemo, useRef, useState } from 'react';
import { Html } from '@react-three/drei';
import { useFrame, useThree } from '@react-three/fiber';
import { CanvasTexture, DoubleSide, PlaneGeometry, SRGBColorSpace, AdditiveBlending } from 'three';
import { YouTubeEmbed, type EmbedStatus } from '@/components/YouTubeEmbed';
import type { YouTubeInfo } from '@/utils/youtube';
import type { AuditoriumLayout } from './seatLayout';

export type ScreenStatus = 'default' | 'loading' | 'playing' | 'error';

interface Props {
  layout: AuditoriumLayout;
  video: YouTubeInfo | null;
  title: string;
  subtitle: string;
  /** When true the iframe receives clicks (play / pause / volume) instead of the camera. */
  interactive: boolean;
  onStatusChange?: (status: ScreenStatus, reason?: string) => void;
}

/**
 * The iframe is a fixed 1280x720 CSS box. drei's <Html transform> maps
 * 1 world unit to (400 / distanceFactor) CSS pixels, so this distanceFactor
 * makes the iframe exactly as wide as the 3D screen. If you ever change the
 * pixel size or screen width, this is the only number to recompute.
 */
const IFRAME_W = 1280;
const IFRAME_H = 720;
const CURTAIN = '#6f0d18';

export function CinemaScreen3D({ layout, video, title, subtitle, interactive, onStatusChange }: Props) {
  const { width, height, centerY, z } = layout.screen;
  const distanceFactor = (400 * width) / IFRAME_W;

  const [embed, setEmbed] = useState<{ status: EmbedStatus; reason?: string }>({ status: 'loading' });
  const holder = useRef<HTMLDivElement>(null);
  const gl = useThree((s) => s.gl);

  useEffect(() => setEmbed({ status: 'loading' }), [video?.embedUrl]);

  const screenStatus: ScreenStatus = !video ? 'default' : embed.status === 'error' ? 'error' : embed.status === 'ready' ? 'playing' : 'loading';
  const report = useRef(onStatusChange);
  report.current = onStatusChange;
  useEffect(() => {
    report.current?.(screenStatus, embed.reason);
  }, [screenStatus, embed.reason]);

  const showVideo = !!video && screenStatus !== 'error';
  const texture = useScreenTexture(screenStatus === 'error' ? 'error' : 'default', title, subtitle, embed.reason);

  // Let the iframe receive clicks while "Play on screen" is active.
  useEffect(() => {
    if (!interactive) return;
    const canvas = gl.domElement;
    const previous = canvas.style.pointerEvents;
    canvas.style.pointerEvents = 'none';
    return () => {
      canvas.style.pointerEvents = previous;
    };
  }, [interactive, gl]);

  // The iframe is a flat DOM layer, so hide it when the camera is behind the screen.
  useFrame(({ camera }) => {
    if (!holder.current) return;
    holder.current.style.visibility = camera.position.z > z + 0.15 ? 'visible' : 'hidden';
  });

  const curtainTop = centerY + height / 2 + 0.35;
  const sideW = layout.width / 2 - width / 2;
  const sideX = width / 2 + sideW / 2;
  const spill = useSpillTexture();

  return (
    <group position={[0, 0, z]}>
      {/* Housing and the screen surface */}
      <mesh position={[0, centerY, -0.17]} castShadow>
        <boxGeometry args={[width + 0.5, height + 0.5, 0.3]} />
        <meshStandardMaterial color="#07080a" roughness={0.5} metalness={0.5} />
      </mesh>
      <mesh position={[0, centerY, 0.004]}>
        <planeGeometry args={[width, height]} />
        <meshBasicMaterial map={texture} toneMapped={false} />
      </mesh>

      {/* Video: an iframe pinned to the screen plane. Camera moves keep it aligned. */}
      {showVideo && video && (
        <Html
          transform
          occlude="blending"
          position={[0, centerY, 0.02]}
          distanceFactor={distanceFactor}
          pointerEvents="none"
        >
          <div ref={holder} style={{ width: IFRAME_W, height: IFRAME_H, background: '#000' }}>
            <YouTubeEmbed
              embedUrl={video.embedUrl}
              title="Cinema screen video"
              style={{ width: '100%', height: '100%', pointerEvents: interactive ? 'auto' : 'none' }}
              onStatus={(status, reason) => setEmbed({ status, reason })}
            />
          </div>
        </Html>
      )}

      {/* Velvet curtains: side drapes and a pleated valance */}
      <Curtain width={sideW} height={layout.height - 0.4} position={[-sideX, (layout.height - 0.4) / 2, 0.06]} />
      <Curtain width={sideW} height={layout.height - 0.4} position={[sideX, (layout.height - 0.4) / 2, 0.06]} />
      <Curtain width={layout.width - 0.3} height={layout.height - curtainTop} position={[0, curtainTop + (layout.height - curtainTop) / 2, 0.08]} />

      {/* Soft light spilling from the screen onto the stage */}
      <mesh position={[0, 0.02, 2.4]} rotation={[-Math.PI / 2, 0, 0]} renderOrder={1}>
        <planeGeometry args={[width * 0.95, 4.6]} />
        <meshBasicMaterial map={spill} transparent opacity={0.55} blending={AdditiveBlending} depthWrite={false} toneMapped={false} />
      </mesh>
    </group>
  );
}

/* ---------------------------------------------------------------- */

function Curtain({ width, height, position }: { width: number; height: number; position: [number, number, number] }) {
  const geometry = useMemo(() => {
    const g = new PlaneGeometry(width, height, Math.max(8, Math.round(width / 0.1)), 1);
    const pos = g.attributes.position;
    for (let i = 0; i < pos.count; i++) pos.setZ(i, Math.sin(pos.getX(i) * 22) * 0.07);
    g.computeVertexNormals();
    return g;
  }, [width, height]);
  useEffect(() => () => geometry.dispose(), [geometry]);
  return (
    <mesh geometry={geometry} position={position} receiveShadow>
      <meshStandardMaterial color={CURTAIN} roughness={0.95} metalness={0} side={DoubleSide} />
    </mesh>
  );
}

function useSpillTexture() {
  const tex = useMemo(() => {
    const c = document.createElement('canvas');
    c.width = 256;
    c.height = 128;
    const ctx = c.getContext('2d')!;
    const g = ctx.createLinearGradient(0, 0, 0, 128);
    g.addColorStop(0, 'rgba(190,205,255,0.55)');
    g.addColorStop(1, 'rgba(190,205,255,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 256, 128);
    const t = new CanvasTexture(c);
    t.colorSpace = SRGBColorSpace;
    return t;
  }, []);
  useEffect(() => () => tex.dispose(), [tex]);
  return tex;
}

/** Draws the "default cinema screen" and the "video unavailable" cards. */
function useScreenTexture(kind: 'default' | 'error', title: string, subtitle: string, reason?: string) {
  const [fontsReady, setFontsReady] = useState(false);
  useEffect(() => {
    let alive = true;
    Promise.all([document.fonts.load('800 160px "Big Shoulders Display"'), document.fonts.load('500 40px "DM Sans"')])
      .catch(() => undefined)
      .then(() => alive && setFontsReady(true));
    return () => {
      alive = false;
    };
  }, []);

  const texture = useMemo(() => {
    void fontsReady; // redraw once the brand fonts are available
    const W = 1920;
    const H = 1080;
    const c = document.createElement('canvas');
    c.width = W;
    c.height = H;
    const ctx = c.getContext('2d')!;

    const bg = ctx.createRadialGradient(W / 2, H * 0.42, 60, W / 2, H / 2, W * 0.75);
    bg.addColorStop(0, kind === 'error' ? '#2a1013' : '#3b0d14');
    bg.addColorStop(0.55, '#0d0709');
    bg.addColorStop(1, '#000000');
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, W, H);

    // projector beam
    const beam = ctx.createLinearGradient(0, 0, 0, H);
    beam.addColorStop(0, 'rgba(225,29,46,0.0)');
    beam.addColorStop(1, 'rgba(225,29,46,0.16)');
    ctx.fillStyle = beam;
    ctx.beginPath();
    ctx.moveTo(W * 0.42, 0);
    ctx.lineTo(W * 0.58, 0);
    ctx.lineTo(W * 0.86, H);
    ctx.lineTo(W * 0.14, H);
    ctx.fill();

    ctx.textAlign = 'center';
    ctx.textBaseline = 'alphabetic';
    ctx.fillStyle = '#ffffff';

    if (kind === 'error') {
      ctx.font = '800 150px "Big Shoulders Display", Impact, sans-serif';
      ctx.fillText('Video unavailable', W / 2, H * 0.47);
      ctx.fillStyle = 'rgba(255,255,255,0.72)';
      ctx.font = '500 48px "DM Sans", system-ui, sans-serif';
      ctx.fillText(reason ?? 'This video can’t be played on the cinema screen.', W / 2, H * 0.47 + 84);
      ctx.fillText('Your seat selection is not affected.', W / 2, H * 0.47 + 150);
    } else {
      ctx.font = '800 330px "Big Shoulders Display", Impact, sans-serif';
      ctx.fillText('MARQUEE', W / 2, H * 0.52);
      ctx.fillStyle = '#e11d2e';
      ctx.fillRect(W / 2 - 90, H * 0.52 + 36, 180, 6);
      ctx.fillStyle = 'rgba(255,255,255,0.92)';
      ctx.font = '700 84px "Big Shoulders Display", Impact, sans-serif';
      ctx.fillText(fit(ctx, title, W * 0.8), W / 2, H * 0.52 + 150);
      ctx.fillStyle = 'rgba(255,255,255,0.6)';
      ctx.font = '500 44px "DM Sans", system-ui, sans-serif';
      ctx.fillText(fit(ctx, subtitle, W * 0.8), W / 2, H * 0.52 + 222);
    }
    const t = new CanvasTexture(c);
    t.colorSpace = SRGBColorSpace;
    t.anisotropy = 8;
    return t;
  }, [kind, title, subtitle, reason, fontsReady]);

  useEffect(() => () => texture.dispose(), [texture]);
  return texture;
}

function fit(ctx: CanvasRenderingContext2D, text: string, maxWidth: number) {
  if (ctx.measureText(text).width <= maxWidth) return text;
  let t = text;
  while (t.length > 1 && ctx.measureText(`${t}…`).width > maxWidth) t = t.slice(0, -1);
  return `${t}…`;
}
