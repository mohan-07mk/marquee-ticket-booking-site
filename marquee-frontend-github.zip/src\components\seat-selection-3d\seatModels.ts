import { BufferGeometry, BoxGeometry, Euler, Matrix4, MeshStandardMaterial, Quaternion, RingGeometry, Vector3 } from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';

/**
 * Seat meshes are authored once and merged into two geometries per seat type
 * (upholstery + trim), so a 140-seat hall draws a few hundred meshes instead of
 * thousands. The seat faces -z (toward the screen); its origin is the floor
 * point under the centre of the cushion.
 */
export type SeatVisual = 'available' | 'selected' | 'booked' | 'unavailable';

export interface SeatGeometries {
  fabric: BufferGeometry;
  trim: BufferGeometry;
  /** Local tilt of the backrest, used to place number plates on it. */
  backTilt: number;
  backPosition: [number, number, number];
  plateY: number;
  backDepth: number;
}

const rounded = (w: number, h: number, d: number, r: number) => new RoundedBoxGeometry(w, h, d, 3, r);
const box = (w: number, h: number, d: number) => new BoxGeometry(w, h, d);

function at(g: BufferGeometry, x: number, y: number, z: number, rx = 0): BufferGeometry {
  const m = new Matrix4().compose(new Vector3(x, y, z), new Quaternion().setFromEuler(new Euler(rx, 0, 0)), new Vector3(1, 1, 1));
  g.applyMatrix4(m);
  return g;
}

function merge(parts: BufferGeometry[]): BufferGeometry {
  // Primitive geometries all carry position/normal/uv and are indexed, which mergeGeometries requires.
  const merged = mergeGeometries(parts, false);
  parts.forEach((p) => p.dispose());
  if (!merged) throw new Error('Seat geometry merge failed');
  return merged;
}

function buildStandard(): SeatGeometries {
  const tilt = 0.14;
  const fabric = merge([
    at(rounded(0.5, 0.13, 0.52, 0.05), 0, 0.46, 0),
    at(rounded(0.52, 0.68, 0.12, 0.05), 0, 0.86, 0.28, tilt),
    at(rounded(0.07, 0.07, 0.5, 0.03), -0.285, 0.66, 0.02),
    at(rounded(0.07, 0.07, 0.5, 0.03), 0.285, 0.66, 0.02),
  ]);
  const trim = merge([
    at(box(0.12, 0.28, 0.3), 0, 0.22, 0.12),
    at(box(0.4, 0.03, 0.4), 0, 0.015, 0.1),
    at(box(0.04, 0.2, 0.05), -0.285, 0.56, 0.14),
    at(box(0.04, 0.2, 0.05), 0.285, 0.56, 0.14),
  ]);
  return { fabric, trim, backTilt: tilt, backPosition: [0, 0.86, 0.28], plateY: 0.2, backDepth: 0.06 };
}

function buildPremium(): SeatGeometries {
  const tilt = 0.28;
  const fabric = merge([
    at(rounded(0.5, 0.16, 0.56, 0.06), 0, 0.5, -0.02),
    at(rounded(0.5, 0.9, 0.15, 0.07), 0, 0.97, 0.3, tilt),
    at(rounded(0.36, 0.2, 0.1, 0.04), 0, 1.4, 0.4, tilt),
    at(rounded(0.08, 0.09, 0.56, 0.035), -0.29, 0.72, 0.0),
    at(rounded(0.08, 0.09, 0.56, 0.035), 0.29, 0.72, 0.0),
    at(rounded(0.42, 0.08, 0.34, 0.035), 0, 0.3, -0.52, -0.22),
  ]);
  const trim = merge([
    at(box(0.2, 0.3, 0.34), 0, 0.24, 0.12),
    at(box(0.46, 0.03, 0.46), 0, 0.015, 0.1),
    at(box(0.5, 0.014, 0.014), 0, 0.585, -0.3),
    at(box(0.05, 0.2, 0.06), -0.29, 0.6, 0.12),
    at(box(0.05, 0.2, 0.06), 0.29, 0.6, 0.12),
    at(box(0.09, 0.012, 0.4), -0.29, 0.772, 0.0),
    at(box(0.09, 0.012, 0.4), 0.29, 0.772, 0.0),
  ]);
  return { fabric, trim, backTilt: tilt, backPosition: [0, 0.97, 0.3], plateY: 0.28, backDepth: 0.077 };
}

let standard: SeatGeometries | null = null;
let premium: SeatGeometries | null = null;
export const getSeatGeometries = (isPremium: boolean): SeatGeometries =>
  isPremium ? (premium ??= buildPremium()) : (standard ??= buildStandard());

export const haloGeometry = new RingGeometry(0.3, 0.4, 40);

/* ---------- Materials: shared by every seat in the same state ---------- */
export interface SeatMaterialSet {
  fabric: MeshStandardMaterial;
  trim: MeshStandardMaterial;
}
export type SeatMaterialMap = Record<`${'standard' | 'premium'}:${SeatVisual}`, SeatMaterialSet>;

const std = (color: string, extra: Partial<ConstructorParameters<typeof MeshStandardMaterial>[0]> = {}) =>
  new MeshStandardMaterial({ color, roughness: 0.82, metalness: 0.02, ...extra });

export function createSeatMaterials(): SeatMaterialMap {
  const gold = '#f5b942';
  const goldTrim = () => std(gold, { metalness: 0.75, roughness: 0.32 });
  const darkTrim = (c = '#1b1d22') => std(c, { roughness: 0.6, metalness: 0.3 });
  const red = (strength: number) => std('#e11d2e', { emissive: '#e11d2e', emissiveIntensity: strength, roughness: 0.6 });

  return {
    'standard:available': { fabric: std('#646b79'), trim: darkTrim() },
    'standard:selected': { fabric: red(0.42), trim: darkTrim('#5a0c15') },
    'standard:booked': { fabric: std('#23252a', { roughness: 1 }), trim: darkTrim('#131417') },
    'standard:unavailable': { fabric: std('#3b3d43', { roughness: 1 }), trim: darkTrim('#1a1b1f') },
    'premium:available': { fabric: std('#4b3a26', { roughness: 0.55, metalness: 0.08 }), trim: goldTrim() },
    'premium:selected': { fabric: red(0.42), trim: goldTrim() },
    'premium:booked': { fabric: std('#24211d', { roughness: 1 }), trim: darkTrim('#15130f') },
    'premium:unavailable': { fabric: std('#3a3733', { roughness: 1 }), trim: darkTrim('#1c1b19') },
  };
}

export function disposeSeatMaterials(map: SeatMaterialMap) {
  Object.values(map).forEach((set) => {
    set.fabric.dispose();
    set.trim.dispose();
  });
}
