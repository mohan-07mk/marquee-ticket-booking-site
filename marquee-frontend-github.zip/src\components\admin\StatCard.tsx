import type { LucideIcon } from 'lucide-react';
import { TrendingDown, TrendingUp } from 'lucide-react';
import { cn } from '@/utils/cn';
import { Skeleton } from '../ui/Skeleton';

interface StatCardProps {
  label: string;
  value: string;
  icon: LucideIcon;
  delta?: number;
  deltaLabel?: string;
  loading?: boolean;
}

export function StatCard({ label, value, icon: Icon, delta, deltaLabel = 'vs previous 14 days', loading }: StatCardProps) {
  return (
    <div className="rounded-3xl border border-line bg-surface p-5">
      <div className="flex items-start justify-between">
        <p className="text-sm text-muted">{label}</p>
        <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand/15 text-brand-hover">
          <Icon className="h-5 w-5" />
        </span>
      </div>
      {loading ? (
        <Skeleton className="mt-3 h-10 w-32" />
      ) : (
        <p className="mt-2 font-display text-5xl font-extrabold leading-none">{value}</p>
      )}
      {delta !== undefined && !loading && (
        <p className={cn('mt-3 flex items-center gap-1.5 text-xs', delta >= 0 ? 'text-emerald-400' : 'text-red-400')}>
          {delta >= 0 ? <TrendingUp className="h-3.5 w-3.5" /> : <TrendingDown className="h-3.5 w-3.5" />}
          <span className="font-semibold">
            {delta >= 0 ? '+' : ''}
            {delta}%
          </span>
          <span className="text-muted">{deltaLabel}</span>
        </p>
      )}
    </div>
  );
}
