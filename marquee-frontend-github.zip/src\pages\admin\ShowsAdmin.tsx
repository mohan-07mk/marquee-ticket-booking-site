import { useMemo, useState } from 'react';
import { Ban, CheckCircle2, Pencil, Plus, Search, Trash2 } from 'lucide-react';
import { AdminPageHeader, Toolbar } from '@/components/admin/AdminPageHeader';
import { DataTable, type Column } from '@/components/admin/DataTable';
import { ShowFormModal } from '@/components/admin/ShowFormModal';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';
import { Input, Select } from '@/components/ui/Field';
import { ErrorState } from '@/components/ui/States';
import { useToast } from '@/context/ToastContext';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { api } from '@/services/api';
import type { Show } from '@/types';
import { formatCurrency, formatDate, formatTime } from '@/utils/format';

export default function ShowsAdmin() {
  useDocumentTitle('Manage shows');
  const toast = useToast();
  const { data, loading, error, reload } = useAsync(async () => {
    const [shows, movies, theatres] = await Promise.all([
      api.shows.list(),
      api.movies.list({ includeInactive: true }),
      api.theatres.list({ includeInactive: true }),
    ]);
    return { shows, movies, theatres };
  }, []);

  const [q, setQ] = useState('');
  const [status, setStatus] = useState('all');
  const [date, setDate] = useState('');
  const [editing, setEditing] = useState<Show | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [toDelete, setToDelete] = useState<Show | null>(null);
  const [busy, setBusy] = useState(false);

  const movieName = (id: string) => data?.movies.find((m) => m.id === id)?.title ?? 'Unknown movie';
  const theatreOf = (id: string) => data?.theatres.find((t) => t.id === id);

  const rows = useMemo(() => {
    const term = q.trim().toLowerCase();
    return (data?.shows ?? []).filter((s) => {
      const hay = `${data?.movies.find((m) => m.id === s.movieId)?.title ?? ''} ${data?.theatres.find((t) => t.id === s.theatreId)?.name ?? ''}`.toLowerCase();
      return (!term || hay.includes(term)) && (status === 'all' || s.status === status) && (!date || s.date === date);
    });
  }, [data, q, status, date]);

  const toggleStatus = async (s: Show) => {
    const next = s.status === 'active' ? 'cancelled' : 'active';
    try {
      await api.shows.update(s.id, { status: next });
      toast.success(next === 'cancelled' ? 'Show cancelled' : 'Show reactivated', movieName(s.movieId));
      reload();
    } catch (e) {
      toast.error('Couldn’t update the show', e instanceof Error ? e.message : undefined);
    }
  };

  const remove = async () => {
    if (!toDelete) return;
    setBusy(true);
    try {
      await api.shows.remove(toDelete.id);
      toast.success('Show deleted');
      setToDelete(null);
      reload();
    } catch (e) {
      toast.error('Couldn’t delete the show', e instanceof Error ? e.message : undefined);
    } finally {
      setBusy(false);
    }
  };

  const columns: Column<Show>[] = [
    { key: 'movie', header: 'Movie', mobile: 'title', cell: (s) => <span className="font-medium">{movieName(s.movieId)}</span> },
    {
      key: 'theatre',
      header: 'Theatre',
      cell: (s) => {
        const t = theatreOf(s.theatreId);
        return (
          <div>
            <p>{t?.name ?? 'Unknown'}</p>
            <p className="text-xs text-muted">{t?.screens.find((x) => x.id === s.screenId)?.name}</p>
          </div>
        );
      },
    },
    { key: 'date', header: 'Date', cell: (s) => formatDate(s.date) },
    { key: 'time', header: 'Time', cell: (s) => formatTime(s.time) },
    { key: 'format', header: 'Format', cell: (s) => <Badge tone={s.format === 'IMAX' ? 'brand' : 'neutral'}>{s.format}</Badge> },
    { key: 'price', header: 'Price', cell: (s) => formatCurrency(s.price) },
    { key: 'status', header: 'Status', cell: (s) => (s.status === 'active' ? <Badge tone="success">Active</Badge> : <Badge tone="danger">Cancelled</Badge>) },
    {
      key: 'actions',
      header: 'Actions',
      mobile: 'actions',
      className: 'text-right',
      cell: (s) => (
        <div className="flex justify-end gap-1">
          <Button
            variant="ghost"
            size="icon"
            aria-label="Edit show"
            onClick={() => {
              setEditing(s);
              setFormOpen(true);
            }}
          >
            <Pencil className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" aria-label={s.status === 'active' ? 'Cancel show' : 'Reactivate show'} onClick={() => toggleStatus(s)}>
            {s.status === 'active' ? <Ban className="h-4 w-4" /> : <CheckCircle2 className="h-4 w-4" />}
          </Button>
          <Button variant="ghost" size="icon" aria-label="Delete show" className="hover:text-red-400" onClick={() => setToDelete(s)}>
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <>
      <AdminPageHeader
        title="Show management"
        description="Schedule screenings and set ticket prices."
        action={
          <Button
            leftIcon={<Plus className="h-4 w-4" />}
            disabled={!data}
            onClick={() => {
              setEditing(null);
              setFormOpen(true);
            }}
          >
            Add show
          </Button>
        }
      />
      <Toolbar>
        <Input aria-label="Search shows" placeholder="Search by movie or theatre" icon={<Search className="h-4 w-4" />} value={q} onChange={(e) => setQ(e.target.value)} className="lg:w-80" />
        <Input aria-label="Filter by date" type="date" value={date} onChange={(e) => setDate(e.target.value)} className="lg:w-48" />
        <Select aria-label="Status" value={status} onChange={(e) => setStatus(e.target.value)} className="lg:w-44">
          <option value="all">All statuses</option>
          <option value="active">Active</option>
          <option value="cancelled">Cancelled</option>
        </Select>
        {(q || date || status !== 'all') && (
          <Button
            variant="ghost"
            onClick={() => {
              setQ('');
              setDate('');
              setStatus('all');
            }}
          >
            Clear filters
          </Button>
        )}
      </Toolbar>

      {error ? (
        <ErrorState message={error} onRetry={reload} />
      ) : (
        <DataTable columns={columns} rows={rows} rowKey={(s) => s.id} loading={loading && !data} pageSize={10} emptyTitle="No shows match" />
      )}

      {data && <ShowFormModal open={formOpen} show={editing} movies={data.movies} theatres={data.theatres} onClose={() => setFormOpen(false)} onSaved={reload} />}
      <ConfirmDialog
        open={!!toDelete}
        title="Delete this show?"
        description={toDelete ? `The ${formatTime(toDelete.time)} show of ${movieName(toDelete.movieId)} on ${formatDate(toDelete.date)} will be removed. Existing bookings for it are not refunded automatically.` : ''}
        confirmLabel="Delete show"
        loading={busy}
        onConfirm={remove}
        onCancel={() => setToDelete(null)}
      />
    </>
  );
}
