import { Link } from 'react-router-dom';
import { Ticket } from 'lucide-react';
import { cn } from '@/utils/cn';

export function Logo({ className, to = '/' }: { className?: string; to?: string }) {
  return (
    <Link to={to} className={cn('group inline-flex items-center gap-2.5', className)} aria-label="Marquee home">
      <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand shadow-[0_8px_22px_-8px_rgba(225,29,46,.9)] transition group-hover:rotate-[-6deg]">
        <Ticket className="h-5 w-5 -rotate-[30deg]" />
      </span>
      <span className="font-display text-[28px] font-extrabold leading-none tracking-wide">Marquee</span>
    </Link>
  );
}
