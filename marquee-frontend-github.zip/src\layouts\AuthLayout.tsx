import { useEffect, useState } from 'react';
import { Outlet } from 'react-router-dom';
import { Logo } from '@/components/Logo';
import { ScrollToTop } from '@/components/ScrollToTop';
import { api } from '@/services/api';
import type { Movie } from '@/types';

export function AuthLayout() {
  const [posters, setPosters] = useState<Movie[]>([]);

  useEffect(() => {
    api.movies.list().then((all) => {
      setPosters(all.filter((m) => m.status === 'now_showing').slice(0, 6));
    }).catch(() => {/* ignore */});
  }, []);

  return (
    <div className="grid min-h-screen lg:grid-cols-[1.05fr_1fr]">
      <ScrollToTop />
      <aside className="relative hidden overflow-hidden border-r border-line lg:block">
        <div className="absolute inset-0 grid -rotate-6 scale-125 grid-cols-3 gap-4 p-6 opacity-70">
          {posters.map((m, i) => (
            <img
              key={m.id}
              src={m.posterUrl}
              alt=""
              className={`aspect-[2/3] w-full rounded-2xl object-cover ${i % 3 === 1 ? 'translate-y-10' : i % 3 === 2 ? '-translate-y-6' : ''}`}
            />
          ))}
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-black/30" />
        <div className="relative flex h-full flex-col justify-between p-12">
          <Logo />
          <div className="max-w-md">
            <h2 className="font-display text-6xl font-extrabold leading-[0.95]">Your seat is waiting.</h2>
            <p className="mt-4 text-lg text-white/70">Book in under a minute, get your ticket instantly, and skip the queue at the counter.</p>
          </div>
        </div>
      </aside>

      <main className="flex flex-col px-5 py-8 sm:px-10">
        <div className="lg:hidden">
          <Logo />
        </div>
        <div className="mx-auto flex w-full max-w-md flex-1 flex-col justify-center py-10">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
