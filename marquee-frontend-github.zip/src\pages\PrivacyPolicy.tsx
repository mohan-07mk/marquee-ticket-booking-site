import { Link } from 'react-router-dom';
import { ChevronLeft, Cookie, CreditCard, Lock, Mail, ShieldCheck } from 'lucide-react';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { useCookieConsent } from '@/context/CookieContext';

export default function PrivacyPolicy() {
  useDocumentTitle('Privacy Policy | Marquee');
  const { openSettings } = useCookieConsent();

  return (
    <div className="container-page py-10 sm:py-16">
      <Link
        to="/"
        className="mb-6 inline-flex items-center gap-1 text-sm text-muted transition hover:text-white"
      >
        <ChevronLeft className="h-4 w-4" />
        Back to Home
      </Link>

      <div className="mx-auto max-w-4xl">
        <header className="mb-10 border-b border-line pb-8">
          <div className="inline-flex items-center gap-2 rounded-full border border-red-500/20 bg-red-500/10 px-3 py-1 text-xs font-semibold text-red-400">
            <ShieldCheck className="h-3.5 w-3.5" /> Legal & Privacy
          </div>
          <h1 className="mt-3 font-display text-4xl font-extrabold tracking-tight text-white sm:text-5xl">
            Privacy Policy
          </h1>
          <p className="mt-2 text-sm text-muted sm:text-base">
            Last updated: September 23, 2026. Learn how Marquee handles your personal information, booking details, and privacy.
          </p>
        </header>

        <div className="space-y-10 text-sm leading-relaxed text-muted sm:text-base">
          {/* Section 1: Introduction */}
          <section className="rounded-3xl border border-line bg-surface/60 p-6 sm:p-8">
            <h2 className="font-display text-xl font-bold text-white sm:text-2xl">1. Introduction</h2>
            <p className="mt-3">
              Welcome to Marquee Cinemas (&quot;Marquee&quot;, &quot;we&quot;, &quot;us&quot;, or &quot;our&quot;). We respect your privacy and are committed to protecting the personal information you share with us. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website or use our online movie ticket booking platform.
            </p>
          </section>

          {/* Section 2: Information We Collect */}
          <section className="rounded-3xl border border-line bg-surface/60 p-6 sm:p-8">
            <h2 className="font-display text-xl font-bold text-white sm:text-2xl">2. Information We Collect</h2>
            <p className="mt-3">
              We collect information that you provide directly to us when using our platform, as well as data automatically generated during your browsing and booking sessions.
            </p>

            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <div className="rounded-2xl border border-line bg-white/[0.02] p-4">
                <h3 className="font-semibold text-white">3. Account Information</h3>
                <p className="mt-1.5 text-xs text-muted sm:text-sm">
                  When you register or log in, we collect your name, email address, and authentication credentials securely managed via Supabase Auth.
                </p>
              </div>

              <div className="rounded-2xl border border-line bg-white/[0.02] p-4">
                <h3 className="font-semibold text-white">4. Booking Information</h3>
                <p className="mt-1.5 text-xs text-muted sm:text-sm">
                  Movie selection, showtimes, theatre locations, screen details, seat selections, ticket quantities, and unique booking references (e.g. MQ-XXXXXXXX).
                </p>
              </div>
            </div>
          </section>

          {/* Section 5 & 6: Payment Information & How Payments Are Processed */}
          <section className="rounded-3xl border border-line bg-surface/60 p-6 sm:p-8">
            <div className="flex items-center gap-3">
              <div className="rounded-xl bg-red-500/10 p-2 text-red-400">
                <CreditCard className="h-5 w-5" />
              </div>
              <h2 className="font-display text-xl font-bold text-white sm:text-2xl">
                5. Payment Information &amp; 6. Processing
              </h2>
            </div>

            <div className="mt-4 space-y-3">
              <p>
                All online payments on Marquee are securely processed through our authorized payment gateway partner, <strong>Razorpay Software Private Limited</strong>.
              </p>
              <div className="rounded-2xl border border-amber-500/20 bg-amber-500/5 p-4 text-xs text-amber-200/90 sm:text-sm">
                <strong className="text-white">Zero Raw Financial Data Storage:</strong> Marquee does <em>NOT</em> collect, process, or store raw credit/debit card numbers, CVVs, expiry dates, net banking passwords, or UPI PINs on our servers. All sensitive financial data is entered directly into Razorpay&apos;s encrypted checkout interface.
              </div>
              <p>
                We only receive transaction status notifications, payment IDs (e.g. <code className="text-white">pay_XXXXXXXX</code>), order IDs, and payment method summaries (e.g. UPI, Card) to verify payment completion and generate your ticket.
              </p>
            </div>
          </section>

          {/* Section 7: Cookies */}
          <section className="rounded-3xl border border-line bg-surface/60 p-6 sm:p-8">
            <div className="flex items-center gap-3">
              <div className="rounded-xl bg-red-500/10 p-2 text-red-400">
                <Cookie className="h-5 w-5" />
              </div>
              <h2 className="font-display text-xl font-bold text-white sm:text-2xl">7. Cookies &amp; Local Preferences</h2>
            </div>
            <p className="mt-3">
              We use essential cookies and local storage tokens to maintain your login session, manage active seat reservations during checkout, and store your cookie consent choices (<code className="text-white">marquee_cookie_consent</code>).
            </p>
            <p className="mt-3">
              Optional analytics cookies are disabled by default and will only be activated if explicitly permitted by you. You can adjust your choices anytime:
            </p>
            <div className="mt-4">
              <button
                type="button"
                onClick={openSettings}
                className="inline-flex items-center justify-center rounded-xl border border-line bg-white/5 px-4 py-2 text-xs font-medium text-white transition hover:bg-white/10"
              >
                Manage Cookie Preferences
              </button>
            </div>
          </section>

          {/* Section 8: How We Use Information */}
          <section className="rounded-3xl border border-line bg-surface/60 p-6 sm:p-8">
            <h2 className="font-display text-xl font-bold text-white sm:text-2xl">8. How We Use Information</h2>
            <ul className="mt-3 list-disc space-y-2 pl-5">
              <li>To confirm seat reservations and issue valid digital movie tickets.</li>
              <li>To send instant transactional booking confirmation emails containing ticket details.</li>
              <li>To verify payment signatures and prevent fraudulent bookings or double-reservations.</li>
              <li>To provide customer support and resolve payment or booking conflicts.</li>
              <li>To maintain the security and operational integrity of the Marquee platform.</li>
            </ul>
          </section>

          {/* Section 9 & 10: Data Sharing & Third-Party Services */}
          <section className="rounded-3xl border border-line bg-surface/60 p-6 sm:p-8">
            <h2 className="font-display text-xl font-bold text-white sm:text-2xl">
              9. Data Sharing &amp; 10. Third-Party Services
            </h2>
            <p className="mt-3">
              We do not sell, rent, or trade your personal information. We share minimal necessary data strictly with trusted service providers essential for operating Marquee:
            </p>
            <div className="mt-4 space-y-3">
              <div className="rounded-xl border border-line bg-white/[0.02] p-3.5">
                <strong className="text-white">Supabase Inc.</strong> — Provides database hosting, backend services, and secure user authentication.
              </div>
              <div className="rounded-xl border border-line bg-white/[0.02] p-3.5">
                <strong className="text-white">Razorpay Software Pvt Ltd</strong> — Processes secure online payments and signature verification.
              </div>
              <div className="rounded-xl border border-line bg-white/[0.02] p-3.5">
                <strong className="text-white">Resend Technologies Inc.</strong> — Dispatches transactional booking confirmation emails directly to your registered email address.
              </div>
            </div>
          </section>

          {/* Section 11 & 12: Data Security & Retention */}
          <section className="rounded-3xl border border-line bg-surface/60 p-6 sm:p-8">
            <div className="flex items-center gap-3">
              <div className="rounded-xl bg-red-500/10 p-2 text-red-400">
                <Lock className="h-5 w-5" />
              </div>
              <h2 className="font-display text-xl font-bold text-white sm:text-2xl">
                11. Data Security &amp; 12. Retention
              </h2>
            </div>
            <p className="mt-3">
              We utilize TLS/HTTPS encryption for all data in transit, combined with strict Row Level Security (RLS) policies and server-side HMAC signature verification. Booking records are retained for historical ticket access in your account. Account data can be managed upon request.
            </p>
          </section>

          {/* Section 13, 14, 15, 16: Rights, Children, Changes, Contact */}
          <section className="rounded-3xl border border-line bg-surface/60 p-6 sm:p-8">
            <h2 className="font-display text-xl font-bold text-white sm:text-2xl">13. User Rights &amp; 14. Children&apos;s Privacy</h2>
            <p className="mt-3">
              You have the right to access your booking history, update account details, or request account deletion. Marquee does not knowingly collect personal data from children under 13 without parental consent.
            </p>

            <h3 className="mt-6 text-lg font-bold text-white">15. Changes to This Policy</h3>
            <p className="mt-2">
              We may update this Privacy Policy periodically. Any updates will be posted on this page with an updated modification date.
            </p>

            <h3 className="mt-6 text-lg font-bold text-white">16. Contact Information</h3>
            <p className="mt-2 flex items-center gap-2">
              <Mail className="h-4 w-4 text-red-400" />
              For privacy inquiries or support, contact us at: <a href="mailto:support@marquee.com" className="text-white underline hover:text-red-400">support@marquee.com</a>
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
