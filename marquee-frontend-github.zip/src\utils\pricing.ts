import type { Format, Seat } from '@/types';

/** Flat per-ticket fee. Move this to a config table / edge function later. */
export const CONVENIENCE_FEE_PER_TICKET = 30;
export const MAX_SEATS_PER_BOOKING = 8;

const FORMAT_BASE: Record<Format, number> = { '2D': 170, '3D': 240, IMAX: 350 };
const THEATRE_BUMP: Record<string, number> = { t1: 30, t5: 40 };

export function standardPrice(format: Format, theatreId: string, time: string) {
  const evening = time >= '19:00' ? 20 : 0;
  return FORMAT_BASE[format] + (THEATRE_BUMP[theatreId] ?? 0) + evening;
}

export const premiumPriceFor = (price: number) => Math.round((price * 1.5) / 10) * 10;

export function calcTotals(seats: Pick<Seat, 'price'>[]) {
  const subtotal = seats.reduce((sum, s) => sum + s.price, 0);
  const convenienceFee = seats.length * CONVENIENCE_FEE_PER_TICKET;
  return { subtotal, convenienceFee, total: subtotal + convenienceFee };
}
