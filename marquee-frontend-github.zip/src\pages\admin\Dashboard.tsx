import { Link } from 'react-router-dom';
import { Film, IndianRupee, Ticket, Users } from 'lucide-react';
import { Area, AreaChart, Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { ChartCard, chartColors, tooltipStyle } from '@/components/admin/ChartCard';
import { StatCard } from '@/components/admin/StatCard';
import { StatusBadge } from '@/components/ui/Badge';
import { ErrorState } from '@/components/ui/States';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { api } from '@/services/api';
import { formatCompactCurrency, formatCurrency, formatDate } from '@/utils/format';

export default function Dashboard() {
  useDocumentTitle('Admin dashboard');
  const { data, loading, error, reload } = useAsync(() => api.admin.getDashboard(), []);

  if (error) return <ErrorState message={error} onRetry={reload} />;

  const t = data?.totals;
  const axis = { stroke: chartColors.axis, fontSize: 12, tickLine: false, axisLine: false } as const;

  return (
    <div className="space-y-6">
      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4" aria-label="Key numbers">
        <StatCard loading={loading} label="Total movies" value={String(t?.movies ?? 0)} icon={Film} />
        <StatCard loading={loading} label="Registered users" value={String(t?.users ?? 0)} icon={Users} />
        <StatCard loading={loading} label="Total bookings" value={(t?.bookings ?? 0).toLocaleString('en-IN')} icon={Ticket} delta={data?.deltas.bookings} />
        <StatCard loading={loading} label="Total revenue" value={formatCompactCurrency(t?.revenue ?? 0)} icon={IndianRupee} delta={data?.deltas.revenue} />
      </section>

      <div className="grid gap-6 xl:grid-cols-[1.4fr_1fr]">
        <ChartCard title="Booking trends" subtitle="Tickets booked per day, last 14 days" loading={loading}>
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={data?.daily} margin={{ top: 8, right: 8, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="bk" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={chartColors.brand} stopOpacity={0.5} />
                  <stop offset="100%" stopColor={chartColors.brand} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke={chartColors.grid} vertical={false} />
              <XAxis dataKey="label" {...axis} interval="preserveStartEnd" />
              <YAxis {...axis} allowDecimals={false} />
              <Tooltip {...tooltipStyle} formatter={(v) => [`${v} bookings`, '']} separator="" />
              <Area type="monotone" dataKey="bookings" stroke={chartColors.brand} strokeWidth={2.5} fill="url(#bk)" />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Popular movies" subtitle="By bookings, all time" loading={loading}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data?.popularMovies} layout="vertical" margin={{ top: 0, right: 12, left: 0, bottom: 0 }}>
              <CartesianGrid stroke={chartColors.grid} horizontal={false} />
              <XAxis type="number" {...axis} allowDecimals={false} />
              <YAxis type="category" dataKey="name" width={120} {...axis} />
              <Tooltip {...tooltipStyle} formatter={(v) => [`${v} bookings`, '']} separator="" />
              <Bar dataKey="bookings" fill={chartColors.brand} radius={[0, 8, 8, 0]} barSize={16} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <ChartCard title="Revenue trends" subtitle="Revenue per day, last 14 days" loading={loading}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data?.daily} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
            <CartesianGrid stroke={chartColors.grid} vertical={false} />
            <XAxis dataKey="label" {...axis} interval="preserveStartEnd" />
            <YAxis {...axis} tickFormatter={(v) => formatCompactCurrency(Number(v))} width={60} />
            <Tooltip {...tooltipStyle} formatter={(v) => [formatCurrency(Number(v)), '']} separator="" />
            <Bar dataKey="revenue" fill={chartColors.brand} radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      <section className="rounded-3xl border border-line bg-surface p-5">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-display text-2xl font-bold leading-none">Recent bookings</h3>
          <Link to="/admin/bookings" className="text-sm text-white/70 transition hover:text-white">
            View all
          </Link>
        </div>
        <ul className="divide-y divide-line">
          {(data?.recentBookings ?? []).map((b) => (
            <li key={b.id} className="flex flex-wrap items-center justify-between gap-3 py-3">
              <div className="flex min-w-0 items-center gap-3">
                <img src={b.posterUrl} alt="" className="h-12 w-8 shrink-0 rounded-md object-cover" />
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">{b.movieTitle}</p>
                  <p className="truncate text-xs text-muted">
                    {b.customerName}, {b.seats.length} seat{b.seats.length > 1 ? 's' : ''}, {formatDate(b.date)}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-sm font-semibold">{formatCurrency(b.amount)}</span>
                <StatusBadge status={b.status} />
              </div>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
