import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Ticket } from 'lucide-react';
import { BookingCard } from '@/components/BookingCard';
import { Button, buttonClasses } from '@/components/ui/Button';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';
import { Skeleton } from '@/components/ui/Skeleton';
import { EmptyState, ErrorState } from '@/components/ui/States';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { api } from '@/services/api';
import type { Booking } from '@/types';
import { cn } from '@/utils/cn';
import { hasShowStarted } from '@/utils/format';

export default function MyBookings() {
  useDocumentTitle('My bookings');
  const { user } = useAuth();
  const toast = useToast();
  const userId = user?.id ?? '';
  const { data, loading, error, reload } = useAsync(() => api.bookings.listForUser(userId), [userId]);
  const [tab, setTab] = useState<'upcoming' | 'past'>('upcoming');
  const [toCancel, setToCancel] = useState<Booking | null>(null);
  const [cancelling, setCancelling] = useState(false);

  const { upcoming, past } = useMemo(() => {
    const all = data ?? [];
    const isUpcoming = (b: Booking) => b.status !== 'cancelled' && !hasShowStarted(b.date, b.time);
    return {
      upcoming: all.filter(isUpcoming).sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time)),
      past: all.filter((b) => !isUpcoming(b)).sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time)),
    };
  }, [data]);

  const list = tab === 'upcoming' ? upcoming : past;

  const confirmCancel = async () => {
    if (!toCancel) return;
    setCancelling(true);
    try {
      await api.bookings.setStatus(toCancel.id, 'cancelled');
      toast.success('Booking cancelled', `${toCancel.movieTitle} on ${toCancel.date} has been cancelled.`);
      setToCancel(null);
      reload();
    } catch (e) {
      toast.error('Couldn’t cancel this booking', e instanceof Error ? e.message : undefined);
    } finally {
      setCancelling(false);
    }
  };

  return (
    <div className="container-page max-w-4xl py-10 sm:py-14">
      <header className="mb-8">
        <h1 className="font-display text-5xl font-extrabold leading-none sm:text-7xl">My bookings</h1>
        <p className="mt-3 text-muted">Your tickets, past and upcoming.</p>
      </header>

      <div role="tablist" aria-label="Booking type" className="mb-6 inline-flex rounded-2xl border border-line bg-surface p-1">
        {(['upcoming', 'past'] as const).map((t) => (
          <button
            key={t}
            role="tab"
            aria-selected={tab === t}
            onClick={() => setTab(t)}
            className={cn('rounded-xl px-5 py-2 text-sm font-semibold capitalize transition', tab === t ? 'bg-white text-black' : 'text-white/70 hover:text-white')}
          >
            {t}
            <span className={cn('ml-2 text-xs', tab === t ? 'text-black/60' : 'text-muted')}>{t === 'upcoming' ? upcoming.length : past.length}</span>
          </button>
        ))}
      </div>

      {error ? (
        <ErrorState message={error} onRetry={reload} />
      ) : loading && !data ? (
        <div className="space-y-4">
          {Array.from({ length: 3 }, (_, i) => (
            <Skeleton key={i} className="h-44" />
          ))}
        </div>
      ) : list.length === 0 ? (
        <EmptyState
          icon={Ticket}
          title={tab === 'upcoming' ? 'No upcoming shows' : 'No past bookings yet'}
          description={tab === 'upcoming' ? 'Book something you’ve been waiting to see.' : 'Once you’ve watched a film, it will show up here.'}
          action={
            tab === 'upcoming' ? (
              <Link to="/movies" className={buttonClasses()}>
                Browse movies
              </Link>
            ) : undefined
          }
        />
      ) : (
        <div className="space-y-4">
          {list.map((b) => (
            <BookingCard
              key={b.id}
              booking={b}
              actions={
                tab === 'upcoming' ? (
                  <Button variant="danger" size="sm" onClick={() => setToCancel(b)}>
                    Cancel booking
                  </Button>
                ) : undefined
              }
            />
          ))}
        </div>
      )}

      <ConfirmDialog
        open={!!toCancel}
        title="Cancel this booking?"
        description={toCancel ? `Your ${toCancel.seats.length} ticket${toCancel.seats.length > 1 ? 's' : ''} for ${toCancel.movieTitle} will be released. This can’t be undone.` : ''}
        confirmLabel="Yes, cancel booking"
        loading={cancelling}
        onConfirm={confirmCancel}
        onCancel={() => setToCancel(null)}
      />
    </div>
  );
}
