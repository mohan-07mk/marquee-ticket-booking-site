import { cn } from '@/utils/cn';
import { parseDateKey, todayKey } from '@/utils/format';

export function DateSelector({ dates, value, onChange }: { dates: string[]; value: string; onChange: (date: string) => void }) {
  const today = todayKey();
  return (
    <div className="no-scrollbar -mx-4 flex gap-2.5 overflow-x-auto px-4 pb-1 sm:mx-0 sm:px-0" role="tablist" aria-label="Select a date">
      {dates.map((d) => {
        const date = parseDateKey(d);
        const active = d === value;
        return (
          <button
            key={d}
            role="tab"
            aria-selected={active}
            onClick={() => onChange(d)}
            className={cn(
              'flex min-w-[72px] shrink-0 flex-col items-center rounded-2xl border px-4 py-2.5 transition duration-200',
              active ? 'border-brand bg-brand text-white shadow-[0_10px_26px_-12px_rgba(225,29,46,.9)]' : 'border-line bg-surface text-white/80 hover:border-white/40',
            )}
          >
            <span className={cn('text-xs font-medium', active ? 'text-white/85' : 'text-muted')}>
              {d === today ? 'Today' : date.toLocaleDateString('en-IN', { weekday: 'short' })}
            </span>
            <span className="font-display text-3xl font-bold leading-none">{date.getDate()}</span>
            <span className={cn('text-xs', active ? 'text-white/85' : 'text-muted')}>
              {date.toLocaleDateString('en-IN', { month: 'short' })}
            </span>
          </button>
        );
      })}
    </div>
  );
}
