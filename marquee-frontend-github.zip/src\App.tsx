import { BrowserRouter } from 'react-router-dom';
import { CookieConsentBanner } from '@/components/cookie/CookieConsentBanner';
import { CookieSettingsModal } from '@/components/cookie/CookieSettingsModal';
import { AuthProvider } from '@/context/AuthContext';
import { BookingProvider } from '@/context/BookingContext';
import { CinemaScreenProvider } from '@/context/CinemaScreenContext';
import { CookieProvider } from '@/context/CookieContext';
import { ToastProvider } from '@/context/ToastContext';
import { AppRoutes } from '@/routes';

export default function App() {
  return (
    <BrowserRouter>
      <ToastProvider>
        <AuthProvider>
          <BookingProvider>
            <CinemaScreenProvider>
              <CookieProvider>
                <AppRoutes />
                <CookieConsentBanner />
                <CookieSettingsModal />
              </CookieProvider>
            </CinemaScreenProvider>
          </BookingProvider>
        </AuthProvider>
      </ToastProvider>
    </BrowserRouter>
  );
}
