import { useMemo, useState } from 'react';
import { Eye, ShieldCheck, ShieldOff, Search } from 'lucide-react';
import { AdminPageHeader, Toolbar } from '@/components/admin/AdminPageHeader';
import { DataTable, type Column } from '@/components/admin/DataTable';
import { StatusBadge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';
import { Input, Select } from '@/components/ui/Field';
import { Modal } from '@/components/ui/Modal';
import { ErrorState } from '@/components/ui/States';
import { useToast } from '@/context/ToastContext';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { api } from '@/services/api';
import type { User } from '@/types';
import { formatDate, initials } from '@/utils/format';

export default function UsersAdmin() {
  useDocumentTitle('Manage users');
  const toast = useToast();
  const { data, loading, error, reload } = useAsync(() => api.users.list(), []);
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('all');
  const [viewing, setViewing] = useState<User | null>(null);
  const [toBlock, setToBlock] = useState<User | null>(null);
  const [busy, setBusy] = useState(false);

  const rows = useMemo(() => {
    const term = q.trim().toLowerCase();
    return (data ?? [])
      .filter((u) => !term || `${u.name} ${u.email} ${u.phone}`.toLowerCase().includes(term))
      .filter((u) => status === 'all' || u.status === status);
  }, [data, q, status]);

  const setUserStatus = async (u: User, next: 'active' | 'blocked') => {
    setBusy(true);
    try {
      await api.users.setStatus(u.id, next);
      toast.success(next === 'blocked' ? 'User blocked' : 'User unblocked', u.name);
      setToBlock(null);
      setViewing(null);
      reload();
    } catch (e) {
      toast.error('Couldn’t update the user', e instanceof Error ? e.message : undefined);
    } finally {
      setBusy(false);
    }
  };

  const columns: Column<User>[] = [
    {
      key: 'name',
      header: 'User',
      mobile: 'title',
      cell: (u) => (
        <div className="flex items-center gap-3">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-white/10 text-sm font-semibold">{initials(u.name)}</span>
          <div className="min-w-0">
            <p className="truncate font-medium">{u.name}</p>
            <p className="truncate text-xs text-muted">{u.email}</p>
          </div>
        </div>
      ),
    },
    { key: 'phone', header: 'Phone', cell: (u) => u.phone },
    { key: 'joined', header: 'Joined', cell: (u) => formatDate(u.joinedAt) },
    { key: 'bookings', header: 'Bookings', cell: (u) => u.totalBookings ?? 0 },
    { key: 'status', header: 'Status', cell: (u) => <StatusBadge status={u.status} /> },
    {
      key: 'actions',
      header: 'Actions',
      mobile: 'actions',
      className: 'text-right',
      cell: (u) => (
        <div className="flex justify-end gap-1">
          <Button variant="ghost" size="icon" aria-label={`View ${u.name}`} onClick={() => setViewing(u)}>
            <Eye className="h-4 w-4" />
          </Button>
          {u.status === 'active' ? (
            <Button variant="ghost" size="icon" aria-label={`Block ${u.name}`} className="hover:text-red-400" onClick={() => setToBlock(u)}>
              <ShieldOff className="h-4 w-4" />
            </Button>
          ) : (
            <Button variant="ghost" size="icon" aria-label={`Unblock ${u.name}`} className="hover:text-emerald-400" onClick={() => setUserStatus(u, 'active')}>
              <ShieldCheck className="h-4 w-4" />
            </Button>
          )}
        </div>
      ),
    },
  ];

  return (
    <>
      <AdminPageHeader title="User management" description="See who has signed up and block accounts that misuse the platform." />
      <Toolbar>
        <Input aria-label="Search users" placeholder="Search by name, email or phone" icon={<Search className="h-4 w-4" />} value={q} onChange={(e) => setQ(e.target.value)} className="lg:w-80" />
        <Select aria-label="Status" value={status} onChange={(e) => setStatus(e.target.value)} className="lg:w-52">
          <option value="all">All statuses</option>
          <option value="active">Active</option>
          <option value="blocked">Blocked</option>
        </Select>
      </Toolbar>

      {error ? <ErrorState message={error} onRetry={reload} /> : <DataTable columns={columns} rows={rows} rowKey={(u) => u.id} loading={loading && !data} emptyTitle="No users found" />}

      <Modal
        open={!!viewing}
        onClose={() => setViewing(null)}
        title={viewing?.name ?? 'User'}
        size="sm"
        footer={
          viewing && (
            <>
              <Button variant="ghost" onClick={() => setViewing(null)}>
                Close
              </Button>
              {viewing.status === 'active' ? (
                <Button variant="danger" onClick={() => setToBlock(viewing)}>
                  Block user
                </Button>
              ) : (
                <Button loading={busy} onClick={() => setUserStatus(viewing, 'active')}>
                  Unblock user
                </Button>
              )}
            </>
          )
        }
      >
        {viewing && (
          <dl className="space-y-3 text-sm">
            {[
              ['Email', viewing.email],
              ['Phone', viewing.phone],
              ['Joined', formatDate(viewing.joinedAt)],
              ['Bookings', String(viewing.totalBookings ?? 0)],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between gap-4 border-b border-line/60 pb-2">
                <dt className="text-muted">{k}</dt>
                <dd className="font-medium">{v}</dd>
              </div>
            ))}
            <div className="flex items-center justify-between pt-1">
              <dt className="text-muted">Status</dt>
              <dd>
                <StatusBadge status={viewing.status} />
              </dd>
            </div>
          </dl>
        )}
      </Modal>

      <ConfirmDialog
        open={!!toBlock}
        title="Block this user?"
        description={toBlock ? `${toBlock.name} will be marked as blocked and shouldn’t be able to make new bookings. You can unblock them at any time.` : ''}
        confirmLabel="Block user"
        loading={busy}
        onConfirm={() => toBlock && setUserStatus(toBlock, 'blocked')}
        onCancel={() => setToBlock(null)}
      />
    </>
  );
}
