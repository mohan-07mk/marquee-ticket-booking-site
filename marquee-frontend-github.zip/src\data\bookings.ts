import type { Booking, Format, PaymentMethod, Seat } from '@/types';
import { addDays, parseDateKey, toDateKey } from '@/utils/format';
import { calcTotals, premiumPriceFor, standardPrice } from '@/utils/pricing';
import { mulberry32 } from '@/utils/random';
import { movies } from './movies';
import { SHOW_SLOTS } from './shows';
import { theatres } from './theatres';
import { users } from './users';
import { rowLabel, PREMIUM_ROWS } from './seats';

/**
 * MOCK DATA - bookings (~6 months of history + a few upcoming ones).
 * The first 8 belong to the demo user (u1) so "My Bookings" is never empty.
 * Replace with: supabase.from('bookings').select('*')
 */
const PAYMENTS: PaymentMethod[] = ['upi', 'card', 'netbanking'];
const DEMO_OFFSETS = [-1, -3, -6, 2, 9, 16, 30, 48]; // negative = upcoming

export function generateBookings(total = 340): Booking[] {
  const rand = mulberry32(2026);
  const today = new Date();
  const customers = users.filter((u) => u.role === 'customer' && u.status === 'active');
  const playable = movies.filter((m) => m.status === 'now_showing');
  const totalPop = playable.reduce((s, m) => s + m.popularity, 0);
  const activeTheatres = theatres.filter((t) => t.status === 'active');
  const out: Booking[] = [];

  for (let i = 0; i < total; i++) {
    const forced = i < DEMO_OFFSETS.length;
    const rawDaysAgo = forced ? DEMO_OFFSETS[i] : Math.floor(Math.pow(rand(), 1.35) * 182) - 4;

    // Weighted movie pick by popularity
    let pick = rand() * totalPop;
    let movie = playable[0];
    for (const m of playable) {
      pick -= m.popularity;
      if (pick <= 0) {
        movie = m;
        break;
      }
    }

    // A film can't be booked before it was released.
    const sinceRelease = Math.round((today.getTime() - parseDateKey(movie.releaseDate).getTime()) / 86400000);
    const daysAgo = rawDaysAgo <= 0 ? rawDaysAgo : Math.min(rawDaysAgo, sinceRelease - Math.floor(rand() * 3));

    const theatre = activeTheatres[Math.floor(rand() * activeTheatres.length)];
    const compatible = theatre.screens.filter((s) => s.formats.some((f) => movie.formats.includes(f)));
    const screen = (compatible.length ? compatible : theatre.screens)[Math.floor(rand() * Math.max(1, compatible.length))];
    const formats = screen.formats.filter((f) => movie.formats.includes(f)) as Format[];
    const format = formats[Math.floor(rand() * formats.length)] ?? '2D';
    const time = SHOW_SLOTS[Math.floor(rand() * SHOW_SLOTS.length)];
    const price = standardPrice(format, theatre.id, time);

    // Seats: a consecutive block in one row
    const count = 1 + Math.floor(rand() * 4);
    const rowIndex = Math.floor(rand() * screen.rows);
    const startNo = 1 + Math.floor(rand() * (screen.seatsPerRow - count));
    const isPremium = rowIndex >= screen.rows - PREMIUM_ROWS;
    const seatIds = Array.from({ length: count }, (_, k) => `${rowLabel(rowIndex)}${startNo + k}`);
    const seatObjs: Pick<Seat, 'price'>[] = seatIds.map(() => ({ price: isPremium ? premiumPriceFor(price) : price }));
    const { subtotal, convenienceFee, total: amount } = calcTotals(seatObjs);

    const user = forced ? users[0] : customers[Math.floor(rand() * customers.length)];
    const showDate = addDays(today, -daysAgo);
    const createdAt = addDays(showDate, -(1 + Math.floor(rand() * 3)));
    if (createdAt > today) createdAt.setTime(today.getTime());

    const past = daysAgo > 0;
    const cancelled = !forced && rand() < 0.05;

    out.push({
      id: `MQ${(i * 7919 + 100003).toString(36).toUpperCase()}`,
      userId: user.id,
      customerName: user.name,
      movieId: movie.id,
      movieTitle: movie.title,
      posterUrl: movie.posterUrl,
      theatreId: theatre.id,
      theatreName: theatre.name,
      screenName: screen.name,
      showId: `sh-${movie.id}-${theatre.id}-${toDateKey(showDate)}-${time.replace(':', '')}`,
      date: toDateKey(showDate),
      time,
      format,
      seats: seatIds,
      subtotal,
      convenienceFee,
      amount,
      status: cancelled ? 'cancelled' : past ? 'completed' : 'confirmed',
      paymentMethod: PAYMENTS[Math.floor(rand() * PAYMENTS.length)],
      createdAt: createdAt.toISOString(),
    });
  }
  return out;
}

export const bookings: Booking[] = generateBookings();
