// supabase/functions/create-razorpay-order/index.ts
import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const RAZORPAY_KEY_ID = Deno.env.get('RAZORPAY_KEY_ID');
    const RAZORPAY_KEY_SECRET = Deno.env.get('RAZORPAY_KEY_SECRET');
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!RAZORPAY_KEY_ID || !RAZORPAY_KEY_SECRET) {
      return new Response(
        JSON.stringify({ error: 'Razorpay keys are missing in Supabase secret settings.' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 1. Extract User Authentication (supports authenticated users & guests)
    let user: any = null;
    const authHeader = req.headers.get('Authorization');

    const supabaseAdmin = createClient(
      SUPABASE_URL || '',
      SUPABASE_SERVICE_ROLE_KEY || '',
      { auth: { persistSession: false } }
    );

    if (authHeader) {
      const token = authHeader.replace('Bearer ', '');
      try {
        const { data: userData } = await supabaseAdmin.auth.getUser(token);
        if (userData?.user) {
          user = userData.user;
        }
      } catch {
        /* guest or anon token */
      }
    }

    // 2. Parse Body & Validate Request Parameters
    const { showId, seatIds } = await req.json();
    console.log('[create-razorpay-order] Request payload - show_id:', showId, 'seat_ids:', seatIds, 'user:', user?.id || 'guest');

    if (!showId || !UUID_REGEX.test(showId)) {
      return new Response(
        JSON.stringify({ error: 'Invalid or missing show_id UUID parameter.' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!Array.isArray(seatIds) || seatIds.length === 0 || seatIds.some((id) => !UUID_REGEX.test(id))) {
      return new Response(
        JSON.stringify({ error: 'seat_ids must be a non-empty array of valid seat UUIDs.' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 3. Verify Show Exists
    const { data: show, error: showErr } = await supabaseAdmin
      .from('shows')
      .select('*')
      .eq('id', showId)
      .single();

    if (showErr || !show) {
      return new Response(
        JSON.stringify({ error: 'Show not found.' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('[create-razorpay-order] Show verified - screen_id:', show.screen_id);

    // 4. Verify Selected Seats belong to the Show's Screen
    const { data: dbSeats, error: seatsErr } = await supabaseAdmin
      .from('seats')
      .select('*')
      .eq('screen_id', show.screen_id);

    if (seatsErr) {
      return new Response(
        JSON.stringify({ error: 'Failed to verify screen seats in database.' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const seatMap = new Map<string, any>();
    if (dbSeats) {
      for (const s of dbSeats) {
        seatMap.set(s.id, s);
      }
    }

    // Ensure all requested seat UUIDs exist for this screen
    for (const seatId of seatIds) {
      if (!seatMap.has(seatId)) {
        return new Response(
          JSON.stringify({ error: `Seat ${seatId} does not belong to the current show screen.` }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    // Calculate subtotal & convenience fee using actual seat prices
    let subtotal = 0;
    const pricePerStandard = show.price || show.ticket_price || 170;
    const pricePerPremium = show.premium_price || Math.round((pricePerStandard * 1.5) / 10) * 10;

    for (const seatId of seatIds) {
      const dbSeat = seatMap.get(seatId);
      const isPremium = dbSeat ? (dbSeat.seat_type === 'premium' || dbSeat.type === 'premium') : false;
      subtotal += isPremium ? pricePerPremium : pricePerStandard;
    }

    const CONVENIENCE_FEE_PER_TICKET = 30;
    const convenienceFee = seatIds.length * CONVENIENCE_FEE_PER_TICKET;
    const totalAmount = subtotal + convenienceFee;

    // 5. Prevent double booking: verify seats are not already booked for this show in booking_seats
    const { data: existingBookings, error: existingErr } = await supabaseAdmin
      .from('booking_seats')
      .select('seat_id')
      .eq('show_id', showId)
      .in('seat_id', seatIds);

    if (existingErr) {
      return new Response(
        JSON.stringify({ error: 'Failed to check seat availability.' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (existingBookings && existingBookings.length > 0) {
      const takenSeats = existingBookings.map((b) => b.seat_id).join(', ');
      return new Response(
        JSON.stringify({ error: `Seat(s) ${takenSeats} are already booked for this show. Please choose different seats.` }),
        { status: 409, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 6. Create Razorpay Order via REST API
    const amountInPaise = Math.round(totalAmount * 100);
    const authString = btoa(`${RAZORPAY_KEY_ID}:${RAZORPAY_KEY_SECRET}`);

    const rzpRes = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: {
        Authorization: `Basic ${authString}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        amount: amountInPaise,
        currency: 'INR',
        receipt: `rcpt_${Date.now()}`,
        notes: {
          show_id: showId,
          user_id: user?.id || 'guest',
          seat_ids: seatIds.join(','),
        },
      }),
    });

    if (!rzpRes.ok) {
      const errText = await rzpRes.text();
      console.error('[create-razorpay-order] Razorpay Order API error:', errText);
      return new Response(
        JSON.stringify({ error: 'Failed to create order with Razorpay.', details: errText }),
        { status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const orderData = await rzpRes.json();
    console.log('[create-razorpay-order] Razorpay order created successfully:', orderData.id);

    // 7. Save pending order metadata in DB
    try {
      await supabaseAdmin.from('razorpay_orders').upsert({
        id: orderData.id,
        user_id: user?.id || null,
        show_id: showId,
        seat_ids: seatIds,
        amount: totalAmount,
        currency: 'INR',
        subtotal,
        convenience_fee: convenienceFee,
        status: 'created',
        customer_email: user?.email || null,
      });
    } catch (dbErr) {
      console.warn('[create-razorpay-order] Could not insert into razorpay_orders table:', dbErr);
    }

    return new Response(
      JSON.stringify({
        success: true,
        orderId: orderData.id,
        amount: orderData.amount,
        currency: orderData.currency,
        keyId: RAZORPAY_KEY_ID,
        subtotal,
        convenienceFee,
        total: totalAmount,
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (err: any) {
    console.error('[create-razorpay-order] Unhandled error:', err);
    return new Response(
      JSON.stringify({ error: err.message || 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
