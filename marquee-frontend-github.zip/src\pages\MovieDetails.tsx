import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { CalendarDays, Clock, Languages, Play, Star, Ticket, Film } from 'lucide-react';
import { ShowtimePicker } from '@/components/ShowtimePicker';
import { TrailerModal } from '@/components/TrailerModal';
import { Badge } from '@/components/ui/Badge';
import { Button, buttonClasses } from '@/components/ui/Button';
import { Skeleton } from '@/components/ui/Skeleton';
import { EmptyState } from '@/components/ui/States';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { api } from '@/services/api';
import { formatDate, formatDuration } from '@/utils/format';

export default function MovieDetails() {
  const { id = '' } = useParams();
  const { data: movie, loading, error, reload } = useAsync(() => api.movies.get(id), [id]);
  const [trailerOpen, setTrailerOpen] = useState(false);
  useDocumentTitle(movie?.title);

  if (error) {
    return (
      <div className="container-page py-20">
        <EmptyState
          icon={Film}
          title="We couldn’t find that movie"
          description={error}
          action={
            <div className="flex gap-3">
              <Button variant="outline" onClick={reload}>
                Try again
              </Button>
              <Link to="/movies" className={buttonClasses()}>
                Browse movies
              </Link>
            </div>
          }
        />
      </div>
    );
  }

  if (loading || !movie) return <DetailsSkeleton />;

  const comingSoon = movie.status === 'coming_soon';

  return (
    <>
      <section className="relative -mt-[68px] overflow-hidden">
        <img src={movie.backdropUrl} alt="" aria-hidden="true" className="absolute inset-0 h-full w-full object-cover opacity-70" />
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-black/30" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-black/60" />

        <div className="container-page relative grid gap-8 pb-14 pt-32 md:grid-cols-[260px_1fr] md:gap-12 lg:grid-cols-[320px_1fr]">
          <img
            src={movie.posterUrl}
            alt={`${movie.title} poster`}
            className="mx-auto w-56 rounded-3xl border border-white/15 object-cover shadow-[0_30px_80px_-20px_rgba(0,0,0,.9)] md:mx-0 md:w-full"
          />

          <div className="animate-fade-in">
            <div className="flex flex-wrap items-center gap-2">
              {comingSoon ? <Badge tone="info">Coming soon</Badge> : <Badge tone="success">Now showing</Badge>}
              <Badge>{movie.certificate}</Badge>
              {movie.formats.map((f) => (
                <Badge key={f} tone={f === 'IMAX' ? 'brand' : 'neutral'}>
                  {f}
                </Badge>
              ))}
            </div>

            <h1 className="mt-4 font-display text-6xl font-black leading-[0.9] sm:text-8xl">{movie.title}</h1>

            <ul className="mt-5 flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-white/80">
              {movie.rating > 0 && (
                <li className="flex items-center gap-1.5 font-semibold">
                  <Star className="h-4 w-4 fill-gold text-gold" />
                  {movie.rating.toFixed(1)} / 10
                </li>
              )}
              <li className="flex items-center gap-1.5">
                <Clock className="h-4 w-4 text-muted" />
                {formatDuration(movie.durationMin)}
              </li>
              <li className="flex items-center gap-1.5">
                <CalendarDays className="h-4 w-4 text-muted" />
                {comingSoon ? 'Releases' : 'Released'} {formatDate(movie.releaseDate)}
              </li>
              <li className="flex items-center gap-1.5">
                <Languages className="h-4 w-4 text-muted" />
                {movie.languages.join(', ')}
              </li>
            </ul>

            <div className="mt-4 flex flex-wrap gap-2">
              {movie.genres.map((g) => (
                <span key={g} className="rounded-full border border-white/25 px-3 py-1 text-sm">
                  {g}
                </span>
              ))}
            </div>

            <p className="mt-6 max-w-2xl text-lg leading-relaxed text-white/75">{movie.description}</p>

            <dl className="mt-6 grid max-w-2xl gap-4 text-sm sm:grid-cols-2">
              <div>
                <dt className="text-muted">Director</dt>
                <dd className="mt-0.5 font-medium">{movie.director}</dd>
              </div>
              <div>
                <dt className="text-muted">Cast</dt>
                <dd className="mt-0.5 font-medium">{movie.cast.join(', ') || 'To be announced'}</dd>
              </div>
            </dl>

            <div className="mt-8 flex flex-wrap gap-3">
              {!comingSoon && (
                <Link to={`/booking?movieId=${movie.id}`} className={buttonClasses({ size: 'lg' })}>
                  <Ticket className="h-5 w-5" />
                  Book Tickets
                </Link>
              )}
              <Button size="lg" variant="outline" className="bg-black/30 backdrop-blur" leftIcon={<Play className="h-5 w-5 fill-white" />} onClick={() => setTrailerOpen(true)}>
                Watch Trailer
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section id="showtimes" className="container-page py-12 sm:py-16">
        <div className="mb-8">
          <h2 className="font-display text-4xl font-extrabold leading-none sm:text-5xl">Showtimes</h2>
          <p className="mt-2 text-sm text-muted">Pick a day, then choose a theatre and time.</p>
        </div>
        {comingSoon ? (
          <EmptyState
            icon={CalendarDays}
            title="Booking opens closer to release"
            description={`Tickets for ${movie.title} go on sale before ${formatDate(movie.releaseDate)}. Use “Notify me” on the movies page to hear first.`}
          />
        ) : (
          <ShowtimePicker movieId={movie.id} />
        )}
      </section>

      <TrailerModal movie={movie} open={trailerOpen} onClose={() => setTrailerOpen(false)} />
    </>
  );
}

function DetailsSkeleton() {
  return (
    <div className="container-page grid gap-10 pb-16 pt-12 md:grid-cols-[280px_1fr]">
      <Skeleton className="mx-auto aspect-[2/3] w-56 md:w-full" />
      <div className="space-y-4">
        <Skeleton className="h-6 w-56" />
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-5 w-2/3" />
        <Skeleton className="h-28 w-full" />
        <div className="flex gap-3">
          <Skeleton className="h-[52px] w-44" />
          <Skeleton className="h-[52px] w-44" />
        </div>
      </div>
    </div>
  );
}
