import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CalendarX2 } from 'lucide-react';
import { useAsync } from '@/hooks/useAsync';
import { api } from '@/services/api';
import type { Format, Show } from '@/types';
import { cn } from '@/utils/cn';
import { DateSelector } from './DateSelector';
import { TheatreCard } from './TheatreCard';
import { EmptyState, ErrorState } from './ui/States';
import { Skeleton } from './ui/Skeleton';

interface Props {
  movieId: string;
  initialDate?: string;
  onDateChange?: (date: string) => void;
}

/** Date strip + format filter + theatres with showtimes. Used on the movie page and the theatre-selection page. */
export function ShowtimePicker({ movieId, initialDate, onDateChange }: Props) {
  const navigate = useNavigate();
  const shows = useAsync(() => api.shows.list({ movieId }), [movieId]);
  const theatres = useAsync(() => api.theatres.list(), []);
  const [date, setDate] = useState<string>(initialDate ?? '');
  const [format, setFormat] = useState<Format | 'all'>('all');

  const dates = useMemo(() => [...new Set((shows.data ?? []).map((s) => s.date))].sort(), [shows.data]);

  useEffect(() => {
    if (dates.length && !dates.includes(date)) setDate(dates[0]);
  }, [dates, date]);

  const dayShows = useMemo(() => (shows.data ?? []).filter((s) => s.date === date), [shows.data, date]);
  const formats = useMemo(() => (['2D', '3D', 'IMAX'] as Format[]).filter((f) => dayShows.some((s) => s.format === f)), [dayShows]);
  const visible = dayShows.filter((s) => format === 'all' || s.format === format);

  const grouped = useMemo(
    () =>
      (theatres.data ?? [])
        .map((t) => ({ theatre: t, shows: visible.filter((s) => s.theatreId === t.id) }))
        .filter((g) => g.shows.length > 0),
    [theatres.data, visible],
  );

  const pick = (s: Show) => navigate(`/booking/seats?showId=${s.id}`);
  const changeDate = (d: string) => {
    setDate(d);
    setFormat('all');
    onDateChange?.(d);
  };

  if (shows.loading && !shows.data) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-24 w-full max-w-xl" />
        <Skeleton className="h-44 w-full" />
        <Skeleton className="h-44 w-full" />
      </div>
    );
  }
  if (shows.error || theatres.error) {
    return (
      <ErrorState
        message={shows.error ?? theatres.error ?? undefined}
        onRetry={() => {
          shows.reload();
          theatres.reload();
        }}
      />
    );
  }
  if (!dates.length) {
    return (
      <EmptyState
        icon={CalendarX2}
        title="No shows scheduled yet"
        description="Showtimes for this movie haven’t been announced. Check back soon or browse what’s playing now."
      />
    );
  }

  return (
    <div className="space-y-6">
      <DateSelector dates={dates} value={date} onChange={changeDate} />

      {formats.length > 1 && (
        <div className="flex flex-wrap items-center gap-2" role="group" aria-label="Filter by format">
          {(['all', ...formats] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFormat(f)}
              aria-pressed={format === f}
              className={cn(
                'rounded-full border px-4 py-1.5 text-sm font-medium transition',
                format === f ? 'border-white bg-white text-black' : 'border-line text-white/70 hover:border-white/40 hover:text-white',
              )}
            >
              {f === 'all' ? 'All formats' : f}
            </button>
          ))}
        </div>
      )}

      {grouped.length ? (
        <div className="space-y-4">
          {grouped.map((g) => (
            <TheatreCard key={g.theatre.id} theatre={g.theatre} shows={g.shows} onSelectShow={pick} />
          ))}
        </div>
      ) : (
        <EmptyState icon={CalendarX2} title="Nothing on this day" description="Try another date or format." />
      )}
    </div>
  );
}
