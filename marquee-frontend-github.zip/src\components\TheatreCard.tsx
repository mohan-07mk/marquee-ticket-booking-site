import { Link } from 'react-router-dom';
import { MapPin, Monitor, Sparkles } from 'lucide-react';
import type { Format, Show, Theatre } from '@/types';
import { Badge } from './ui/Badge';
import { buttonClasses } from './ui/Button';
import { ShowtimeButton } from './ShowtimeButton';

interface TheatreCardProps {
  theatre: Theatre;
  /** When provided, the card lists showtimes grouped by format. */
  shows?: Show[];
  onSelectShow?: (show: Show) => void;
}

export function TheatreCard({ theatre, shows, onSelectShow }: TheatreCardProps) {
  const screenName = (id: string) => theatre.screens.find((s) => s.id === id)?.name ?? '';
  const formats = shows
    ? (['IMAX', '3D', '2D'] as Format[]).filter((f) => shows.some((s) => s.format === f))
    : [];

  return (
    <article className="rounded-3xl border border-line bg-surface p-5 transition duration-300 hover:border-white/25 sm:p-6">
      <header className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="font-display text-2xl font-bold leading-tight">{theatre.name}</h3>
          <p className="mt-1 flex items-center gap-1.5 text-sm text-muted">
            <MapPin className="h-4 w-4 shrink-0" />
            {theatre.location}
          </p>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {theatre.amenities.slice(0, 3).map((a) => (
            <Badge key={a}>{a}</Badge>
          ))}
        </div>
      </header>

      {shows ? (
        <div className="mt-5 space-y-5">
          {formats.map((format) => {
            const list = shows.filter((s) => s.format === format);
            const screen = screenName(list[0].screenId);
            return (
              <div key={format}>
                <div className="mb-2.5 flex items-center gap-2 text-sm">
                  <Badge tone={format === 'IMAX' ? 'brand' : format === '3D' ? 'info' : 'neutral'}>{format}</Badge>
                  <span className="flex items-center gap-1.5 text-muted">
                    <Monitor className="h-3.5 w-3.5" />
                    {screen}
                  </span>
                </div>
                <div className="flex flex-wrap gap-2.5">
                  {list.map((s) => (
                    <ShowtimeButton key={s.id} show={s} onSelect={(sh) => onSelectShow?.(sh)} />
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="mt-5 space-y-4">
          <ul className="grid gap-2 sm:grid-cols-2">
            {theatre.screens.map((s) => (
              <li key={s.id} className="flex items-center justify-between gap-3 rounded-xl border border-line bg-black/40 px-3.5 py-2.5 text-sm">
                <span className="flex items-center gap-2 font-medium">
                  <Monitor className="h-4 w-4 text-muted" />
                  {s.name}
                </span>
                <span className="flex items-center gap-1.5">
                  {s.formats.map((f) => (
                    <Badge key={f} tone={f === 'IMAX' ? 'brand' : 'neutral'}>
                      {f}
                    </Badge>
                  ))}
                  <span className="ml-1 text-xs text-muted">{s.capacity} seats</span>
                </span>
              </li>
            ))}
          </ul>
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="flex items-center gap-1.5 text-sm text-muted">
              <Sparkles className="h-4 w-4" />
              {theatre.amenities.join(', ')}
            </p>
            <Link to="/movies" className={buttonClasses({ variant: 'outline', size: 'sm' })}>
              Browse movies
            </Link>
          </div>
        </div>
      )}
    </article>
  );
}
