import { Play } from 'lucide-react';
import type { Movie } from '@/types';
import { Modal } from './ui/Modal';
import { getYouTubeEmbedUrl } from '@/utils/youtube';

export function TrailerModal({ movie, open, onClose }: { movie: Movie | null; open: boolean; onClose: () => void }) {
  if (!movie) return null;
  const embedUrl = getYouTubeEmbedUrl(movie.trailerUrl);

  return (
    <Modal open={open} onClose={onClose} title={`${movie.title}: Official Trailer`} size="lg">
      <div className="relative aspect-video overflow-hidden rounded-2xl border border-line bg-black">
        {embedUrl ? (
          <iframe
            src={embedUrl}
            title={`${movie.title} trailer`}
            className="h-full w-full"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            allowFullScreen
          />
        ) : (
          <>
            <img src={movie.backdropUrl || movie.posterUrl} alt="" className="absolute inset-0 h-full w-full object-cover opacity-50" />
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center">
              <span className="grid h-16 w-16 place-items-center rounded-full bg-brand/80 shadow-[0_0_40px_rgba(225,29,46,.6)]">
                <Play className="h-7 w-7 translate-x-0.5 fill-white" />
              </span>
              <p className="max-w-md text-lg font-bold text-white">Trailer Unavailable</p>
              <p className="max-w-md text-xs text-white/70">
                No official trailer URL has been configured for {movie.title} yet. You can add a YouTube trailer link in Admin Movie management.
              </p>
            </div>
          </>
        )}
      </div>
    </Modal>
  );
}

