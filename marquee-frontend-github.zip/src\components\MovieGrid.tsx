import type { Movie } from '@/types';
import { MovieCard } from './MovieCard';
import { MovieCardSkeleton } from './ui/Skeleton';

export function MovieGrid({ movies, loading, skeletons = 8 }: { movies?: Movie[]; loading?: boolean; skeletons?: number }) {
  return (
    <div className="grid grid-cols-2 gap-x-4 gap-y-8 md:grid-cols-3 lg:grid-cols-4 lg:gap-x-6">
      {loading
        ? Array.from({ length: skeletons }, (_, i) => <MovieCardSkeleton key={i} />)
        : movies?.map((m) => <MovieCard key={m.id} movie={m} />)}
    </div>
  );
}
