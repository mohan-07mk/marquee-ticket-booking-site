import { Link } from 'react-router-dom';
import { buttonClasses } from '@/components/ui/Button';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';

export default function NotFound() {
  useDocumentTitle('Page not found');
  return (
    <div className="container-page flex min-h-[70vh] flex-col items-center justify-center text-center">
      <p className="font-display text-[10rem] font-black leading-none text-transparent [-webkit-text-stroke:2px_#e11d2e] sm:text-[14rem]">404</p>
      <h1 className="-mt-4 font-display text-4xl font-extrabold">This screening doesn’t exist</h1>
      <p className="mt-3 max-w-md text-muted">The page you’re looking for has been moved or never made it to the cinema.</p>
      <Link to="/" className={buttonClasses({ className: 'mt-8' })}>
        Back to home
      </Link>
    </div>
  );
}
