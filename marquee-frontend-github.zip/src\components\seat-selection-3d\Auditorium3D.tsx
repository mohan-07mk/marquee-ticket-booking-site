import { forwardRef, useEffect, useLayoutEffect, useMemo, useRef } from 'react';
import { Environment, Lightformer } from '@react-three/drei';
import { Canvas } from '@react-three/fiber';
import { Matrix4, Object3D, Quaternion, Vector3, type InstancedMesh } from 'three';
import type { Seat } from '@/types';
import type { YouTubeInfo } from '@/utils/youtube';
import { AuditoriumCamera, type AuditoriumCameraApi } from './AuditoriumCamera';
import { CinemaScreen3D, type ScreenStatus } from './CinemaScreen3D';
import { CinemaSeat3D } from './CinemaSeat3D';
import { labelTexture } from './labelTexture';
import { SIDE_AISLE, CENTER_AISLE, WALL_INSET, type AuditoriumLayout } from './seatLayout';
import { createSeatMaterials, disposeSeatMaterials, type SeatVisual } from './seatModels';

interface Props {
  layout: AuditoriumLayout;
  selectedIds: Set<string>;
  /** True once the show has started: free seats can no longer be picked. */
  blocked: boolean;
  video: YouTubeInfo | null;
  title: string;
  subtitle: string;
  screenInteractive: boolean;
  reducedMotion: boolean;
  lowPower: boolean;
  onHoverSeat: (seat: Seat | null) => void;
  onSelectSeat: (seat: Seat) => void;
  onScreenStatus: (status: ScreenStatus, reason?: string) => void;
  onUserMove: () => void;
  onReady: () => void;
  onContextLost: () => void;
}

/** The whole scene: room, screen, lighting and seats. Mounted inside <Canvas>. */
export const Auditorium3D = forwardRef<AuditoriumCameraApi, Props>(function Auditorium3D(props, cameraRef) {
  const { layout, lowPower } = props;
  return (
    <Canvas
      shadows="soft"
      dpr={lowPower ? [1, 1.25] : [1, 1.75]}
      gl={{ antialias: true, alpha: true, powerPreference: 'high-performance' }}
      camera={{ fov: 38, near: 0.1, far: 220, position: [0, 10, layout.length + 8] }}
      onCreated={({ gl }) => {
        gl.domElement.addEventListener('webglcontextlost', (e) => {
          e.preventDefault();
          props.onContextLost();
        });
        props.onReady();
      }}
      aria-label="3D view of the cinema auditorium"
    >
      <Lighting layout={layout} lowPower={lowPower} />
      <Room layout={layout} />
      <CinemaScreen3D
        layout={layout}
        video={props.video}
        title={props.title}
        subtitle={props.subtitle}
        interactive={props.screenInteractive}
        onStatusChange={props.onScreenStatus}
      />
      <Seats {...props} />
      <RowLabels layout={layout} />
      <AuditoriumCamera ref={cameraRef} layout={layout} reducedMotion={props.reducedMotion} onUserMove={props.onUserMove} />
    </Canvas>
  );
});

/* ------------------------------------------------------------------ */
/* Seats                                                               */
/* ------------------------------------------------------------------ */
function Seats({ layout, selectedIds, blocked, reducedMotion, onHoverSeat, onSelectSeat }: Props) {
  const materials = useMemo(() => createSeatMaterials(), []);
  useEffect(() => () => disposeSeatMaterials(materials), [materials]);

  return (
    <group>
      {layout.placements.map((p) => {
        const { seat } = p;
        const visual: SeatVisual =
          seat.status === 'occupied' ? 'booked' : blocked ? 'unavailable' : selectedIds.has(seat.id) ? 'selected' : 'available';
        return (
          <CinemaSeat3D
            key={seat.id}
            placement={p}
            visual={visual}
            materials={materials}
            reducedMotion={reducedMotion}
            onHover={onHoverSeat}
            onSelect={onSelectSeat}
          />
        );
      })}
    </group>
  );
}

/** Row letters at both ends of each row. Sprites always face the camera. */
function RowLabels({ layout }: { layout: AuditoriumLayout }) {
  const edge = layout.width / 2 - WALL_INSET - SIDE_AISLE / 2;
  return (
    <group>
      {layout.rows.map((row) => {
        const map = labelTexture(row.label, row.premium ? '#f5b942' : '#ffffff');
        return [-edge, edge].map((x) => (
          <sprite key={`${row.label}${x}`} position={[x, row.y + 0.42, row.z]} scale={[0.46, 0.46, 1]} raycast={() => null}>
            <spriteMaterial map={map} transparent depthWrite={false} toneMapped={false} />
          </sprite>
        ));
      })}
    </group>
  );
}

/* ------------------------------------------------------------------ */
/* Lighting                                                            */
/* ------------------------------------------------------------------ */
function Lighting({ layout, lowPower }: { layout: AuditoriumLayout; lowPower: boolean }) {
  const { width, length, height, center, screen } = layout;
  const mapSize = lowPower ? 1024 : 2048;
  return (
    <>
      <ambientLight intensity={0.32} color="#c3c9ff" />
      <hemisphereLight args={['#b4bcff', '#1c0b0e', 0.42]} />
      <directionalLight
        position={[0, height, length + 3]}
        intensity={1.5}
        color="#fff1dd"
        castShadow
        shadow-mapSize={[mapSize, mapSize]}
        shadow-bias={-0.0004}
        shadow-normalBias={0.03}
        shadow-camera-left={-width}
        shadow-camera-right={width}
        shadow-camera-top={length}
        shadow-camera-bottom={-length}
        shadow-camera-near={0.5}
        shadow-camera-far={length * 2 + height}
      />
      {/* Cool wash from the screen onto the front rows */}
      <pointLight position={[0, screen.centerY, 4]} intensity={55} color="#93a8ff" distance={34} decay={2} />
      <pointLight position={[0, 3, center.z]} intensity={18} color="#ffb877" distance={30} decay={2} />
      <Environment resolution={64} frames={1}>
        <Lightformer form="rect" intensity={0.9} color="#9db0ff" position={[0, 6, -8]} scale={[14, 5, 1]} />
        <Lightformer form="rect" intensity={0.6} color="#ffc48a" position={[0, 12, 6]} rotation={[Math.PI / 2, 0, 0]} scale={[16, 6, 1]} />
      </Environment>
    </>
  );
}

/* ------------------------------------------------------------------ */
/* Room                                                                */
/* ------------------------------------------------------------------ */
const WALL = '#14151a';
const TRIM_WARM = '#ffb25a';

function Room({ layout }: { layout: AuditoriumLayout }) {
  const { width, length, height, rows } = layout;
  const inner = width - WALL_INSET * 2;
  const lastY = rows.length ? rows[rows.length - 1].y : 0;
  const firstPremium = rows.find((r) => r.premium);
  // Aisle x-centres and widths: left side aisle, centre aisle, right side aisle.
  const aisles = [
    { x: -(width / 2 - WALL_INSET - SIDE_AISLE / 2), w: SIDE_AISLE },
    { x: 0, w: CENTER_AISLE },
    { x: width / 2 - WALL_INSET - SIDE_AISLE / 2, w: SIDE_AISLE },
  ];

  const slope = Math.atan2(lastY, length - 5.2);
  const slopeLen = Math.hypot(lastY, length - 5.2);

  return (
    <group>
      {/* Stage floor in front of the first row */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 2.6]} receiveShadow>
        <planeGeometry args={[inner, 5.2]} />
        <meshStandardMaterial color="#0e0f12" roughness={0.55} metalness={0.2} />
      </mesh>

      {/* Stepped seating tiers */}
      {rows.map((row) => (
        <group key={row.label}>
          <mesh position={[0, row.y / 2, row.z]} receiveShadow castShadow>
            <boxGeometry args={[inner, row.y, row.depth]} />
            <meshStandardMaterial color="#17181d" roughness={0.96} />
          </mesh>
          {aisles.map((a) => (
            <group key={a.x}>
              <mesh position={[a.x, row.y + 0.004, row.z]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
                <planeGeometry args={[a.w - 0.1, row.depth - 0.04]} />
                <meshStandardMaterial color="#3a0e15" roughness={0.98} />
              </mesh>
              {/* Aisle step light on the tread edge */}
              <mesh position={[a.x, row.y + 0.008, row.z - row.depth / 2 + 0.05]}>
                <boxGeometry args={[a.w - 0.2, 0.012, 0.03]} />
                <meshBasicMaterial color={TRIM_WARM} toneMapped={false} />
              </mesh>
            </group>
          ))}
        </group>
      ))}

      {/* Gold divider where the premium recliners start */}
      {firstPremium && (
        <mesh position={[0, firstPremium.y + 0.01, firstPremium.z - firstPremium.depth / 2 + 0.012]}>
          <boxGeometry args={[inner - 0.2, 0.012, 0.04]} />
          <meshBasicMaterial color="#f5b942" toneMapped={false} />
        </mesh>
      )}

      {/* Walls and ceiling face inward only, so from outside the hall you see straight in. */}
      <mesh position={[-width / 2, height / 2, length / 2]} rotation={[0, Math.PI / 2, 0]} receiveShadow>
        <planeGeometry args={[length, height]} />
        <meshStandardMaterial color={WALL} roughness={0.92} />
      </mesh>
      <mesh position={[width / 2, height / 2, length / 2]} rotation={[0, -Math.PI / 2, 0]} receiveShadow>
        <planeGeometry args={[length, height]} />
        <meshStandardMaterial color={WALL} roughness={0.92} />
      </mesh>
      <mesh position={[0, height / 2, length]} rotation={[0, Math.PI, 0]} receiveShadow>
        <planeGeometry args={[width, height]} />
        <meshStandardMaterial color="#101116" roughness={0.92} />
      </mesh>
      <mesh position={[0, height / 2, 0]} receiveShadow>
        <planeGeometry args={[width, height]} />
        <meshStandardMaterial color="#0c0d10" roughness={0.95} />
      </mesh>
      <mesh position={[0, height, length / 2]} rotation={[Math.PI / 2, 0, 0]}>
        <planeGeometry args={[width, length]} />
        <meshStandardMaterial color="#0b0c0f" roughness={1} />
      </mesh>

      {/* Acoustic wall slats */}
      <WallSlats layout={layout} side={-1} />
      <WallSlats layout={layout} side={1} />

      {/* Cove lights following the slope of the stairs */}
      {[-1, 1].map((side) => (
        <mesh
          key={side}
          position={[side * (width / 2 - 0.04), lastY / 2 + 0.55, 5.2 + (length - 5.2) / 2]}
          rotation={[-slope, 0, 0]}
        >
          <boxGeometry args={[0.04, 0.04, slopeLen]} />
          <meshBasicMaterial color={TRIM_WARM} toneMapped={false} />
        </mesh>
      ))}

      {/* Ceiling cove strips and downlights */}
      {[-width * 0.3, 0, width * 0.3].map((x) => (
        <mesh key={x} position={[x, height - 0.03, length / 2]}>
          <boxGeometry args={[0.1, 0.03, length - 1]} />
          <meshBasicMaterial color="#ffe2b8" toneMapped={false} />
        </mesh>
      ))}
      <Downlights layout={layout} />
    </group>
  );
}

function WallSlats({ layout, side }: { layout: AuditoriumLayout; side: -1 | 1 }) {
  const ref = useRef<InstancedMesh>(null);
  const { width, length, height } = layout;
  const count = Math.floor((length - 5.2) / 0.62);

  useLayoutEffect(() => {
    const mesh = ref.current;
    if (!mesh) return;
    const m = new Matrix4();
    const q = new Quaternion();
    const s = new Vector3(1, 1, 1);
    for (let i = 0; i < count; i++) {
      const z = 5.6 + i * 0.62;
      m.compose(new Vector3(side * (width / 2 - 0.06), height * 0.55, z), q, s);
      mesh.setMatrixAt(i, m);
    }
    mesh.instanceMatrix.needsUpdate = true;
  }, [count, height, side, width]);

  return (
    <instancedMesh ref={ref} args={[undefined, undefined, count]} receiveShadow>
      <boxGeometry args={[0.08, height * 0.62, 0.22]} />
      <meshStandardMaterial color="#3a281c" roughness={0.7} metalness={0.05} />
    </instancedMesh>
  );
}

function Downlights({ layout }: { layout: AuditoriumLayout }) {
  const ref = useRef<InstancedMesh>(null);
  const { width, length, height } = layout;
  const cols = [-width * 0.16, width * 0.16];
  const per = Math.max(3, Math.floor(length / 3));
  useLayoutEffect(() => {
    const mesh = ref.current;
    if (!mesh) return;
    const dummy = new Object3D();
    let i = 0;
    cols.forEach((x) => {
      for (let k = 0; k < per; k++) {
        dummy.position.set(x, height - 0.01, 3 + k * ((length - 4) / per));
        dummy.rotation.set(Math.PI / 2, 0, 0);
        dummy.updateMatrix();
        mesh.setMatrixAt(i++, dummy.matrix);
      }
    });
    mesh.instanceMatrix.needsUpdate = true;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [width, length, height, per]);
  return (
    <instancedMesh ref={ref} args={[undefined, undefined, cols.length * per]}>
      <circleGeometry args={[0.16, 20]} />
      <meshBasicMaterial color="#fff3df" toneMapped={false} />
    </instancedMesh>
  );
}
