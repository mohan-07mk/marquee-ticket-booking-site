import { useMemo, useState } from 'react';
import { Building2, Search } from 'lucide-react';
import { TheatreCard } from '@/components/TheatreCard';
import { Input, Select } from '@/components/ui/Field';
import { Skeleton } from '@/components/ui/Skeleton';
import { EmptyState, ErrorState } from '@/components/ui/States';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { api } from '@/services/api';

export default function Theatres() {
  useDocumentTitle('Theatres');
  const { data, loading, error, reload } = useAsync(() => api.theatres.list(), []);
  const [q, setQ] = useState('');
  const [format, setFormat] = useState('all');

  const results = useMemo(
    () =>
      (data ?? [])
        .filter((t) => !q.trim() || `${t.name} ${t.location}`.toLowerCase().includes(q.trim().toLowerCase()))
        .filter((t) => format === 'all' || t.screens.some((s) => s.formats.includes(format as never))),
    [data, q, format],
  );

  return (
    <div className="container-page py-10 sm:py-14">
      <header className="mb-8">
        <h1 className="font-display text-5xl font-extrabold leading-none sm:text-7xl">Theatres</h1>
        <p className="mt-3 text-muted">Every screen, format and amenity in one place.</p>
      </header>

      <div className="mb-8 grid gap-3 sm:grid-cols-[1fr_220px]">
        <Input aria-label="Search theatres" placeholder="Search by name or area" icon={<Search className="h-4 w-4" />} value={q} onChange={(e) => setQ(e.target.value)} />
        <Select aria-label="Format" value={format} onChange={(e) => setFormat(e.target.value)}>
          <option value="all">All formats</option>
          <option>2D</option>
          <option>3D</option>
          <option>IMAX</option>
        </Select>
      </div>

      {error ? (
        <ErrorState message={error} onRetry={reload} />
      ) : loading ? (
        <div className="grid gap-5 lg:grid-cols-2">
          {Array.from({ length: 4 }, (_, i) => (
            <Skeleton key={i} className="h-64" />
          ))}
        </div>
      ) : results.length === 0 ? (
        <EmptyState icon={Building2} title="No theatres found" description="Try a different name or area, or switch the format filter back to All." />
      ) : (
        <div className="grid gap-5 lg:grid-cols-2">
          {results.map((t) => (
            <TheatreCard key={t.id} theatre={t} />
          ))}
        </div>
      )}
    </div>
  );
}
