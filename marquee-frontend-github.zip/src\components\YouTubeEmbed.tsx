import { useEffect, useRef } from 'react';
import { describeYouTubeError, loadYouTubeApi } from '@/utils/youtubeApi';

export type EmbedStatus = 'loading' | 'ready' | 'error';

interface Props {
  embedUrl: string;
  title: string;
  /** Reports loading / ready / error (with a plain-language reason). */
  onStatus?: (status: EmbedStatus, reason?: string) => void;
  className?: string;
  style?: React.CSSProperties;
}

/**
 * One iframe, used both in the admin preview and on the 3D cinema screen.
 * Keyed by URL so changing the video mounts a fresh iframe and player.
 */
export function YouTubeEmbed({ embedUrl, title, onStatus, className, style }: Props) {
  const ref = useRef<HTMLIFrameElement>(null);
  const report = useRef(onStatus);
  report.current = onStatus;

  useEffect(() => {
    let cancelled = false;
    report.current?.('loading');
    loadYouTubeApi()
      .then((YT) => {
        if (cancelled || !ref.current) return;
        new YT.Player(ref.current, {
          events: {
            onReady: () => !cancelled && report.current?.('ready'),
            onError: (e) => !cancelled && report.current?.('error', describeYouTubeError(e.data)),
          },
        });
      })
      .catch(() => {
        /* API blocked or offline: the iframe's own onLoad reports ready below. */
      });
    return () => {
      cancelled = true;
    };
  }, [embedUrl]);

  return (
    <iframe
      key={embedUrl}
      ref={ref}
      src={embedUrl}
      title={title}
      className={className}
      style={{ border: 0, ...style }}
      allow="autoplay; encrypted-media; picture-in-picture; fullscreen"
      allowFullScreen
      referrerPolicy="strict-origin-when-cross-origin"
      onLoad={() => report.current?.('ready')}
    />
  );
}
