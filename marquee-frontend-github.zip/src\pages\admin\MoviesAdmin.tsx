import { useMemo, useState } from 'react';
import { Eye, EyeOff, Pencil, Plus, Search, Trash2, Star } from 'lucide-react';
import { AdminPageHeader, Toolbar } from '@/components/admin/AdminPageHeader';
import { DataTable, type Column } from '@/components/admin/DataTable';
import { MovieFormModal } from '@/components/admin/MovieFormModal';
import { StatusBadge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';
import { Input, Select } from '@/components/ui/Field';
import { ErrorState } from '@/components/ui/States';
import { useToast } from '@/context/ToastContext';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { api } from '@/services/api';
import type { Movie } from '@/types';
import { formatDate, formatDuration } from '@/utils/format';

export default function MoviesAdmin() {
  useDocumentTitle('Manage movies');
  const toast = useToast();
  const { data, loading, error, reload } = useAsync(() => api.movies.list({ includeInactive: true }), []);
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('all');
  const [editing, setEditing] = useState<Movie | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [toDelete, setToDelete] = useState<Movie | null>(null);
  const [busy, setBusy] = useState(false);

  const rows = useMemo(
    () =>
      (data ?? [])
        .filter((m) => !q.trim() || m.title.toLowerCase().includes(q.trim().toLowerCase()))
        .filter((m) => status === 'all' || m.status === status),
    [data, q, status],
  );

  const openAdd = () => {
    setEditing(null);
    setFormOpen(true);
  };
  const openEdit = (m: Movie) => {
    setEditing(m);
    setFormOpen(true);
  };

  const toggleActive = async (m: Movie) => {
    const next = m.status === 'inactive' ? (new Date(m.releaseDate) > new Date() ? 'coming_soon' : 'now_showing') : 'inactive';
    try {
      await api.movies.setStatus(m.id, next);
      toast.success(next === 'inactive' ? 'Movie deactivated' : 'Movie activated', m.title);
      reload();
    } catch (e) {
      toast.error('Couldn’t update the movie', e instanceof Error ? e.message : undefined);
    }
  };

  const remove = async () => {
    if (!toDelete) return;
    setBusy(true);
    try {
      await api.movies.remove(toDelete.id);
      toast.success('Movie deleted', toDelete.title);
      setToDelete(null);
      reload();
    } catch (e) {
      toast.error('Couldn’t delete the movie', e instanceof Error ? e.message : undefined);
    } finally {
      setBusy(false);
    }
  };

  const columns: Column<Movie>[] = [
    {
      key: 'title',
      header: 'Movie',
      mobile: 'title',
      cell: (m) => (
        <div className="flex items-center gap-3">
          <img src={m.posterUrl} alt="" className="h-14 w-10 shrink-0 rounded-md border border-line object-cover" />
          <div className="min-w-0">
            <p className="truncate font-medium">{m.title}</p>
            <p className="flex items-center gap-2 text-xs text-muted">
              {m.certificate}
              {m.rating > 0 && (
                <span className="inline-flex items-center gap-0.5">
                  <Star className="h-3 w-3 fill-gold text-gold" />
                  {m.rating.toFixed(1)}
                </span>
              )}
            </p>
          </div>
        </div>
      ),
    },
    { key: 'lang', header: 'Language', cell: (m) => m.languages.join(', ') },
    { key: 'genre', header: 'Genre', cell: (m) => m.genres.join(', ') },
    { key: 'dur', header: 'Duration', cell: (m) => formatDuration(m.durationMin) },
    { key: 'release', header: 'Release', cell: (m) => formatDate(m.releaseDate) },
    { key: 'status', header: 'Status', cell: (m) => <StatusBadge status={m.status} /> },
    {
      key: 'actions',
      header: 'Actions',
      mobile: 'actions',
      className: 'text-right',
      cell: (m) => (
        <div className="flex justify-end gap-1">
          <Button variant="ghost" size="icon" aria-label={`Edit ${m.title}`} onClick={() => openEdit(m)}>
            <Pencil className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" aria-label={m.status === 'inactive' ? `Activate ${m.title}` : `Deactivate ${m.title}`} onClick={() => toggleActive(m)}>
            {m.status === 'inactive' ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
          </Button>
          <Button variant="ghost" size="icon" aria-label={`Delete ${m.title}`} className="hover:text-red-400" onClick={() => setToDelete(m)}>
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      ),
    },
  ];

  return (
    <>
      <AdminPageHeader
        title="Movie management"
        description="Add films, update details, and control what customers can see."
        action={
          <Button leftIcon={<Plus className="h-4 w-4" />} onClick={openAdd}>
            Add movie
          </Button>
        }
      />
      <Toolbar>
        <Input aria-label="Search movies" placeholder="Search by title" icon={<Search className="h-4 w-4" />} value={q} onChange={(e) => setQ(e.target.value)} className="lg:w-80" />
        <Select aria-label="Status" value={status} onChange={(e) => setStatus(e.target.value)} className="lg:w-52">
          <option value="all">All statuses</option>
          <option value="now_showing">Now showing</option>
          <option value="coming_soon">Coming soon</option>
          <option value="inactive">Inactive</option>
        </Select>
      </Toolbar>

      {error ? <ErrorState message={error} onRetry={reload} /> : <DataTable columns={columns} rows={rows} rowKey={(m) => m.id} loading={loading && !data} emptyTitle="No movies found" />}

      <MovieFormModal open={formOpen} movie={editing} onClose={() => setFormOpen(false)} onSaved={reload} />
      <ConfirmDialog
        open={!!toDelete}
        title="Delete this movie?"
        description={toDelete ? `“${toDelete.title}” will be removed from the catalogue. Existing bookings are kept. Consider deactivating it instead if you might need it again.` : ''}
        confirmLabel="Delete movie"
        loading={busy}
        onConfirm={remove}
        onCancel={() => setToDelete(null)}
      />
    </>
  );
}
