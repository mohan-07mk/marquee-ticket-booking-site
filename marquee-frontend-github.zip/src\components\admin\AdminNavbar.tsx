import { useLocation } from 'react-router-dom';
import { Menu } from 'lucide-react';
import { NotificationDropdown } from '@/components/NotificationDropdown';
import { useAuth } from '@/context/AuthContext';
import { initials } from '@/utils/format';

const titles: Record<string, string> = {
  '/admin': 'Dashboard',
  '/admin/movies': 'Movies',
  '/admin/theatres': 'Theatres',
  '/admin/shows': 'Shows',
  '/admin/bookings': 'Bookings',
  '/admin/users': 'Users',
  '/admin/revenue': 'Revenue',
};

export function AdminNavbar({ onMenu }: { onMenu: () => void }) {
  const { pathname } = useLocation();
  const { user } = useAuth();
  const displayName = user?.name || 'Admin User';

  return (
    <header className="sticky top-0 z-30 flex h-[68px] items-center justify-between gap-4 border-b border-line bg-black/85 px-4 backdrop-blur-xl sm:px-8">
      <div className="flex items-center gap-3">
        <button
          onClick={onMenu}
          className="grid h-10 w-10 place-items-center rounded-xl border border-line lg:hidden"
          aria-label="Open sidebar"
          type="button"
        >
          <Menu className="h-5 w-5" />
        </button>
        <h1 className="font-display text-3xl font-extrabold leading-none">{titles[pathname] ?? 'Admin'}</h1>
      </div>
      <div className="flex items-center gap-3">
        {/* Working Notification Dropdown */}
        <NotificationDropdown variant="admin" />

        {/* Admin User Profile */}
        <div className="flex items-center gap-2.5">
          <span className="grid h-10 w-10 place-items-center rounded-full bg-brand text-sm font-bold text-white shadow">
            {initials(displayName)}
          </span>
          <div className="hidden text-sm leading-tight sm:block">
            <p className="font-semibold text-white">{displayName}</p>
            <p className="text-xs text-muted">{user?.role === 'admin' ? 'Administrator' : 'Admin Panel'}</p>
          </div>
        </div>
      </div>
    </header>
  );
}
