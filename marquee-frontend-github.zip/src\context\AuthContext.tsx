import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { supabase } from '@/lib/supabase';
import { api } from '@/services/api';
import type { User } from '@/types';

/**
 * Supabase-backed auth context.
 * Listens to onAuthStateChange to keep the user in sync across tabs,
 * persists the profile to localStorage for instant hydration on reload.
 */
interface AuthState {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<User>;
  loginWithGoogle: () => Promise<User>;
  register: (input: { name: string; email: string; phone: string; password: string }) => Promise<User>;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthState | null>(null);
const KEY = 'marquee.user';

const readStored = (): User | null => {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as User) : null;
  } catch {
    return null;
  }
};

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(readStored);
  const [loading, setLoading] = useState(true);

  const save = useCallback((u: User | null) => {
    setUser(u);
    try {
      if (u) localStorage.setItem(KEY, JSON.stringify(u));
      else localStorage.removeItem(KEY);
    } catch {
      /* ignore */
    }
  }, []);

  // On mount: check for existing session
  useEffect(() => {
    let mounted = true;

    const init = async () => {
      try {
        const profile = await api.auth.getSession();
        if (mounted) save(profile);
      } catch {
        if (mounted) save(null);
      } finally {
        if (mounted) setLoading(false);
      }
    };

    init();

    // Listen for auth state changes (login, logout, token refresh)
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_OUT') {
        save(null);
        return;
      }
      if (session?.user) {
        try {
          const profile = await api.auth.getSession();
          if (mounted) save(profile);
        } catch {
          if (mounted) save(null);
        }
      }
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [save]);

  const refreshProfile = useCallback(async () => {
    const profile = await api.auth.getSession();
    save(profile);
  }, [save]);

  const value = useMemo<AuthState>(
    () => ({
      user,
      loading,
      login: async (email, password) => {
        const u = await api.auth.login(email, password);
        save(u);
        return u;
      },
      loginWithGoogle: async () => {
        const u = await api.auth.loginWithGoogle();
        // OAuth redirects so this may not return
        if (u.id) save(u);
        return u;
      },
      register: async (input) => {
        const u = await api.auth.register(input);
        save(u);
        return u;
      },
      logout: async () => {
        await api.auth.logout();
        save(null);
      },
      refreshProfile,
    }),
    [user, loading, save, refreshProfile],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
}
