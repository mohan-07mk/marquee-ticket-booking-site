import { NavLink } from 'react-router-dom';
import { Building2, CalendarClock, Film, IndianRupee, LayoutDashboard, LogOut, Ticket, Users, X } from 'lucide-react';
import { cn } from '@/utils/cn';
import { Logo } from '../Logo';

const items = [
  { to: '/admin', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/admin/movies', label: 'Movies', icon: Film },
  { to: '/admin/theatres', label: 'Theatres', icon: Building2 },
  { to: '/admin/shows', label: 'Shows', icon: CalendarClock },
  { to: '/admin/bookings', label: 'Bookings', icon: Ticket },
  { to: '/admin/users', label: 'Users', icon: Users },
  { to: '/admin/revenue', label: 'Revenue', icon: IndianRupee },
];

export function AdminSidebar({ open, onClose }: { open: boolean; onClose: () => void }) {
  return (
    <>
      {open && <div className="fixed inset-0 z-40 bg-black/70 backdrop-blur-sm lg:hidden" onClick={onClose} aria-hidden="true" />}
      <aside
        className={cn(
          'fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r border-line bg-surface transition-transform duration-300 lg:translate-x-0',
          open ? 'translate-x-0' : '-translate-x-full',
        )}
        aria-label="Admin navigation"
      >
        <div className="flex h-[68px] items-center justify-between border-b border-line px-5">
          <Logo to="/admin" />
          <button onClick={onClose} className="rounded-lg p-1.5 text-muted hover:bg-white/10 lg:hidden" aria-label="Close sidebar">
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav className="flex-1 space-y-1 overflow-y-auto p-3">
          {items.map(({ to, label, icon: Icon, end }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              onClick={onClose}
              className={({ isActive }) =>
                cn(
                  'flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition',
                  isActive ? 'bg-brand text-white shadow-[0_10px_24px_-14px_rgba(225,29,46,.9)]' : 'text-white/65 hover:bg-white/5 hover:text-white',
                )
              }
            >
              <Icon className="h-[18px] w-[18px]" />
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="border-t border-line p-3">
          <NavLink to="/" className="flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm text-white/65 transition hover:bg-white/5 hover:text-white">
            <LogOut className="h-[18px] w-[18px]" />
            Back to website
          </NavLink>
        </div>
      </aside>
    </>
  );
}
