import type { Screen, Seat } from '@/types';

/**
 * Pure layout maths for the 3D auditorium. Units are metres.
 *
 *   -z  = the screen wall        +z = the back of the hall
 *   +y  = up                     x  = left / right, centred on 0
 *
 * Row A is closest to the screen, matching the existing 2D seat map.
 * Seats are placed from the same `Seat[]` the 2D map uses, so booking
 * logic does not change.
 */
export const SEAT_PITCH = 0.66;
export const CENTER_AISLE = 1.3;
export const SIDE_AISLE = 1.5;
export const WALL_INSET = 0.15;
export const FRONT_GAP = 5.2; // stage space between the screen wall and row A
export const BACK_GAP = 1.6;
export const STEP_RISE = 0.26;
export const ROW_DEPTH = { standard: 1.2, premium: 1.55 } as const;
export const SCREEN_WIDTH = 11.4;
export const SCREEN_HEIGHT = (SCREEN_WIDTH * 9) / 16;
export const SCREEN_BOTTOM = 1.5;
export const EYE_HEIGHT = 1.15; // eyes above the seat's floor

export interface RowLayout {
  label: string;
  index: number;
  z: number;
  /** Height of the step this row sits on. */
  y: number;
  depth: number;
  premium: boolean;
}

export interface SeatPlacement {
  seat: Seat;
  x: number;
  y: number;
  z: number;
  rowIndex: number;
}

export interface AuditoriumLayout {
  width: number;
  length: number;
  height: number;
  rows: RowLayout[];
  placements: SeatPlacement[];
  byId: Map<string, SeatPlacement>;
  screen: { z: number; centerY: number; width: number; height: number };
  /** The centre of the seating area, used as the default camera target. */
  center: { x: number; y: number; z: number };
  aisleAfter: number;
}

export function buildAuditoriumLayout(seats: Seat[], screen: Pick<Screen, 'seatsPerRow'>): AuditoriumLayout {
  const perRow = screen?.seatsPerRow || 14;
  const aisleAfter = Math.floor(perRow / 2);

  const rowMap = new Map<string, Seat[]>();
  (seats || []).forEach((s) => rowMap.set(s.row, [...(rowMap.get(s.row) ?? []), s]));
  const rowLabels = [...rowMap.keys()].sort();

  const width = perRow * SEAT_PITCH + CENTER_AISLE + SIDE_AISLE * 2 + WALL_INSET * 2;

  let z = FRONT_GAP;
  let y = 0;
  const rows: RowLayout[] = rowLabels.map((label, index) => {
    const rowSeats = rowMap.get(label) ?? [];
    const premium = rowSeats[0]?.type === 'premium';
    const depth = premium ? ROW_DEPTH.premium : ROW_DEPTH.standard;
    y += STEP_RISE;
    const row: RowLayout = { label, index, z: z + depth / 2, y, depth, premium };
    z += depth;
    return row;
  });
  const length = z + BACK_GAP;
  const lastY = rows.length ? rows[rows.length - 1].y : 0;
  const height = Math.max(9.5, lastY + 7);

  const seatX = (n: number) => {
    const half = CENTER_AISLE / 2;
    return n <= aisleAfter ? -half - (aisleAfter - n + 0.5) * SEAT_PITCH : half + (n - aisleAfter - 0.5) * SEAT_PITCH;
  };

  const placements: SeatPlacement[] = [];
  const byId = new Map<string, SeatPlacement>();
  rows.forEach((row) => {
    const rowSeats = rowMap.get(row.label) ?? [];
    rowSeats.forEach((seat) => {
      const p: SeatPlacement = { seat, x: seatX(seat.number), y: row.y, z: row.z, rowIndex: row.index };
      placements.push(p);
      byId.set(seat.id, p);
    });
  });

  return {
    width,
    length,
    height,
    rows,
    placements,
    byId,
    screen: { z: 0.35, centerY: SCREEN_BOTTOM + SCREEN_HEIGHT / 2, width: SCREEN_WIDTH, height: SCREEN_HEIGHT },
    center: { x: 0, y: Math.max(1.4, lastY * 0.5 + 1), z: FRONT_GAP + (length - FRONT_GAP) * 0.45 },
    aisleAfter,
  };
}

export type ViewQuality = 'Excellent' | 'Great' | 'Good' | 'Close to the screen' | 'Far from the screen' | 'Steep side angle';

export interface SeatViewInfo {
  distance: number; // metres from the screen
  sideAngle: number; // degrees off the centre line
  quality: ViewQuality;
  zone: 'Left side' | 'Left centre' | 'Centre' | 'Right centre' | 'Right side';
}

/** Rough, friendly viewing guidance. A heuristic, not an acoustic or optical study. */
export function describeSeatView(layout: AuditoriumLayout, id: string): SeatViewInfo | null {
  const p = layout.byId.get(id);
  if (!p) return null;
  const dz = p.z - layout.screen.z;
  const distance = Math.hypot(dz, p.x);
  const sideAngle = (Math.atan2(Math.abs(p.x), dz) * 180) / Math.PI;
  const depthFraction = (p.z - FRONT_GAP) / Math.max(1, layout.length - FRONT_GAP - BACK_GAP);

  let quality: ViewQuality;
  if (sideAngle > 32) quality = 'Steep side angle';
  else if (depthFraction < 0.18) quality = 'Close to the screen';
  else if (depthFraction > 0.92) quality = 'Far from the screen';
  else if (depthFraction >= 0.42 && depthFraction <= 0.78 && sideAngle < 14) quality = 'Excellent';
  else if (sideAngle < 22) quality = 'Great';
  else quality = 'Good';

  const edge = layout.width / 2;
  const ratio = p.x / edge;
  const zone = ratio < -0.55 ? 'Left side' : ratio < -0.12 ? 'Left centre' : ratio <= 0.12 ? 'Centre' : ratio <= 0.55 ? 'Right centre' : 'Right side';
  return { distance, sideAngle, quality, zone };
}
