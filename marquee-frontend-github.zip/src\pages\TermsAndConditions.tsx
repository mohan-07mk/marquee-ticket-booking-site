import { Link } from 'react-router-dom';
import { ChevronLeft, FileText, Mail, ShieldAlert, Ticket } from 'lucide-react';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';

export default function TermsAndConditions() {
  useDocumentTitle('Terms & Conditions | Marquee');

  return (
    <div className="container-page py-10 sm:py-16">
      <Link
        to="/"
        className="mb-6 inline-flex items-center gap-1 text-sm text-muted transition hover:text-white"
      >
        <ChevronLeft className="h-4 w-4" />
        Back to Home
      </Link>

      <div className="mx-auto max-w-4xl">
        <header className="mb-10 border-b border-line pb-8">
          <div className="inline-flex items-center gap-2 rounded-full border border-red-500/20 bg-red-500/10 px-3 py-1 text-xs font-semibold text-red-400">
            <FileText className="h-3.5 w-3.5" /> Terms of Service
          </div>
          <h1 className="mt-3 font-display text-4xl font-extrabold tracking-tight text-white sm:text-5xl">
            Terms &amp; Conditions
          </h1>
          <p className="mt-2 text-sm text-muted sm:text-base">
            Last updated: September 23, 2026. Please read these terms carefully before booking tickets on Marquee.
          </p>
        </header>

        <div className="space-y-10 text-sm leading-relaxed text-muted sm:text-base">
          {/* Section 1: Introduction & Accounts */}
          <section className="rounded-3xl border border-line bg-surface/60 p-6 sm:p-8">
            <h2 className="font-display text-xl font-bold text-white sm:text-2xl">1. Introduction &amp; 2. User Accounts</h2>
            <p className="mt-3">
              These Terms &amp; Conditions (&quot;Terms&quot;) govern your access to and use of the Marquee online movie ticket booking platform. By accessing our website, creating an account, or purchasing movie tickets, you agree to be bound by these Terms.
            </p>
            <p className="mt-3">
              You are responsible for maintaining the confidentiality of your account credentials and for all activities conducted under your account.
            </p>
          </section>

          {/* Section 3, 4, 5: Movie Info, Ticket Booking, Seat Selection */}
          <section className="rounded-3xl border border-line bg-surface/60 p-6 sm:p-8">
            <div className="flex items-center gap-3">
              <div className="rounded-xl bg-red-500/10 p-2 text-red-400">
                <Ticket className="h-5 w-5" />
              </div>
              <h2 className="font-display text-xl font-bold text-white sm:text-2xl">
                3. Movie Information, 4. Ticket Booking &amp; 5. Seat Selection
              </h2>
            </div>
            <p className="mt-3">
              Movie synopses, posters, ratings, formats (2D, 3D, IMAX), showtimes, and seat layouts displayed on Marquee are provided for convenience. Seat selections made during booking are subject to real-time availability and double-booking protection checks.
            </p>
          </section>

          {/* Section 6, 7, 8, 9: Pricing, Fees, Payments, Confirmation */}
          <section className="rounded-3xl border border-line bg-surface/60 p-6 sm:p-8">
            <h2 className="font-display text-xl font-bold text-white sm:text-2xl">
              6. Pricing, 7. Convenience Fees, 8. Payments &amp; 9. Confirmation
            </h2>
            <p className="mt-3">
              Ticket prices are set per show and seat type (Standard / Premium). A nominal internet convenience fee (₹30 per seat) is applied at checkout to cover transaction processing and booking infrastructure.
            </p>
            <p className="mt-3">
              Payments are executed via <strong>Razorpay</strong>. Upon successful HMAC signature verification, a unique booking reference (format: <code className="text-white">MQ-XXXXXXXX</code>) is issued and a confirmation email is dispatched via Resend.
            </p>
          </section>

          {/* Section 10 & 11: Cancellation / Refunds & Failed Transactions */}
          <section className="rounded-3xl border border-line bg-surface/60 p-6 sm:p-8">
            <div className="flex items-center gap-3">
              <div className="rounded-xl bg-amber-500/10 p-2 text-amber-400">
                <ShieldAlert className="h-5 w-5" />
              </div>
              <h2 className="font-display text-xl font-bold text-white sm:text-2xl">
                10. Cancellation / Refunds &amp; 11. Failed Transactions
              </h2>
            </div>
            <div className="mt-3 space-y-3">
              <p>
                <strong>Cancellation &amp; Refund Policy:</strong> Ticket cancellation and refund rules are subject to the specific policy displayed during checkout or determined by individual partner cinema theatres. Unless explicitly specified otherwise on your ticket, confirmed movie bookings are generally non-refundable once the showtime has commenced.
              </p>
              <p>
                <strong>Failed or Conflicted Transactions:</strong> If your payment is debited by Razorpay but the booking fails (for example, due to a seat conflict right before confirmation), an automatic refund will be triggered to your original payment method or logged for manual processing by our support team.
              </p>
            </div>
          </section>

          {/* Section 12 & 13: User Responsibilities & Prohibited Activities */}
          <section className="rounded-3xl border border-line bg-surface/60 p-6 sm:p-8">
            <h2 className="font-display text-xl font-bold text-white sm:text-2xl">
              12. User Responsibilities &amp; 13. Prohibited Activities
            </h2>
            <ul className="mt-3 list-disc space-y-2 pl-5">
              <li>You must provide accurate personal and payment information during checkout.</li>
              <li>You agree not to use automated scripts, bots, or scrapers to lock seats or manipulate showtimes.</li>
              <li>Reselling or commercial scalping of tickets purchased on Marquee is strictly prohibited.</li>
            </ul>
          </section>

          {/* Section 14, 15, 16, 17: Availability, Third Parties, IP, Limitation of Liability */}
          <section className="rounded-3xl border border-line bg-surface/60 p-6 sm:p-8">
            <h2 className="font-display text-xl font-bold text-white sm:text-2xl">
              14. Availability, 15. Third-Party Services, 16. IP &amp; 17. Liability
            </h2>
            <p className="mt-3">
              Marquee strives for continuous system uptime but does not guarantee uninterrupted service during maintenance or external network outages. All logos, branding, and original platform designs are intellectual property of Marquee.
            </p>
            <p className="mt-3">
              To the maximum extent permitted by law, Marquee shall not be liable for indirect, incidental, or consequential damages resulting from third-party cinema delays, show cancellations by theatres, or payment gateway processor outages.
            </p>
          </section>

          {/* Section 18 & 19: Changes & Contact */}
          <section className="rounded-3xl border border-line bg-surface/60 p-6 sm:p-8">
            <h2 className="font-display text-xl font-bold text-white sm:text-2xl">
              18. Changes to Terms &amp; 19. Contact Information
            </h2>
            <p className="mt-3">
              We reserve the right to modify these Terms at any time. Continued use of the platform following updates constitutes acceptance of the revised Terms.
            </p>
            <p className="mt-4 flex items-center gap-2">
              <Mail className="h-4 w-4 text-red-400" />
              Questions regarding these Terms should be sent to: <a href="mailto:support@marquee.com" className="text-white underline hover:text-red-400">support@marquee.com</a>
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}
