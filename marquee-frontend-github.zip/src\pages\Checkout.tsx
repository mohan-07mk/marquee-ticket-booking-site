import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AlertCircle, ChevronLeft, CreditCard, Landmark, Lock, Smartphone, Ticket } from 'lucide-react';
import { BookingSummary } from '@/components/BookingSummary';
import { PaymentCard } from '@/components/PaymentCard';
import { Button, buttonClasses } from '@/components/ui/Button';
import { Field, Input } from '@/components/ui/Field';
import { Skeleton } from '@/components/ui/Skeleton';
import { EmptyState, ErrorState } from '@/components/ui/States';
import { useAuth } from '@/context/AuthContext';
import { useBooking } from '@/context/BookingContext';
import { useToast } from '@/context/ToastContext';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { api } from '@/services/api';
import type { PaymentMethod } from '@/types';
import { cn } from '@/utils/cn';
import { formatCurrency } from '@/utils/format';
import { calcTotals } from '@/utils/pricing';

const BANKS = ['State Bank', 'HDFC Bank', 'ICICI Bank', 'Axis Bank', 'Kotak Bank', 'Canara Bank'];
const UPI_APPS = ['GPay', 'PhonePe', 'Paytm'];
const DECLINE_TEST_CARD = '4000000000000002';

type Errors = Partial<Record<'upi' | 'cardNumber' | 'cardName' | 'expiry' | 'cvv' | 'bank', string>>;

const formatCardNumber = (v: string) => v.replace(/\D/g, '').slice(0, 16).replace(/(.{4})/g, '$1 ').trim();
const formatExpiry = (v: string) => {
  const d = v.replace(/\D/g, '').slice(0, 4);
  return d.length > 2 ? `${d.slice(0, 2)}/${d.slice(2)}` : d;
};

function expiryValid(v: string) {
  const m = /^(\d{2})\/(\d{2})$/.exec(v);
  if (!m) return false;
  const month = Number(m[1]);
  const year = 2000 + Number(m[2]);
  if (month < 1 || month > 12) return false;
  return new Date(year, month, 0, 23, 59) >= new Date();
}

export default function Checkout() {
  useDocumentTitle('Checkout');
  const navigate = useNavigate();
  const toast = useToast();
  const { user } = useAuth();
  const { draft, clearDraft } = useBooking();

  const details = useAsync(() => (draft.showId ? api.shows.getDetails(draft.showId) : Promise.resolve(null)), [draft.showId]);

  const [method, setMethod] = useState<PaymentMethod>('upi');
  const [upi, setUpi] = useState('');
  const [card, setCard] = useState({ number: '', name: '', expiry: '', cvv: '' });
  const [bank, setBank] = useState('');
  const [errors, setErrors] = useState<Errors>({});
  const [paying, setPaying] = useState(false);
  const [payError, setPayError] = useState<string | null>(null);

  if (!draft.showId || draft.seats.length === 0) {
    return (
      <div className="container-page py-16">
        <EmptyState
          icon={Ticket}
          title="No seats selected"
          description="Pick a show and choose your seats before heading to payment."
          action={
            <Link to="/booking" className={buttonClasses()}>
              Choose a movie
            </Link>
          }
        />
      </div>
    );
  }

  if (details.error) {
    return (
      <div className="container-page py-16">
        <ErrorState message={details.error} onRetry={details.reload} />
      </div>
    );
  }

  if (details.loading || !details.data) {
    return (
      <div className="container-page grid gap-8 py-10 lg:grid-cols-[1fr_400px]">
        <Skeleton className="h-[520px]" />
        <Skeleton className="h-[520px]" />
      </div>
    );
  }

  const { total } = calcTotals(draft.seats);

  const validate = (): Errors => {
    const e: Errors = {};
    if (method === 'upi' && !/^[\w.-]{2,}@[a-zA-Z]{2,}$/.test(upi.trim())) e.upi = 'Enter a valid UPI ID, like name@bank.';
    if (method === 'card') {
      if (card.number.replace(/\s/g, '').length !== 16) e.cardNumber = 'Card number must be 16 digits.';
      if (!card.name.trim()) e.cardName = 'Enter the name on the card.';
      if (!expiryValid(card.expiry)) e.expiry = 'Enter a valid future date (MM/YY).';
      if (!/^\d{3,4}$/.test(card.cvv)) e.cvv = 'CVV must be 3 or 4 digits.';
    }
    if (method === 'netbanking' && !bank) e.bank = 'Choose your bank to continue.';
    return e;
  };

  const pay = async () => {
    const e = validate();
    setErrors(e);
    setPayError(null);
    if (Object.keys(e).length) {
      toast.error('Check your payment details');
      return;
    }
    setPaying(true);
    try {
      // 1. Create Razorpay Order on server via Edge Function (amount calculated on server)
      const orderData = await api.bookings.createRazorpayOrder({
        showId: draft.showId!,
        seats: draft.seats,
      });

      const keyId = orderData.keyId || (import.meta.env.VITE_RAZORPAY_KEY_ID as string) || 'rzp_test_mock_key';

      // 2. Open Razorpay Standard Checkout Popup Modal
      const options = {
        key: keyId,
        amount: orderData.amount,
        currency: orderData.currency || 'INR',
        name: 'Marquee Cinemas',
        description: `Booking for ${details.data?.movie.title || 'Movie'} (${draft.seats.length} seat${draft.seats.length > 1 ? 's' : ''})`,
        image: details.data?.movie.posterUrl || undefined,
        order_id: orderData.orderId,
        prefill: {
          name: user?.name || (card.name ? card.name : undefined),
          email: user?.email || undefined,
          contact: user?.phone || undefined,
        },
        theme: {
          color: '#e50914',
        },
        handler: async (response: {
          razorpay_payment_id: string;
          razorpay_order_id: string;
          razorpay_signature: string;
        }) => {
          try {
            // 3. Verify server-side HMAC SHA256 signature & finalize booking via Edge Function
            const result = await api.bookings.verifyRazorpayPayment({
              razorpay_order_id: response.razorpay_order_id,
              razorpay_payment_id: response.razorpay_payment_id,
              razorpay_signature: response.razorpay_signature,
              showId: draft.showId!,
              seats: draft.seats,
              paymentMethod: method,
              customerName: user?.name || card.name || undefined,
            });

            clearDraft();
            toast.success('Booking confirmed', `Your tickets for ${details.data?.movie.title} are ready!`);
            navigate(`/booking-confirmation/${result.bookingId}`, { replace: true });
          } catch (verifyErr) {
            const message = verifyErr instanceof Error ? verifyErr.message : 'Payment verification failed.';
            setPayError(message);
            toast.error('Payment verification failed', message);
            setPaying(false);
          }
        },
        modal: {
          ondismiss: () => {
            setPaying(false);
            toast.info('Payment cancelled', 'You closed the Razorpay payment window.');
          },
        },
      };

      if (typeof window !== 'undefined' && (window as any).Razorpay) {
        const rzp = new (window as any).Razorpay(options);
        rzp.on('payment.failed', (resp: any) => {
          setPaying(false);
          const failMsg = resp.error?.description || 'Payment failed on Razorpay.';
          setPayError(failMsg);
          toast.error('Payment failed', failMsg);
        });
        rzp.open();
      } else {
        // Fallback for development if SDK script load is delayed
        const result = await api.bookings.verifyRazorpayPayment({
          razorpay_order_id: orderData.orderId,
          razorpay_payment_id: `pay_${Date.now()}`,
          razorpay_signature: 'mock_dev_signature',
          showId: draft.showId!,
          seats: draft.seats,
          paymentMethod: method,
          customerName: user?.name || card.name || undefined,
        });

        clearDraft();
        toast.success('Booking confirmed', `Your tickets for ${details.data?.movie.title} are ready!`);
        navigate(`/booking-confirmation/${result.bookingId}`, { replace: true });
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Payment failed. Please try again.';
      setPayError(message);
      toast.error('Payment failed', message);
      setPaying(false);
    }
  };

  return (
    <div className="container-page py-8 sm:py-12">
      <Link to={`/booking/seats?showId=${draft.showId}`} className="mb-5 inline-flex items-center gap-1 text-sm text-muted transition hover:text-white">
        <ChevronLeft className="h-4 w-4" />
        Change seats
      </Link>
      <header className="mb-8">
        <p className="text-sm text-muted">Step 3 of 3: payment</p>
        <h1 className="mt-1 font-display text-4xl font-extrabold leading-none sm:text-6xl">Checkout</h1>
      </header>

      <div className="grid items-start gap-8 lg:grid-cols-[1fr_400px]">
        <section aria-labelledby="pay-heading">
          <h2 id="pay-heading" className="mb-4 text-lg font-semibold">
            Choose a payment method
          </h2>

          {payError && (
            <div role="alert" className="mb-4 flex items-start gap-3 rounded-2xl border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-200">
              <AlertCircle className="mt-0.5 h-5 w-5 shrink-0" />
              <div>
                <p className="font-semibold">Payment failed</p>
                <p className="mt-0.5 text-red-200/80">{payError}</p>
              </div>
            </div>
          )}

          <div role="radiogroup" aria-label="Payment method" className="space-y-3">
            <PaymentCard id="upi" title="UPI" description="Pay with any UPI app" icon={Smartphone} selected={method === 'upi'} onSelect={setMethod}>
              <div className="space-y-4">
                <div className="flex flex-wrap gap-2">
                  {UPI_APPS.map((a) => (
                    <button
                      key={a}
                      type="button"
                      onClick={() => setUpi(`yourname@${a.toLowerCase()}`)}
                      className="rounded-full border border-line px-4 py-1.5 text-sm text-white/80 transition hover:border-white/40 hover:text-white"
                    >
                      {a}
                    </button>
                  ))}
                </div>
                <Field label="UPI ID" htmlFor="upi" error={errors.upi}>
                  <Input id="upi" placeholder="name@bank" value={upi} invalid={!!errors.upi} onChange={(e) => setUpi(e.target.value)} autoComplete="off" />
                </Field>
              </div>
            </PaymentCard>

            <PaymentCard id="card" title="Credit or debit card" description="Visa, Mastercard, RuPay" icon={CreditCard} selected={method === 'card'} onSelect={setMethod}>
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Card number" htmlFor="cc-number" error={errors.cardNumber} className="sm:col-span-2" hint={`To preview a declined payment, use ${formatCardNumber(DECLINE_TEST_CARD)}.`}>
                  <Input id="cc-number" inputMode="numeric" autoComplete="cc-number" placeholder="1234 5678 9012 3456" value={card.number} invalid={!!errors.cardNumber} onChange={(e) => setCard({ ...card, number: formatCardNumber(e.target.value) })} />
                </Field>
                <Field label="Name on card" htmlFor="cc-name" error={errors.cardName} className="sm:col-span-2">
                  <Input id="cc-name" autoComplete="cc-name" placeholder="As printed on the card" value={card.name} invalid={!!errors.cardName} onChange={(e) => setCard({ ...card, name: e.target.value })} />
                </Field>
                <Field label="Expiry" htmlFor="cc-exp" error={errors.expiry}>
                  <Input id="cc-exp" inputMode="numeric" autoComplete="cc-exp" placeholder="MM/YY" value={card.expiry} invalid={!!errors.expiry} onChange={(e) => setCard({ ...card, expiry: formatExpiry(e.target.value) })} />
                </Field>
                <Field label="CVV" htmlFor="cc-cvv" error={errors.cvv}>
                  <Input id="cc-cvv" type="password" inputMode="numeric" autoComplete="cc-csc" maxLength={4} placeholder="123" value={card.cvv} invalid={!!errors.cvv} onChange={(e) => setCard({ ...card, cvv: e.target.value.replace(/\D/g, '') })} />
                </Field>
              </div>
            </PaymentCard>

            <PaymentCard id="netbanking" title="Net banking" description="Pay from your bank account" icon={Landmark} selected={method === 'netbanking'} onSelect={setMethod}>
              <div>
                <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-3">
                  {BANKS.map((b) => (
                    <button
                      key={b}
                      type="button"
                      aria-pressed={bank === b}
                      onClick={() => setBank(b)}
                      className={cn(
                        'rounded-xl border px-3 py-3 text-sm font-medium transition',
                        bank === b ? 'border-brand bg-brand/15 text-white' : 'border-line text-white/75 hover:border-white/40',
                      )}
                    >
                      {b}
                    </button>
                  ))}
                </div>
                {errors.bank && (
                  <p role="alert" className="mt-2 text-xs text-red-400">
                    {errors.bank}
                  </p>
                )}
              </div>
            </PaymentCard>
          </div>

          <p className="mt-5 flex items-center gap-2 text-sm text-muted">
            <Lock className="h-4 w-4" />
            Payments are processed securely via Razorpay in Test Mode.
          </p>
        </section>

        <div className="lg:sticky lg:top-24">
          <BookingSummary
            details={details.data}
            seats={draft.seats}
            cta={
              <Button size="lg" className="w-full" loading={paying} onClick={pay}>
                {paying ? 'Processing payment' : `Pay ${formatCurrency(total)} & Confirm Booking`}
              </Button>
            }
          />
        </div>
      </div>
    </div>
  );
}
