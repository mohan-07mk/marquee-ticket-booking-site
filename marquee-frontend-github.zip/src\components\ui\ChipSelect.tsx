import { cn } from '@/utils/cn';

/** Multi-select rendered as toggle chips. */
export function ChipSelect<T extends string>({
  options,
  value,
  onChange,
  label,
}: {
  options: readonly T[];
  value: T[];
  onChange: (next: T[]) => void;
  label: string;
}) {
  const toggle = (o: T) => onChange(value.includes(o) ? value.filter((v) => v !== o) : [...value, o]);
  return (
    <div className="flex flex-wrap gap-2" role="group" aria-label={label}>
      {options.map((o) => {
        const on = value.includes(o);
        return (
          <button
            key={o}
            type="button"
            aria-pressed={on}
            onClick={() => toggle(o)}
            className={cn(
              'rounded-full border px-3.5 py-1.5 text-sm transition',
              on ? 'border-brand bg-brand/15 text-white' : 'border-line text-white/65 hover:border-white/40',
            )}
          >
            {o}
          </button>
        );
      })}
    </div>
  );
}
