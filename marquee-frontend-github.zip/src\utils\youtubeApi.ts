/**
 * Loads the YouTube IFrame Player API once. It lets us find out when a video
 * cannot be embedded (private, removed, embedding disabled) so the cinema
 * screen can show a fallback instead of YouTube's error page.
 * If the script is blocked or offline the promise rejects and callers simply
 * keep showing the iframe.
 */
export interface YTPlayerEvent {
  data: number;
}
export interface YTPlayer {
  destroy?: () => void;
}
export interface YTNamespace {
  Player: new (
    el: HTMLIFrameElement,
    opts: { events?: { onReady?: () => void; onError?: (e: YTPlayerEvent) => void } },
  ) => YTPlayer;
}

declare global {
  interface Window {
    YT?: YTNamespace;
    onYouTubeIframeAPIReady?: () => void;
  }
}

let pending: Promise<YTNamespace> | null = null;

export function loadYouTubeApi(): Promise<YTNamespace> {
  if (typeof window === 'undefined') return Promise.reject(new Error('No window'));
  if (window.YT?.Player) return Promise.resolve(window.YT);
  if (pending) return pending;

  pending = new Promise<YTNamespace>((resolve, reject) => {
    const previous = window.onYouTubeIframeAPIReady;
    window.onYouTubeIframeAPIReady = () => {
      previous?.();
      if (window.YT?.Player) resolve(window.YT);
      else reject(new Error('YouTube API unavailable'));
    };
    const script = document.createElement('script');
    script.src = 'https://www.youtube.com/iframe_api';
    script.async = true;
    script.onerror = () => {
      pending = null;
      reject(new Error('YouTube API failed to load'));
    };
    document.head.appendChild(script);
    window.setTimeout(() => {
      if (!window.YT?.Player) {
        pending = null;
        reject(new Error('YouTube API timed out'));
      }
    }, 8000);
  });
  return pending;
}

export function describeYouTubeError(code: number): string {
  switch (code) {
    case 2:
      return 'This YouTube link isn’t valid.';
    case 5:
      return 'Your browser couldn’t play this video.';
    case 100:
      return 'This video was removed or is private.';
    case 101:
    case 150:
      return 'The video owner doesn’t allow it to play outside YouTube.';
    default:
      return 'This video can’t be played here.';
  }
}
