import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
import type { Seat } from '@/types';

/**
 * Holds the in-progress booking between Seat selection -> Checkout.
 * Persisted in sessionStorage so a page refresh doesn't lose the selection.
 */
interface Draft {
  showId: string | null;
  seats: Seat[];
}
interface BookingState {
  draft: Draft;
  setDraft: (draft: Draft) => void;
  clearDraft: () => void;
}

const BookingContext = createContext<BookingState | null>(null);
const KEY = 'marquee.draft';
const empty: Draft = { showId: null, seats: [] };

const read = (): Draft => {
  try {
    const raw = sessionStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Draft) : empty;
  } catch {
    return empty;
  }
};

export function BookingProvider({ children }: { children: ReactNode }) {
  const [draft, setDraftState] = useState<Draft>(read);

  const setDraft = useCallback((d: Draft) => {
    setDraftState(d);
    try {
      sessionStorage.setItem(KEY, JSON.stringify(d));
    } catch {
      /* ignore */
    }
  }, []);

  const clearDraft = useCallback(() => setDraft(empty), [setDraft]);
  const value = useMemo(() => ({ draft, setDraft, clearDraft }), [draft, setDraft, clearDraft]);

  return <BookingContext.Provider value={value}>{children}</BookingContext.Provider>;
}

export function useBooking() {
  const ctx = useContext(BookingContext);
  if (!ctx) throw new Error('useBooking must be used inside <BookingProvider>');
  return ctx;
}
