import { useEffect, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { AlertCircle, CheckCircle2, Eye, EyeOff, Lock } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Field, Input } from '@/components/ui/Field';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { supabase } from '@/lib/supabase';

export default function ResetPassword() {
  useDocumentTitle('Set new password');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [show, setShow] = useState(false);
  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(true);
  const [hasSession, setHasSession] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    let mounted = true;
    const hash = window.location.hash || '';
    const isRecovery = hash.includes('type=recovery') || hash.includes('access_token=');

    supabase.auth
      .getSession()
      .then(({ data: { session } }) => {
        if (mounted) {
          if (session || isRecovery) {
            setHasSession(true);
          }
          setChecking(false);
        }
      })
      .catch(() => {
        if (mounted) {
          if (isRecovery) setHasSession(true);
          setChecking(false);
        }
      });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === 'PASSWORD_RECOVERY' || (session && isRecovery)) {
        if (mounted) setHasSession(true);
      }
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!password) {
      setError('Please enter a new password.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters long.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    setError(null);
    setLoading(true);

    try {
      const { error: updateErr } = await supabase.auth.updateUser({ password });
      if (updateErr) {
        setError(updateErr.message);
      } else {
        setSuccess(true);
        await supabase.auth.signOut();
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not update password. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (checking) {
    return (
      <div className="animate-fade-in text-center py-12">
        <p className="text-muted">Verifying recovery session...</p>
      </div>
    );
  }

  if (success) {
    return (
      <div className="animate-fade-in">
        <span className="mb-5 grid h-14 w-14 place-items-center rounded-2xl bg-emerald-500/15 text-emerald-400">
          <CheckCircle2 className="h-7 w-7" />
        </span>
        <h1 className="font-display text-5xl font-extrabold leading-none">Password updated!</h1>
        <p className="mt-3 text-muted">
          Your password has been changed successfully. You can now log in with your new password.
        </p>
        <Link to="/login" className="mt-8 block">
          <Button size="lg" className="w-full">
            Go to log in
          </Button>
        </Link>
      </div>
    );
  }

  if (!hasSession) {
    return (
      <div className="animate-fade-in">
        <div role="alert" className="mb-6 flex items-start gap-2.5 rounded-xl border border-amber-500/30 bg-amber-500/10 p-4 text-sm text-amber-200">
          <AlertCircle className="mt-0.5 h-5 w-5 shrink-0 text-amber-400" />
          <div>
            <p className="font-semibold text-white">Invalid or expired recovery link</p>
            <p className="mt-1 text-amber-200/80">The password recovery link may have expired or is invalid. Please request a new link.</p>
          </div>
        </div>
        <Link to="/forgot-password" className="block">
          <Button size="lg" className="w-full">
            Request new reset link
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <h1 className="font-display text-5xl font-extrabold leading-none">Set new password</h1>
      <p className="mt-3 text-muted">Enter your new password below to update your account.</p>

      <form onSubmit={handleSubmit} noValidate className="mt-8 space-y-5">
        {error && (
          <div role="alert" className="flex items-start gap-2.5 rounded-xl border border-red-500/30 bg-red-500/10 p-3.5 text-sm text-red-200">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
            {error}
          </div>
        )}

        <Field label="New Password" htmlFor="new-password">
          <Input
            id="new-password"
            type={show ? 'text' : 'password'}
            autoComplete="new-password"
            placeholder="At least 6 characters"
            icon={<Lock className="h-4 w-4" />}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            rightSlot={
              <button type="button" onClick={() => setShow((s) => !s)} aria-label={show ? 'Hide password' : 'Show password'} className="rounded-lg p-2 text-muted transition hover:text-white">
                {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            }
          />
        </Field>

        <Field label="Confirm Password" htmlFor="confirm-password">
          <Input
            id="confirm-password"
            type={show ? 'text' : 'password'}
            autoComplete="new-password"
            placeholder="Re-enter new password"
            icon={<Lock className="h-4 w-4" />}
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
          />
        </Field>

        <Button type="submit" size="lg" className="w-full" loading={loading}>
          Update Password
        </Button>
      </form>
    </div>
  );
}
