import { Link } from 'react-router-dom';
import { BellRing, Clock, Star } from 'lucide-react';
import type { Movie } from '@/types';
import { useToast } from '@/context/ToastContext';
import { formatDate, formatDuration } from '@/utils/format';
import { Button, buttonClasses } from './ui/Button';

export function MovieCard({ movie }: { movie: Movie }) {
  const toast = useToast();
  const comingSoon = movie.status === 'coming_soon';

  return (
    <article className="group flex flex-col">
      <Link
        to={`/movies/${movie.id}`}
        className="relative block overflow-hidden rounded-2xl border border-line bg-surface transition duration-300 group-hover:-translate-y-1 group-hover:border-brand/60 group-hover:shadow-[0_18px_40px_-18px_rgba(225,29,46,.55)]"
        aria-label={`${movie.title}, view details`}
      >
        <img
          src={movie.posterUrl}
          alt={`${movie.title} poster`}
          loading="lazy"
          className="aspect-[2/3] w-full object-cover transition duration-500 group-hover:scale-105"
        />
        {!comingSoon && movie.rating > 0 && (
          <span className="absolute left-2.5 top-2.5 inline-flex items-center gap-1 rounded-full bg-black/75 px-2.5 py-1 text-xs font-semibold backdrop-blur">
            <Star className="h-3.5 w-3.5 fill-gold text-gold" />
            {movie.rating.toFixed(1)}
          </span>
        )}
        <span className="absolute right-2.5 top-2.5 rounded-md border border-white/25 bg-black/60 px-1.5 py-0.5 text-[11px] font-semibold backdrop-blur">
          {movie.certificate}
        </span>
        {comingSoon && (
          <span className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 to-transparent px-3 pb-3 pt-10 text-xs font-medium text-white/90">
            Releases {formatDate(movie.releaseDate)}
          </span>
        )}
      </Link>

      <div className="mt-3 flex-1 space-y-1.5">
        <h3 className="line-clamp-1 font-display text-[22px] font-bold leading-tight">
          <Link to={`/movies/${movie.id}`} className="transition hover:text-brand-hover">
            {movie.title}
          </Link>
        </h3>
        <p className="line-clamp-1 text-sm text-white/70">{movie.languages.join(', ')}</p>
        <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
          {movie.genres.map((g) => (
            <span key={g} className="rounded-full border border-line px-2 py-0.5 text-xs text-muted">
              {g}
            </span>
          ))}
          <span className="inline-flex items-center gap-1 text-xs text-muted">
            <Clock className="h-3.5 w-3.5" />
            {formatDuration(movie.durationMin)}
          </span>
        </div>
      </div>

      {comingSoon ? (
        <Button
          variant="outline"
          className="mt-3 w-full"
          leftIcon={<BellRing className="h-4 w-4" />}
          onClick={() => toast.success('You’re on the list', `We’ll let you know when ${movie.title} opens for booking.`)}
        >
          Notify me
        </Button>
      ) : (
        <Link to={`/booking?movieId=${movie.id}`} className={buttonClasses({ className: 'mt-3 w-full' })}>
          Book now
        </Link>
      )}
    </article>
  );
}
