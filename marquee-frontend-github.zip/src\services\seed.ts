import { supabase } from '@/lib/supabase';
import { addDays, toDateKey } from '@/utils/format';
import { makeArt } from '@/utils/poster';
import { standardPrice } from '@/utils/pricing';

const rel = (days: number) => toDateKey(addDays(new Date(), days));

export async function seedDatabaseIfNeeded() {
  try {
    // Check if movies table has rows
    const { count, error } = await supabase.from('movies').select('*', { count: 'exact', head: true });
    if (error || (count !== null && count > 0)) {
      return; // Already populated or error
    }

    console.log('Database empty. Seeding initial data to Supabase...');

    // 1. Seed Movies
    const seedMovies = [
      {
        title: 'Crimson Horizon',
        description: 'When a deep-space relay goes silent, a disgraced flight engineer is the only person who can reach it in time. Every light-year closer to the signal, the crew learns that someone got there first.',
        genres: ['Sci-Fi', 'Action'],
        languages: ['Tamil', 'English'],
        formats: ['2D', '3D', 'IMAX'],
        duration: 148,
        release_date: rel(-9),
        rating: 8.4,
        poster_url: makeArt('Crimson Horizon', 1, 'poster'),
        backdrop_url: makeArt('Crimson Horizon', 1, 'backdrop'),
        trailer_url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
        status: 'now_showing',
      },
      {
        title: 'Monsoon Protocol',
        description: 'A city under three days of rain, a missing flood-gate log, and a hydrologist who realises the disaster was scheduled. A tight, sweaty thriller told in real time.',
        genres: ['Thriller', 'Drama'],
        languages: ['Hindi'],
        formats: ['2D'],
        duration: 132,
        release_date: rel(-16),
        rating: 7.9,
        poster_url: makeArt('Monsoon Protocol', 2, 'poster'),
        backdrop_url: makeArt('Monsoon Protocol', 2, 'backdrop'),
        trailer_url: '',
        status: 'now_showing',
      },
      {
        title: 'The Great Indian Circus',
        description: 'Set in 1994, a traveling troupe refuses to close their tent despite suburban malls taking over their towns. Heartwarming, noisy, and beautifully shot.',
        genres: ['Comedy', 'Family'],
        languages: ['Hindi', 'Malayalam'],
        formats: ['2D'],
        duration: 124,
        release_date: rel(-3),
        rating: 8.8,
        poster_url: makeArt('The Great Indian Circus', 3, 'poster'),
        backdrop_url: makeArt('The Great Indian Circus', 3, 'backdrop'),
        trailer_url: '',
        status: 'now_showing',
      },
      {
        title: 'Shadow over Shanti Nagar',
        description: 'An investigative journalist reopens an unsolved 1982 burglary case in a quiet mountain town, only to find the suspects are now the town leaders.',
        genres: ['Thriller', 'Sci-Fi'],
        languages: ['Telugu', 'Hindi'],
        formats: ['2D', '3D'],
        duration: 156,
        release_date: rel(-30),
        rating: 8.1,
        poster_url: makeArt('Shadow over Shanti Nagar', 4, 'poster'),
        backdrop_url: makeArt('Shadow over Shanti Nagar', 4, 'backdrop'),
        trailer_url: '',
        status: 'now_showing',
      },
      {
        title: 'Neon Nights: Chapter 1',
        description: 'In a futuristic Mumbai, a cyber-enhanced courier takes a high-value delivery job that turns into a high-stakes escape across neon-lit skyways.',
        genres: ['Action', 'Sci-Fi'],
        languages: ['English', 'Hindi'],
        formats: ['2D', 'IMAX'],
        duration: 140,
        release_date: rel(7),
        rating: 0,
        poster_url: makeArt('Neon Nights: Chapter 1', 5, 'poster'),
        backdrop_url: makeArt('Neon Nights: Chapter 1', 5, 'backdrop'),
        trailer_url: '',
        status: 'coming_soon',
      },
      {
        title: 'The Lost Kingdom of Hampi',
        description: 'An archaeological expedition stumbles upon hidden chambers beneath ancient ruins, unraveling a century-old royal mystery.',
        genres: ['Adventure', 'Fantasy'],
        languages: ['Kannada', 'Hindi'],
        formats: ['2D', '3D'],
        duration: 162,
        release_date: rel(14),
        rating: 0,
        poster_url: makeArt('The Lost Kingdom of Hampi', 6, 'poster'),
        backdrop_url: makeArt('The Lost Kingdom of Hampi', 6, 'backdrop'),
        trailer_url: '',
        status: 'coming_soon',
      },
    ];

    const { data: moviesData, error: movieErr } = await supabase.from('movies').insert(seedMovies).select();
    if (movieErr || !moviesData) {
      console.error('Error seeding movies:', movieErr);
      return;
    }

    // 2. Seed Theatres & Screens
    const seedTheatres = [
      {
        name: 'Aurora Cinemas',
        location: 'Grand Mall, Central Avenue',
        amenities: ['Dolby Atmos', 'Recliners', 'Food court', 'Parking'],
        status: 'active',
      },
      {
        name: 'Regal Screens Prime',
        location: 'Lakeview Plaza, Lake Road',
        amenities: ['Dolby Atmos', 'Wheelchair access', 'Parking'],
        status: 'active',
      },
      {
        name: 'Starlight Multiplex',
        location: 'Metro Station Mall, West Sector',
        amenities: ['4K Laser', 'Recliners', 'Gourmet menu'],
        status: 'active',
      },
    ];

    const { data: theatresData, error: theatreErr } = await supabase.from('theatres').insert(seedTheatres).select();
    if (theatreErr || !theatresData) {
      console.error('Error seeding theatres:', theatreErr);
      return;
    }

    // Seed Screens & Seats for each theatre
    const screenInserts: Record<string, unknown>[] = [];
    const screenConfigs = [
      { name: 'Screen 1', rows: 12, seatsPerRow: 14, formats: ['IMAX', '2D'] },
      { name: 'Screen 2', rows: 10, seatsPerRow: 14, formats: ['3D', '2D'] },
      { name: 'Screen 3', rows: 9, seatsPerRow: 14, formats: ['2D'] },
    ];

    for (const t of theatresData) {
      for (const sc of screenConfigs) {
        screenInserts.push({
          theatre_id: t.id,
          name: sc.name,
          capacity: sc.rows * sc.seatsPerRow,
          rows: sc.rows,
          seats_per_row: sc.seatsPerRow,
          formats: sc.formats,
        });
      }
    }

    const { data: screensData, error: screensErr } = await supabase.from('screens').insert(screenInserts).select();
    if (screensErr || !screensData) {
      console.error('Error seeding screens:', screensErr);
      return;
    }

    // Seed Seats for screens
    for (const screen of screensData) {
      const seatInserts: Record<string, unknown>[] = [];
      const rows = screen.rows as number;
      const seatsPerRow = screen.seats_per_row as number;
      const premiumFrom = rows - 3;

      for (let r = 0; r < rows; r++) {
        const rowLabel = String.fromCharCode(65 + r);
        for (let n = 1; n <= seatsPerRow; n++) {
          seatInserts.push({
            id: `${screen.id}-${rowLabel}${n}`,
            screen_id: screen.id,
            row_label: rowLabel,
            seat_number: n,
            seat_type: r >= premiumFrom ? 'premium' : 'standard',
          });
        }
      }
      if (seatInserts.length) {
        await supabase.from('seats').insert(seatInserts);
      }
    }

    // 3. Seed Shows for now_showing movies
    const nowShowingMovies = moviesData.filter((m) => m.status === 'now_showing');
    const times = ['10:30', '14:15', '18:00', '21:30'];
    const showInserts: Record<string, unknown>[] = [];

    // Schedule shows for today and next 4 days
    for (let dayOffset = 0; dayOffset < 5; dayOffset++) {
      const dateStr = rel(dayOffset);
      let movieIdx = 0;

      for (const t of theatresData) {
        const tScreens = screensData.filter((s) => s.theatre_id === t.id);
        for (const s of tScreens) {
          const m = nowShowingMovies[movieIdx % nowShowingMovies.length];
          movieIdx++;

          for (const time of times.slice(0, 2)) {
            const fmt = (s.formats as string[])[0] ?? '2D';
            const price = standardPrice(fmt as any, t.id, time);
            showInserts.push({
              movie_id: m.id,
              theatre_id: t.id,
              screen_id: s.id,
              show_date: dateStr,
              show_time: time,
              format: fmt,
              language: (m.languages as string[])[0] ?? 'English',
              price: price,
              premium_price: Math.round((price * 1.5) / 10) * 10,
              status: 'active',
            });
          }
        }
      }
    }

    if (showInserts.length) {
      await supabase.from('shows').insert(showInserts);
    }

    console.log('Supabase seeding complete!');
  } catch (err) {
    console.error('Failed to seed database:', err);
  }
}
