import { useMemo, useState } from 'react';
import { Film, RotateCcw, Search } from 'lucide-react';
import { MovieGrid } from '@/components/MovieGrid';
import { Button } from '@/components/ui/Button';
import { Input, Select } from '@/components/ui/Field';
import { EmptyState, ErrorState } from '@/components/ui/States';
import type { Format } from '@/types';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { api } from '@/services/api';

const GENRES = ['Action', 'Adventure', 'Comedy', 'Drama', 'Family', 'Fantasy', 'Romance', 'Sci-Fi', 'Thriller'];
const LANGUAGES = ['English', 'Hindi', 'Malayalam', 'Tamil', 'Telugu'];
const FORMATS: Format[] = ['2D', '3D', 'IMAX'];

const initial = { q: '', language: 'all', genre: 'all', format: 'all', rating: 'all' };

export default function Movies() {
  useDocumentTitle('Movies');
  const { data, loading, error, reload } = useAsync(() => api.movies.list(), []);
  const [filters, setFilters] = useState(initial);
  const set = (key: keyof typeof initial) => (value: string) => setFilters((f) => ({ ...f, [key]: value }));

  const results = useMemo(() => {
    const q = filters.q.trim().toLowerCase();
    return (data ?? [])
      .filter((m) => !q || m.title.toLowerCase().includes(q) || m.genres.some((g) => g.toLowerCase().includes(q)))
      .filter((m) => filters.language === 'all' || m.languages.includes(filters.language))
      .filter((m) => filters.genre === 'all' || m.genres.includes(filters.genre))
      .filter((m) => filters.format === 'all' || m.formats.includes(filters.format as (typeof FORMATS)[number]))
      .filter((m) => filters.rating === 'all' || m.rating >= Number(filters.rating))
      .sort((a, b) => b.popularity - a.popularity);
  }, [data, filters]);

  const dirty = JSON.stringify(filters) !== JSON.stringify(initial);

  return (
    <div className="container-page py-10 sm:py-14">
      <header className="mb-8">
        <h1 className="font-display text-5xl font-extrabold leading-none sm:text-7xl">Movies</h1>
        <p className="mt-3 text-muted">Search everything playing or opening soon, then narrow it down.</p>
      </header>

      <div className="sticky top-[68px] z-20 -mx-4 mb-8 border-y border-line bg-black/90 px-4 py-4 backdrop-blur-xl sm:mx-0 sm:rounded-3xl sm:border sm:px-5">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-[2fr_repeat(4,1fr)_auto]">
          <Input
            aria-label="Search movies"
            placeholder="Search by title or genre"
            icon={<Search className="h-4 w-4" />}
            value={filters.q}
            onChange={(e) => set('q')(e.target.value)}
            className="sm:col-span-2 lg:col-span-1"
          />
          <Select aria-label="Language" value={filters.language} onChange={(e) => set('language')(e.target.value)}>
            <option value="all">All languages</option>
            {LANGUAGES.map((l) => (
              <option key={l}>{l}</option>
            ))}
          </Select>
          <Select aria-label="Genre" value={filters.genre} onChange={(e) => set('genre')(e.target.value)}>
            <option value="all">All genres</option>
            {GENRES.map((g) => (
              <option key={g}>{g}</option>
            ))}
          </Select>
          <Select aria-label="Format" value={filters.format} onChange={(e) => set('format')(e.target.value)}>
            <option value="all">All formats</option>
            {FORMATS.map((f) => (
              <option key={f}>{f}</option>
            ))}
          </Select>
          <Select aria-label="Rating" value={filters.rating} onChange={(e) => set('rating')(e.target.value)}>
            <option value="all">Any rating</option>
            <option value="8">8.0 and above</option>
            <option value="7">7.0 and above</option>
            <option value="6">6.0 and above</option>
          </Select>
          <Button variant="ghost" disabled={!dirty} onClick={() => setFilters(initial)} leftIcon={<RotateCcw className="h-4 w-4" />}>
            Reset
          </Button>
        </div>
      </div>

      {error ? (
        <ErrorState message={error} onRetry={reload} />
      ) : loading ? (
        <MovieGrid loading skeletons={8} />
      ) : results.length === 0 ? (
        <EmptyState
          icon={Film}
          title="No movies match those filters"
          description="Try a different language or genre, or clear the filters to see everything."
          action={
            <Button variant="outline" onClick={() => setFilters(initial)}>
              Clear filters
            </Button>
          }
        />
      ) : (
        <>
          <p className="mb-5 text-sm text-muted" aria-live="polite">
            {results.length} {results.length === 1 ? 'movie' : 'movies'}
          </p>
          <MovieGrid movies={results} />
        </>
      )}
    </div>
  );
}
