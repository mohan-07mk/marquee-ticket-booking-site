import { useEffect, useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AlertCircle, Eye, EyeOff, Lock, Mail } from 'lucide-react';
import { Button } from '@/components/ui/Button';
import { Field, Input } from '@/components/ui/Field';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { isEmail } from '@/utils/validators';
import { GoogleButton, OrDivider } from './GoogleButton';

export default function Login() {
  useDocumentTitle('Log in');
  const { user, login, loginWithGoogle } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [show, setShow] = useState(false);
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);

  useEffect(() => {
    const authErr = localStorage.getItem('marquee.auth_error');
    if (authErr) {
      setFormError(authErr);
      localStorage.removeItem('marquee.auth_error');
    }
  }, []);

  useEffect(() => {
    if (user) {
      navigate(user.role === 'admin' ? '/admin' : '/', { replace: true });
    }
  }, [user, navigate]);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const next: typeof errors = {};
    if (!isEmail(email)) next.email = 'Enter a valid email address.';
    if (!password) next.password = 'Enter your password.';
    setErrors(next);
    setFormError(null);
    if (Object.keys(next).length) return;

    setLoading(true);
    try {
      const user = await login(email.trim(), password);
      toast.success(`Welcome back, ${user.name.split(' ')[0]}`);
      navigate(user.role === 'admin' ? '/admin' : '/');
    } catch (err) {
      setFormError(err instanceof Error ? err.message : 'Could not log in.');
      setLoading(false);
    }
  };

  const google = async () => {
    setGoogleLoading(true);
    try {
      await loginWithGoogle();
      // OAuth will redirect so nothing to do here
    } catch (err) {
      toast.error('Could not sign in with Google', err instanceof Error ? err.message : undefined);
      setGoogleLoading(false);
    }
  };

  return (
    <div className="animate-fade-in">
      <h1 className="font-display text-5xl font-extrabold leading-none">Welcome back</h1>
      <p className="mt-3 text-muted">Log in to see your tickets and book faster.</p>

      <div className="mt-8">
        <GoogleButton label="Continue with Google" onClick={google} loading={googleLoading} />
      </div>
      <OrDivider />

      <form onSubmit={submit} noValidate className="space-y-5">
        {formError && (
          <div role="alert" className="flex items-start gap-2.5 rounded-xl border border-red-500/30 bg-red-500/10 p-3.5 text-sm text-red-200">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
            {formError}
          </div>
        )}
        <Field label="Email" htmlFor="email" error={errors.email}>
          <Input id="email" type="email" autoComplete="email" placeholder="you@example.com" icon={<Mail className="h-4 w-4" />} value={email} invalid={!!errors.email} onChange={(e) => setEmail(e.target.value)} />
        </Field>
        <Field label="Password" htmlFor="password" error={errors.password}>
          <Input
            id="password"
            type={show ? 'text' : 'password'}
            autoComplete="current-password"
            placeholder="Your password"
            icon={<Lock className="h-4 w-4" />}
            value={password}
            invalid={!!errors.password}
            onChange={(e) => setPassword(e.target.value)}
            rightSlot={
              <button type="button" onClick={() => setShow((s) => !s)} aria-label={show ? 'Hide password' : 'Show password'} className="rounded-lg p-2 text-muted transition hover:text-white">
                {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            }
          />
        </Field>
        <div className="flex justify-end">
          <Link to="/forgot-password" className="text-sm text-white/70 underline-offset-4 transition hover:text-white hover:underline">
            Forgot password?
          </Link>
        </div>
        <Button type="submit" size="lg" className="w-full" loading={loading}>
          Log in
        </Button>
      </form>

      <p className="mt-6 text-center text-sm text-muted">
        New to Marquee?{' '}
        <Link to="/register" className="font-semibold text-white underline-offset-4 hover:underline">
          Create an account
        </Link>
      </p>
    </div>
  );
}
