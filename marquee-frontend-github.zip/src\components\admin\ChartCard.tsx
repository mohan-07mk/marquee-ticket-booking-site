import type { ReactNode } from 'react';
import { Skeleton } from '../ui/Skeleton';

export const chartColors = { brand: '#e11d2e', soft: '#ff6b78', grid: '#262626', axis: '#8a8a8a', gold: '#f5b942' };

export const tooltipStyle = {
  contentStyle: { background: '#1d1d1d', border: '1px solid #2b2b2b', borderRadius: 12, color: '#fff', fontSize: 13 },
  labelStyle: { color: '#9b9b9b', marginBottom: 4 },
  cursor: { fill: 'rgba(255,255,255,0.05)' },
};

export function ChartCard({
  title,
  subtitle,
  loading,
  className,
  children,
}: {
  title: string;
  subtitle?: string;
  loading?: boolean;
  className?: string;
  children: ReactNode;
}) {
  return (
    <section className={`rounded-3xl border border-line bg-surface p-5 ${className ?? ''}`}>
      <h3 className="font-display text-2xl font-bold leading-none">{title}</h3>
      {subtitle && <p className="mt-1.5 text-sm text-muted">{subtitle}</p>}
      <div className="mt-5 h-64 w-full">{loading ? <Skeleton className="h-full w-full" /> : children}</div>
    </section>
  );
}
