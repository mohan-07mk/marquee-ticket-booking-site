import type { Show } from '@/types';
import { hasShowStarted, formatTime } from '@/utils/format';
import { cn } from '@/utils/cn';

/** A single tappable showtime. Colour reflects how full the show is. */
export function ShowtimeButton({ show, onSelect }: { show: Show; onSelect: (show: Show) => void }) {
  const started = hasShowStarted(show.date, show.time);
  const left = show.seatsLeft ?? 1;
  const ratio = show.capacity ? left / show.capacity : 1;
  const soldOut = left === 0;
  const disabled = started || soldOut || show.status === 'cancelled';

  const tone = soldOut
    ? 'text-muted'
    : ratio < 0.2
      ? 'text-red-400'
      : ratio < 0.5
        ? 'text-amber-300'
        : 'text-emerald-400';

  const note = show.status === 'cancelled' ? 'Cancelled' : started ? 'Started' : soldOut ? 'Sold out' : ratio < 0.2 ? 'Almost full' : ratio < 0.5 ? 'Filling fast' : 'Available';

  return (
    <button
      type="button"
      disabled={disabled}
      onClick={() => onSelect(show)}
      className={cn(
        'group flex min-w-[112px] flex-col items-start rounded-xl border border-line bg-surface px-3.5 py-2.5 text-left transition duration-200',
        'hover:-translate-y-0.5 hover:border-brand hover:bg-brand/10 disabled:translate-y-0 disabled:cursor-not-allowed disabled:opacity-45 disabled:hover:border-line disabled:hover:bg-surface',
      )}
      aria-label={`${formatTime(show.time)}, ${show.format}, ${show.language}, ${note}`}
    >
      <span className="text-[15px] font-semibold leading-tight">{formatTime(show.time)}</span>
      <span className="mt-0.5 text-xs text-muted">{show.language}</span>
      <span className={cn('mt-1 text-[11px] font-medium', tone)}>{note}</span>
    </button>
  );
}
