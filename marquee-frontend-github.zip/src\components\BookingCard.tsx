import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { CalendarDays, Clock, MapPin, Armchair } from 'lucide-react';
import type { Booking } from '@/types';
import { formatLongDate, formatTime } from '@/utils/format';
import { StatusBadge } from './ui/Badge';
import { buttonClasses } from './ui/Button';

export function BookingCard({ booking, actions }: { booking: Booking; actions?: ReactNode }) {
  return (
    <article className="flex gap-4 rounded-3xl border border-line bg-surface p-4 transition duration-300 hover:border-white/25 sm:gap-6 sm:p-5">
      <img
        src={booking.posterUrl}
        alt={`${booking.movieTitle} poster`}
        className="h-32 w-[86px] shrink-0 rounded-xl border border-line object-cover sm:h-40 sm:w-[106px]"
        loading="lazy"
      />
      <div className="flex min-w-0 flex-1 flex-col">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div className="min-w-0">
            <h3 className="truncate font-display text-2xl font-bold leading-tight">{booking.movieTitle}</h3>
            <p className="text-xs text-muted">
              Booking ID <span className="font-semibold text-white/85">{booking.id}</span>
            </p>
          </div>
          <StatusBadge status={booking.status} />
        </div>

        <ul className="mt-3 grid gap-x-6 gap-y-1.5 text-sm text-white/80 sm:grid-cols-2">
          <li className="flex items-center gap-2">
            <MapPin className="h-4 w-4 shrink-0 text-muted" />
            <span className="truncate">
              {booking.theatreName}, {booking.screenName}
            </span>
          </li>
          <li className="flex items-center gap-2">
            <CalendarDays className="h-4 w-4 shrink-0 text-muted" />
            {formatLongDate(booking.date)}
          </li>
          <li className="flex items-center gap-2">
            <Clock className="h-4 w-4 shrink-0 text-muted" />
            {formatTime(booking.time)}
          </li>
          <li className="flex items-center gap-2">
            <Armchair className="h-4 w-4 shrink-0 text-muted" />
            {booking.seats.join(', ')}
          </li>
        </ul>

        <div className="mt-auto flex flex-wrap items-center gap-2 pt-4">
          <Link to={`/booking-success?id=${booking.id}`} className={buttonClasses({ variant: 'outline', size: 'sm' })}>
            View ticket
          </Link>
          {actions}
        </div>
      </div>
    </article>
  );
}
