import type { User } from '@/types';

/** MOCK DATA - users. Replace with: supabase.from('profiles').select('*') */
export const DEMO_USER_ID = 'u1';

export const users: User[] = [
  { id: 'u1', name: 'Aarav Menon', email: 'aarav.menon@example.com', phone: '+91 98765 43210', role: 'customer', status: 'active', joinedAt: '2025-11-04' },
  { id: 'u2', name: 'Diya Raghavan', email: 'diya.r@example.com', phone: '+91 91234 55672', role: 'customer', status: 'active', joinedAt: '2025-12-19' },
  { id: 'u3', name: 'Karthik Subramani', email: 'karthik.s@example.com', phone: '+91 99887 12045', role: 'customer', status: 'active', joinedAt: '2026-01-08' },
  { id: 'u4', name: 'Neha Iyer', email: 'neha.iyer@example.com', phone: '+91 90031 87764', role: 'customer', status: 'active', joinedAt: '2026-01-27' },
  { id: 'u5', name: 'Rohit Malhotra', email: 'rohit.m@example.com', phone: '+91 98450 22019', role: 'customer', status: 'blocked', joinedAt: '2026-02-03' },
  { id: 'u6', name: 'Sneha Pillai', email: 'sneha.pillai@example.com', phone: '+91 97001 45521', role: 'customer', status: 'active', joinedAt: '2026-02-21' },
  { id: 'u7', name: 'Vikram Shetty', email: 'vikram.shetty@example.com', phone: '+91 96321 09876', role: 'customer', status: 'active', joinedAt: '2026-03-10' },
  { id: 'u8', name: 'Ananya Das', email: 'ananya.das@example.com', phone: '+91 95500 76123', role: 'customer', status: 'active', joinedAt: '2026-03-30' },
  { id: 'u9', name: 'Faisal Khan', email: 'faisal.khan@example.com', phone: '+91 99400 31877', role: 'customer', status: 'active', joinedAt: '2026-04-14' },
  { id: 'u10', name: 'Lakshmi Narayanan', email: 'lakshmi.n@example.com', phone: '+91 94440 68215', role: 'customer', status: 'active', joinedAt: '2026-05-06' },
  { id: 'u11', name: 'Tejas Patil', email: 'tejas.patil@example.com', phone: '+91 93210 44598', role: 'customer', status: 'blocked', joinedAt: '2026-06-18' },
  { id: 'u12', name: 'Isha Bansal', email: 'isha.bansal@example.com', phone: '+91 98111 90342', role: 'customer', status: 'active', joinedAt: '2026-07-25' },
];
