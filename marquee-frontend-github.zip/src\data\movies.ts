import type { Format, Movie, MovieStatus } from '@/types';
import { addDays, toDateKey } from '@/utils/format';
import { makeArt } from '@/utils/poster';

/**
 * MOCK DATA - movies.
 * Replace with: supabase.from('movies').select('*') (see services/api.ts).
 * Release dates are relative to "today" so the demo never goes stale.
 */
const rel = (days: number) => toDateKey(addDays(new Date(), days));

interface Seed {
  title: string;
  description: string;
  genres: string[];
  languages: string[];
  formats: Format[];
  durationMin: number;
  releaseOffset: number;
  rating: number;
  certificate: string;
  cast: string[];
  director: string;
  status: MovieStatus;
  popularity: number;
}

const seeds: Seed[] = [
  {
    title: 'Crimson Horizon',
    description:
      'When a deep-space relay goes silent, a disgraced flight engineer is the only person who can reach it in time. Every light-year closer to the signal, the crew learns that someone got there first.',
    genres: ['Sci-Fi', 'Action'],
    languages: ['Tamil', 'English'],
    formats: ['2D', '3D', 'IMAX'],
    durationMin: 148,
    releaseOffset: -9,
    rating: 8.4,
    certificate: 'UA',
    cast: ['Arjun Velan', 'Nora Fitzgerald', 'Ishaan Rao'],
    director: 'Meera Kannan',
    status: 'now_showing',
    popularity: 98,
  },
  {
    title: 'Monsoon Protocol',
    description:
      'A city under three days of rain, a missing flood-gate log, and a hydrologist who realises the disaster was scheduled. A tight, sweaty thriller told in real time.',
    genres: ['Thriller', 'Drama'],
    languages: ['Hindi'],
    formats: ['2D'],
    durationMin: 132,
    releaseOffset: -16,
    rating: 7.9,
    certificate: 'UA',
    cast: ['Tanvi Bhatt', 'Rohan Kulkarni', 'Devika Nair'],
    director: 'Sameer Joshi',
    status: 'now_showing',
    popularity: 84,
  },
  {
    title: 'The Last Projectionist',
    description:
      'In a single-screen cinema due for demolition, the old projectionist runs one last film for the town that grew up in its dark. A quiet, luminous love letter to the movies.',
    genres: ['Drama'],
    languages: ['English'],
    formats: ['2D'],
    durationMin: 118,
    releaseOffset: -23,
    rating: 8.7,
    certificate: 'U',
    cast: ['Walter Ashby', 'Lila Moreau'],
    director: 'Hana Ito',
    status: 'now_showing',
    popularity: 79,
  },
  {
    title: 'Kaalam',
    description:
      'Three decades, two rival families, one disputed river. A sweeping saga of loyalty and land that follows a village from its first harvest festival to its final reckoning.',
    genres: ['Action', 'Drama'],
    languages: ['Tamil'],
    formats: ['2D', 'IMAX'],
    durationMin: 161,
    releaseOffset: -5,
    rating: 8.1,
    certificate: 'UA',
    cast: ['Karthik Selvam', 'Priya Ramanujam', 'Vetri Maran'],
    director: 'Bala Murugesan',
    status: 'now_showing',
    popularity: 92,
  },
  {
    title: 'Starfall Academy',
    description:
      'Twelve-year-old Pia discovers her school sits on the only spot where fallen stars can be caught. Now she has one term to learn how, before the night sky runs out of them.',
    genres: ['Fantasy', 'Family'],
    languages: ['English', 'Hindi'],
    formats: ['2D', '3D'],
    durationMin: 125,
    releaseOffset: -12,
    rating: 7.4,
    certificate: 'U',
    cast: ['Anaya Desai', 'Gordon Pryce', 'Mira Chandran'],
    director: 'Lucas Ferreira',
    status: 'now_showing',
    popularity: 71,
  },
  {
    title: 'Midnight Biryani',
    description:
      'A food truck, a stolen recipe and one very long night in the city. A warm, fast-talking comedy about the people who feed us after the restaurants close.',
    genres: ['Comedy'],
    languages: ['Malayalam', 'Tamil'],
    formats: ['2D'],
    durationMin: 123,
    releaseOffset: -19,
    rating: 8.0,
    certificate: 'U',
    cast: ['Sanoj Pillai', 'Aswathi Menon', 'Basil Thomas'],
    director: 'Jithin Varghese',
    status: 'now_showing',
    popularity: 76,
  },
  {
    title: 'Iron Tide',
    description:
      'A retired harbour pilot is dragged back to guide a hijacked tanker through the most dangerous strait on earth. Big ships, bigger stakes and one long, brutal night at sea.',
    genres: ['Action', 'Thriller'],
    languages: ['Telugu', 'Hindi'],
    formats: ['2D', 'IMAX'],
    durationMin: 155,
    releaseOffset: -7,
    rating: 7.7,
    certificate: 'UA',
    cast: ['Raghav Teja', 'Sonal Mehra', 'Dev Kapoor'],
    director: 'Prasad Naidu',
    status: 'now_showing',
    popularity: 88,
  },
  {
    title: 'Paper Lanterns',
    description:
      'Two strangers keep leaving notes in the same borrowed library book. By the time they meet, the festival lights are already floating away.',
    genres: ['Romance', 'Drama'],
    languages: ['Hindi'],
    formats: ['2D'],
    durationMin: 129,
    releaseOffset: -26,
    rating: 7.2,
    certificate: 'U',
    cast: ['Kabir Sethi', 'Ananya Rastogi'],
    director: 'Ritu Sharma',
    status: 'now_showing',
    popularity: 58,
  },
  {
    title: 'Echo Chamber Zero',
    description:
      'A sound engineer discovers a frequency that lets her hear conversations from the day before. The trouble starts when she hears one that has not happened yet.',
    genres: ['Sci-Fi', 'Thriller'],
    languages: ['English', 'Hindi'],
    formats: ['2D', 'IMAX'],
    durationMin: 141,
    releaseOffset: 9,
    rating: 0,
    certificate: 'UA',
    cast: ['Freya Lindqvist', 'Amit Trivedi'],
    director: 'Noor Al-Hashimi',
    status: 'coming_soon',
    popularity: 90,
  },
  {
    title: 'Vettai Raja',
    description:
      'A small-town constable, a forgotten hunting law, and a king who never left the forest. The year’s most anticipated Tamil action drama.',
    genres: ['Action', 'Drama'],
    languages: ['Tamil', 'Telugu'],
    formats: ['2D', 'IMAX'],
    durationMin: 158,
    releaseOffset: 16,
    rating: 0,
    certificate: 'UA',
    cast: ['Karthik Selvam', 'Ramya Iyer'],
    director: 'Bala Murugesan',
    status: 'coming_soon',
    popularity: 95,
  },
  {
    title: 'Glass Kingdom',
    description:
      'A mirror-maker’s apprentice steps through a shard and finds a realm where every reflection rules a different court. Built for the biggest screen you can find.',
    genres: ['Fantasy', 'Adventure'],
    languages: ['English', 'Hindi'],
    formats: ['2D', '3D', 'IMAX'],
    durationMin: 136,
    releaseOffset: 30,
    rating: 0,
    certificate: 'U',
    cast: ['Ella Whitmore', 'Zain Qureshi', 'Ravi Shankar Iyer'],
    director: 'Lucas Ferreira',
    status: 'coming_soon',
    popularity: 82,
  },
  {
    title: 'The Salt Road',
    description:
      'Two drovers, forty camels and a trade route the maps forgot. An adventure about the price of a shortcut.',
    genres: ['Adventure', 'Drama'],
    languages: ['Malayalam', 'Tamil'],
    formats: ['2D'],
    durationMin: 138,
    releaseOffset: 44,
    rating: 0,
    certificate: 'UA',
    cast: ['Sanoj Pillai', 'Meera Kannan'],
    director: 'Jithin Varghese',
    status: 'coming_soon',
    popularity: 66,
  },
  {
    title: 'Old Town Blues',
    description:
      'A retired jazz trumpeter tries to reunite his band for one last gig in a town that has forgotten the tune. Currently paused from listing.',
    genres: ['Drama', 'Comedy'],
    languages: ['Hindi'],
    formats: ['2D'],
    durationMin: 112,
    releaseOffset: -60,
    rating: 6.8,
    certificate: 'U',
    cast: ['Kabir Sethi'],
    director: 'Ritu Sharma',
    status: 'inactive',
    popularity: 20,
  },
];

export const movies: Movie[] = seeds.map((s, i) => ({
  id: `m${i + 1}`,
  title: s.title,
  description: s.description,
  genres: s.genres,
  languages: s.languages,
  formats: s.formats,
  durationMin: s.durationMin,
  releaseDate: rel(s.releaseOffset),
  rating: s.rating,
  certificate: s.certificate,
  posterUrl: makeArt(s.title, i, 'poster'),
  backdropUrl: makeArt(s.title, i, 'backdrop'),
  trailerUrl: '', // set to a YouTube embed URL, e.g. https://www.youtube.com/embed/<id>
  cast: s.cast,
  director: s.director,
  status: s.status,
  popularity: s.popularity,
}));

export const GENRES = ['Action', 'Adventure', 'Comedy', 'Drama', 'Family', 'Fantasy', 'Romance', 'Sci-Fi', 'Thriller'];
export const LANGUAGES = ['English', 'Hindi', 'Malayalam', 'Tamil', 'Telugu'];
export const FORMATS: Format[] = ['2D', '3D', 'IMAX'];
