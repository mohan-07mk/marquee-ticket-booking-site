import { Component, useCallback, useEffect, useMemo, useRef, useState, type ErrorInfo, type ReactNode } from 'react';
import { AlertTriangle, Box, Loader2, Map as MapIcon, X } from 'lucide-react';
import { SeatLegend as FlatSeatLegend, SeatMap } from '@/components/SeatMap';
import { useCinemaScreen } from '@/context/CinemaScreenContext';
import type { Screen, Seat } from '@/types';
import { formatCurrency } from '@/utils/format';
import { MAX_SEATS_PER_BOOKING } from '@/utils/pricing';
import { parseYouTubeUrl } from '@/utils/youtube';
import { Auditorium3D } from './Auditorium3D';
import type { AuditoriumCameraApi } from './AuditoriumCamera';
import type { ScreenStatus } from './CinemaScreen3D';
import { SeatLegend } from './SeatLegend';
import { buildAuditoriumLayout } from './seatLayout';
import { SeatSelectionControls } from './SeatSelectionControls';
import { SeatViewPreview } from './SeatViewPreview';
import './theme.css';

interface Props {
  seats: Seat[];
  screen: Screen;
  selectedIds: string[];
  onToggle: (seat: Seat) => void;
  /** The show has started, so free seats cannot be booked. */
  started?: boolean;
  movieTitle: string;
  /** Shown on the default cinema screen, e.g. "Aurora Cinemas, Screen 1". */
  screenSubtitle: string;
  theatreId?: string;
  theatreScreenViewLink?: string;
  movieTrailerUrl?: string;
}

type Mode = '3d' | 'flat';

function webglSupported() {
  try {
    const canvas = document.createElement('canvas');
    return !!(window.WebGLRenderingContext && (canvas.getContext('webgl2') || canvas.getContext('webgl')));
  } catch {
    return false;
  }
}

function usePrefersReducedMotion() {
  const [reduced, setReduced] = useState(() => window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false);
  useEffect(() => {
    const mq = window.matchMedia?.('(prefers-reduced-motion: reduce)');
    if (!mq) return;
    const on = () => setReduced(mq.matches);
    mq.addEventListener('change', on);
    return () => mq.removeEventListener('change', on);
  }, []);
  return reduced;
}

/** Catches anything the 3D scene throws and lets the page fall back to the flat map. */
class SceneBoundary extends Component<{ onError: (error: Error) => void; children: ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch(error: Error, _info: ErrorInfo) {
    this.props.onError(error);
  }
  render() {
    return this.state.failed ? null : this.props.children;
  }
}

export default function SeatSelection3D({
  seats,
  screen,
  selectedIds,
  onToggle,
  started = false,
  movieTitle,
  screenSubtitle,
  theatreId,
  theatreScreenViewLink,
  movieTrailerUrl,
}: Props) {
  const { video: globalVideo } = useCinemaScreen();

  const activeVideo = useMemo(() => {
    let targetLink = theatreScreenViewLink;
    if (!targetLink && theatreId && typeof window !== 'undefined') {
      try {
        targetLink = localStorage.getItem(`marquee.theatre_screen_link_${theatreId}`) ?? undefined;
      } catch {}
    }
    if (targetLink) {
      const parsed = parseYouTubeUrl(targetLink);
      if (parsed) return parsed;
    }
    if (globalVideo) return globalVideo;
    if (movieTrailerUrl) {
      const parsed = parseYouTubeUrl(movieTrailerUrl);
      if (parsed) return parsed;
    }
    return null;
  }, [theatreId, theatreScreenViewLink, globalVideo, movieTrailerUrl]);

  const reducedMotion = usePrefersReducedMotion();
  const api = useRef<AuditoriumCameraApi>(null);
  const container = useRef<HTMLDivElement>(null);
  const tooltip = useRef<HTMLDivElement>(null);
  const pointer = useRef({ x: 0, y: 0 });

  const supported = useMemo(webglSupported, []);
  const [mode, setMode] = useState<Mode>(supported ? '3d' : 'flat');
  const [notice, setNotice] = useState<string | null>(supported ? null : 'Your browser can’t show the 3D hall, so here is the classic seat map.');
  const [ready, setReady] = useState(false);
  const [hovered, setHovered] = useState<Seat | null>(null);
  const [focus, setFocus] = useState<Seat | null>(null);
  const [panMode, setPanMode] = useState(false);
  const [screenInteractive, setScreenInteractive] = useState(false);
  const [seatViewId, setSeatViewId] = useState<string | null>(null);
  const [screenStatus, setScreenStatus] = useState<ScreenStatus>('default');

  const lowPower = useMemo(
    () => window.matchMedia?.('(pointer: coarse)').matches || window.innerWidth < 768 || (navigator.hardwareConcurrency ?? 8) <= 4,
    [],
  );

  const layout = useMemo(() => buildAuditoriumLayout(seats, screen), [seats, screen]);
  const selected = useMemo(() => new Set(selectedIds), [selectedIds]);
  const selectedSeats = useMemo(() => seats.filter((s) => selected.has(s.id)), [seats, selected]);

  // A new layout means a new show: start fresh.
  useEffect(() => {
    setSeatViewId(null);
    setFocus(null);
  }, [layout]);

  const fallBack = useCallback((message: string) => {
    setNotice(message);
    setMode('flat');
  }, []);

  const handleSelect = useCallback(
    (seat: Seat) => {
      setFocus(seat);
      if (started || seat.status === 'occupied') return;
      onToggle(seat);
    },
    [onToggle, started],
  );

  const leaveSpecialViews = useCallback(() => {
    setSeatViewId(null);
    setScreenInteractive(false);
  }, []);

  const viewFromSeat = (id: string) => {
    setScreenInteractive(false);
    setSeatViewId(id);
    api.current?.seatView(id);
  };

  const togglePan = (pan: boolean) => {
    setPanMode(pan);
    api.current?.setPanMode(pan);
  };

  const toggleScreenInteractive = () => {
    if (screenInteractive) {
      setScreenInteractive(false);
      return;
    }
    setSeatViewId(null);
    setScreenInteractive(true);
    api.current?.setView('screen');
  };

  const onPointerMove = (e: React.PointerEvent) => {
    const rect = container.current?.getBoundingClientRect();
    if (!rect) return;
    pointer.current = { x: e.clientX - rect.left, y: e.clientY - rect.top };
    if (tooltip.current) tooltip.current.style.transform = `translate(${pointer.current.x + 14}px, ${pointer.current.y + 14}px)`;
  };

  const shownSeat = hovered ?? focus ?? selectedSeats[selectedSeats.length - 1] ?? null;
  const hoverBlocked = hovered && (started || hovered.status === 'occupied');
  const hoverLabel = !hovered ? '' : hovered.status === 'occupied' ? 'Booked' : started ? 'Unavailable' : selected.has(hovered.id) ? 'Selected, tap to remove' : 'Available';

  /* ------------------------------ classic map ------------------------------ */
  if (mode === 'flat') {
    return (
      <div>
        {notice && (
          <div role="status" className="mb-4 flex items-start gap-2 rounded-xl border border-amber-500/30 bg-amber-500/10 px-3.5 py-2.5 text-sm text-amber-200">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
            {notice}
          </div>
        )}
        {supported && (
          <button type="button" onClick={() => { setNotice(null); setReady(false); setMode('3d'); }} className="mb-4 inline-flex items-center gap-1.5 text-sm text-white/70 transition hover:text-white">
            <Box className="h-4 w-4" />
            Try the 3D hall
          </button>
        )}
        <SeatMap seats={seats} screen={screen} selectedIds={selectedIds} onToggle={onToggle} />
        <div className="mt-8 border-t border-line pt-6">
          <FlatSeatLegend />
        </div>
      </div>
    );
  }

  /* --------------------------------- 3D hall -------------------------------- */
  return (
    <div>
      <div
        ref={container}
        onPointerMove={onPointerMove}
        className="mq3d h-[min(68vh,640px)] min-h-[400px] sm:min-h-[460px]"
        style={{ cursor: hovered ? (hoverBlocked ? 'not-allowed' : 'pointer') : undefined }}
      >
        <SceneBoundary onError={() => fallBack('The 3D hall hit a problem, so here is the classic seat map. Your selection is kept.')}>
          <Auditorium3D
            ref={api}
            layout={layout}
            selectedIds={selected}
            blocked={started}
            video={activeVideo}
            title={movieTitle}
            subtitle={screenSubtitle}
            screenInteractive={screenInteractive}
            reducedMotion={reducedMotion}
            lowPower={lowPower}
            onHoverSeat={setHovered}
            onSelectSeat={handleSelect}
            onScreenStatus={(s) => setScreenStatus(s)}
            onUserMove={leaveSpecialViews}
            onReady={() => setReady(true)}
            onContextLost={() => fallBack('The 3D view was interrupted by your graphics driver, so here is the classic seat map.')}
          />
        </SceneBoundary>

        {!ready && (
          <div className="absolute inset-0 z-20 grid place-items-center bg-black/80">
            <p className="flex items-center gap-2 text-sm text-white/70">
              <Loader2 className="h-4 w-4 animate-spin" />
              Preparing the auditorium
            </p>
          </div>
        )}

        {/* Top row: orientation hint and the way back to the flat map */}
        <div className="pointer-events-none absolute inset-x-0 top-0 z-10 flex items-start justify-between gap-3 p-3 sm:p-4">
          <p className="rounded-full bg-black/55 px-3 py-1.5 text-xs text-white/70 backdrop-blur">
            <span className="hidden sm:inline">Drag to look around, scroll to zoom, click a seat to pick it</span>
            <span className="sm:hidden">Drag to look, pinch to zoom, tap a seat</span>
          </p>
          <button
            type="button"
            onClick={() => { setNotice(null); setMode('flat'); }}
            className="pointer-events-auto inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-black/55 px-3 py-1.5 text-xs font-medium text-white/80 backdrop-blur transition hover:text-white"
          >
            <MapIcon className="h-3.5 w-3.5" />
            Classic map
          </button>
        </div>

        {seatViewId && (
          <div className="mq3d-pop absolute left-1/2 top-14 z-10 -translate-x-1/2">
            <button type="button" onClick={() => { leaveSpecialViews(); api.current?.reset(); }} className="inline-flex items-center gap-2 rounded-full bg-brand px-3.5 py-1.5 text-xs font-semibold shadow-[0_8px_24px_-8px_rgba(225,29,46,.9)]">
              Viewing from seat {layout.byId.get(seatViewId)?.seat.label || (layout.byId.get(seatViewId)?.seat ? `${layout.byId.get(seatViewId)?.seat.row}${layout.byId.get(seatViewId)?.seat.number}` : seatViewId)}
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        )}

        {screenInteractive && (
          <p className="mq3d-pop absolute left-1/2 top-14 z-10 -translate-x-1/2 rounded-full bg-black/70 px-3.5 py-1.5 text-center text-xs text-white/80 backdrop-blur">
            Use the player on the screen. If it hasn’t started, press play there.
          </p>
        )}

        {screenStatus === 'error' && !screenInteractive && (
          <p className="absolute bottom-20 left-1/2 z-10 -translate-x-1/2 rounded-full bg-black/70 px-3.5 py-1.5 text-xs text-white/70 backdrop-blur">The screen video can’t play here. Seats still work as normal.</p>
        )}

        {hovered && (
          <div
            ref={tooltip}
            className="pointer-events-none absolute left-0 top-0 z-20 rounded-xl border border-white/15 bg-black/85 px-3 py-2 text-xs shadow-xl backdrop-blur"
            style={{ transform: `translate(${pointer.current.x + 14}px, ${pointer.current.y + 14}px)` }}
          >
            <p className="font-semibold text-white">
              {hovered.label || `${hovered.row}${hovered.number}`}, <span className={hovered.type === 'premium' ? 'text-gold' : ''}>{hovered.type === 'premium' ? 'Premium' : 'Standard'}</span>
              <span className="text-white/60">, {formatCurrency(hovered.price)}</span>
            </p>
            <p className="mt-0.5 text-white/60">{hoverLabel}</p>
          </div>
        )}

        <div className="absolute inset-x-0 bottom-0 z-10 flex justify-center p-3 sm:p-4">
          <SeatSelectionControls
            api={api}
            panMode={panMode}
            onPanMode={togglePan}
            onCameraAction={leaveSpecialViews}
            hasVideo={!!activeVideo}
            screenInteractive={screenInteractive}
            onToggleScreenInteractive={toggleScreenInteractive}
          />
        </div>
      </div>

      <div className="mt-5">
        <SeatLegend />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <div className="rounded-2xl border border-line bg-black/40 p-4">
          <div className="flex items-baseline justify-between gap-3">
            <h3 className="font-display text-2xl font-bold leading-none">Your seats</h3>
            <p className="text-xs text-muted">
              {selectedSeats.length} of {MAX_SEATS_PER_BOOKING}
            </p>
          </div>
          {selectedSeats.length ? (
            <ul className="mt-3 flex flex-wrap gap-2">
              {selectedSeats.map((s) => (
                <li key={s.id}>
                  <button
                    type="button"
                    onClick={() => onToggle(s)}
                    onMouseEnter={() => setFocus(s)}
                    aria-label={`Remove seat ${s.label || `${s.row}${s.number}`}`}
                    className={`group inline-flex items-center gap-2 rounded-xl border px-2.5 py-1.5 text-sm transition hover:bg-white/5 ${s.type === 'premium' ? 'border-gold/50' : 'border-white/25'}`}
                  >
                    <span className={`font-semibold ${s.type === 'premium' ? 'text-gold' : ''}`}>{s.label || `${s.row}${s.number}`}</span>
                    <span className="text-xs text-white/60">{formatCurrency(s.price)}</span>
                    <X className="h-3.5 w-3.5 text-white/40 transition group-hover:text-white" />
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="mt-3 text-sm text-white/60">{started ? 'This show has started, so seats can’t be picked.' : 'No seats yet. Pick any free seat in the hall.'}</p>
          )}
        </div>

        <SeatViewPreview layout={layout} seat={shownSeat} inSeatView={!!seatViewId} onViewFromSeat={viewFromSeat} />
      </div>
    </div>
  );
}
