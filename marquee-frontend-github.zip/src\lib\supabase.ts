import { createClient } from '@supabase/supabase-js';

const defaultUrl = 'https://lshddzfzehchfartsqhs.supabase.co';
const defaultKey = 'sb_publishable_KzLSYOJVECyEJXtqUmXE-A_P2TmrhYC';

const url = import.meta.env.VITE_SUPABASE_URL || defaultUrl;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY || defaultKey;

/**
 * Wrap fetch with a 15-second timeout so that DNS failures (ERR_NAME_NOT_RESOLVED)
 * are surfaced quickly as errors rather than hanging silently, which would keep
 * skeleton loaders on screen indefinitely.
 */
const fetchWithTimeout: typeof fetch = (input, init) => {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), 15_000);
  return fetch(input, { ...init, signal: controller.signal }).finally(() =>
    clearTimeout(id),
  );
};

export const supabase = createClient(url, key, {
  global: { fetch: fetchWithTimeout },
});

