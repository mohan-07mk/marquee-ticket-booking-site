import { useMemo, useState } from 'react';
import { CheckCircle2, ClipboardPaste, Eye, EyeOff, Film, Link2, Play, RotateCcw, Save, XCircle } from 'lucide-react';
import { Badge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { Field, Input } from '@/components/ui/Field';
import { YouTubeEmbed, type EmbedStatus } from '@/components/YouTubeEmbed';
import { useCinemaScreen } from '@/context/CinemaScreenContext';
import { useToast } from '@/context/ToastContext';
import { parseYouTubeUrl } from '@/utils/youtube';

/**
 * Admin editor for the video shown on the 3D cinema screen.
 * Frontend demo: the saved link lives in React state (CinemaScreenContext) and
 * is lost on refresh. Persisting it is a backend task, see README.md.
 */
export function CinemaScreenSettings() {
  const toast = useToast();
  const { videoUrl, video, saveVideoUrl, resetToDefault } = useCinemaScreen();
  const [draft, setDraft] = useState(videoUrl);
  const [previewing, setPreviewing] = useState(false);
  const [status, setStatus] = useState<EmbedStatus>('loading');
  const [reason, setReason] = useState<string>();
  const [thumbFailed, setThumbFailed] = useState(false);

  const parsed = useMemo(() => parseYouTubeUrl(draft), [draft]);
  const touched = draft.trim().length > 0;
  const invalid = touched && !parsed;
  const unchanged = draft.trim() === videoUrl.trim();

  const onDraftChange = (value: string) => {
    setDraft(value);
    setPreviewing(false);
    setThumbFailed(false);
  };

  const paste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (!text.trim()) {
        toast.info('Clipboard is empty', 'Copy a YouTube link first.');
        return;
      }
      onDraftChange(text.trim());
    } catch {
      toast.info('Paste with Ctrl+V', 'Your browser blocked clipboard access. Click the field and paste instead.');
    }
  };

  const save = () => {
    if (!saveVideoUrl(draft)) return;
    toast.success('Cinema screen updated', 'The video now plays on the 3D screen in seat selection.');
  };

  const reset = () => {
    resetToDefault();
    setDraft('');
    setPreviewing(false);
    toast.success('Default screen restored');
  };

  const showing = parsed ?? video;
  const liveLabel = video ? 'Custom video' : 'Default screen';

  return (
    <section className="rounded-3xl border border-line bg-surface p-5 sm:p-6" aria-labelledby="cinema-screen-settings">
      <div className="mb-5 flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 id="cinema-screen-settings" className="font-display text-2xl font-bold leading-none">
            Cinema Screen Settings
          </h3>
          <p className="mt-2 max-w-xl text-sm text-muted">Paste a YouTube link to play it on the big screen in the 3D auditorium. Customers see it when they choose seats.</p>
        </div>
        <Badge tone={video ? 'success' : 'neutral'}>Live: {liveLabel}</Badge>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_minmax(0,420px)]">
        <div className="space-y-4">
          <Field
            label="YouTube video URL"
            htmlFor="yt-url"
            error={invalid ? 'That isn’t a YouTube video link. Try youtube.com/watch?v=… or youtu.be/…' : undefined}
            hint={!touched ? 'Works with watch, youtu.be, embed, shorts and live links.' : undefined}
          >
            <Input
              id="yt-url"
              value={draft}
              onChange={(e) => onDraftChange(e.target.value)}
              placeholder="https://www.youtube.com/watch?v=…"
              icon={<Link2 className="h-4 w-4" />}
              invalid={invalid}
              inputMode="url"
              autoComplete="off"
              spellCheck={false}
              aria-describedby="yt-url-state"
            />
          </Field>

          <p id="yt-url-state" role="status" className="flex min-h-5 items-center gap-1.5 text-sm">
            {parsed && (
              <>
                <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                <span className="text-emerald-300">Valid URL</span>
                <span className="text-muted">Video ID {parsed.id}</span>
              </>
            )}
            {invalid && (
              <>
                <XCircle className="h-4 w-4 text-red-400" />
                <span className="text-red-300">Invalid URL</span>
              </>
            )}
          </p>

          <div className="flex flex-wrap gap-2.5">
            <Button onClick={save} disabled={!parsed || unchanged} leftIcon={<Save className="h-4 w-4" />}>
              {video ? 'Update screen' : 'Save to screen'}
            </Button>
            <Button variant="outline" onClick={() => setPreviewing((p) => !p)} disabled={!parsed} leftIcon={previewing ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}>
              {previewing ? 'Hide preview' : 'Preview video'}
            </Button>
            <Button variant="ghost" onClick={paste} leftIcon={<ClipboardPaste className="h-4 w-4" />}>
              Paste URL
            </Button>
            <Button variant="ghost" onClick={reset} disabled={!video && !touched} leftIcon={<RotateCcw className="h-4 w-4" />}>
              Reset to default
            </Button>
          </div>

          <p className="text-xs text-muted">
            Demo only: this setting lives in the browser and resets when the page reloads. Browsers may block autoplay, so viewers might need to press play on the screen.
          </p>
        </div>

        <div>
          <p className="mb-2 text-sm font-medium text-white/90">{previewing ? 'Video preview' : 'Screen preview'}</p>
          <div className="relative aspect-video overflow-hidden rounded-2xl border border-line bg-black">
            {previewing && parsed ? (
              <>
                <YouTubeEmbed
                  embedUrl={parsed.embedUrl}
                  title="Cinema screen video preview"
                  className="absolute inset-0 h-full w-full"
                  onStatus={(s, r) => {
                    setStatus(s);
                    setReason(r);
                  }}
                />
                {status === 'error' && (
                  <div className="absolute inset-0 grid place-items-center bg-black/90 p-6 text-center">
                    <div>
                      <XCircle className="mx-auto h-8 w-8 text-red-400" />
                      <p className="mt-2 text-sm font-medium">This video can’t play on the cinema screen</p>
                      <p className="mt-1 text-xs text-muted">{reason ?? 'Try another link.'} The default screen will show instead.</p>
                    </div>
                  </div>
                )}
              </>
            ) : showing && !thumbFailed ? (
              <>
                <img src={showing.thumbnailUrl} alt="" className="h-full w-full object-cover" onError={() => setThumbFailed(true)} />
                <span className="absolute inset-0 grid place-items-center bg-black/35">
                  <span className="grid h-14 w-14 place-items-center rounded-full bg-brand shadow-[0_0_40px_rgba(225,29,46,.55)]">
                    <Play className="h-6 w-6 translate-x-0.5 fill-white" />
                  </span>
                </span>
              </>
            ) : (
              <div className="absolute inset-0 grid place-items-center bg-gradient-to-b from-brand/15 via-black to-black text-center">
                <div>
                  <Film className="mx-auto h-8 w-8 text-white/50" />
                  <p className="mt-2 font-display text-xl font-bold">{showing ? 'No thumbnail available' : 'Default cinema screen'}</p>
                  <p className="mt-0.5 text-xs text-muted">{showing ? 'The video can still play on screen.' : 'The Marquee title card shows until a video is saved.'}</p>
                </div>
              </div>
            )}
          </div>
          {video && (
            <p className="mt-2 truncate text-xs text-muted">
              On the screen now: <span className="text-white/80">{video.watchUrl}</span>
            </p>
          )}
        </div>
      </div>
    </section>
  );
}
