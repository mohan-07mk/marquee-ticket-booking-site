import { useEffect, useRef, useState } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { LayoutDashboard, LogIn, LogOut, Menu, Ticket, User as UserIcon, X } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/context/ToastContext';
import { cn } from '@/utils/cn';
import { Logo } from './Logo';
import { NotificationDropdown } from './NotificationDropdown';
import { buttonClasses } from './ui/Button';

const links = [
  { to: '/', label: 'Home', end: true },
  { to: '/movies', label: 'Movies' },
  { to: '/theatres', label: 'Theatres' },
  { to: '/my-bookings', label: 'My Bookings' },
];

export function Navbar() {
  const { user, logout } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setMobileOpen(false);
    setMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (!menuOpen) return;
    const onDown = (e: MouseEvent) => {
      if (!menuRef.current?.contains(e.target as Node)) setMenuOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, [menuOpen]);

  const handleLogout = async () => {
    await logout();
    setMenuOpen(false);
    toast.info('Signed out', 'See you at the next show.');
    navigate('/');
  };

  const linkClass = ({ isActive }: { isActive: boolean }) =>
    cn(
      'relative px-1 py-2 text-sm font-medium transition-colors',
      isActive ? 'text-white' : 'text-white/60 hover:text-white',
      isActive && 'after:absolute after:inset-x-0 after:-bottom-0.5 after:h-0.5 after:rounded-full after:bg-brand',
    );

  return (
    <header
      className={cn(
        'sticky top-0 z-50 border-b transition-colors duration-300',
        scrolled || mobileOpen ? 'border-line bg-black/85 backdrop-blur-xl' : 'border-transparent bg-gradient-to-b from-black/80 to-transparent',
      )}
    >
      <div className="container-page flex h-[68px] items-center justify-between gap-6">
        <Logo />

        <nav className="hidden items-center gap-8 md:flex" aria-label="Main">
          {links.map((l) => (
            <NavLink key={l.to} to={l.to} end={l.end} className={linkClass}>
              {l.label}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          {!user && (
            <Link to="/login" className={buttonClasses({ variant: 'outline', size: 'sm', className: 'hidden sm:inline-flex' })}>
              <LogIn className="h-4 w-4" />
              Login
            </Link>
          )}

          <NotificationDropdown variant="user" />

          <div className="relative" ref={menuRef}>
            <button
              onClick={() => setMenuOpen((o) => !o)}
              aria-label="Open profile menu"
              aria-expanded={menuOpen}
              className="grid h-10 w-10 place-items-center rounded-full border border-line bg-surface text-white/80 transition hover:border-white/40 hover:text-white"
            >
              <UserIcon className="h-5 w-5" />
            </button>
            {menuOpen && (
              <div className="absolute right-0 top-12 w-64 animate-pop-in rounded-2xl border border-line bg-raised p-2 shadow-2xl shadow-black/70">
                {user ? (
                  <div className="border-b border-line px-3 pb-3 pt-2">
                    <p className="truncate text-sm font-semibold">{user.name}</p>
                    <p className="truncate text-xs text-muted">{user.email}</p>
                  </div>
                ) : (
                  <div className="border-b border-line px-3 pb-3 pt-2">
                    <p className="text-sm font-semibold">Welcome to Marquee</p>
                    <p className="text-xs text-muted">Log in to see your tickets anywhere.</p>
                  </div>
                )}
                <div className="py-1.5">
                  <MenuLink to="/my-bookings" icon={<Ticket className="h-4 w-4" />}>
                    My bookings
                  </MenuLink>
                  {user?.role === 'admin' && (
                    <MenuLink to="/admin" icon={<LayoutDashboard className="h-4 w-4" />}>
                      Admin dashboard
                    </MenuLink>
                  )}
                  {!user && (
                    <MenuLink to="/login" icon={<LogIn className="h-4 w-4" />}>
                      Log in
                    </MenuLink>
                  )}
                </div>
                {user && (
                  <button
                    onClick={handleLogout}
                    className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-red-300 transition hover:bg-red-500/10"
                  >
                    <LogOut className="h-4 w-4" />
                    Log out
                  </button>
                )}
              </div>
            )}
          </div>

          <button
            className="grid h-10 w-10 place-items-center rounded-xl border border-line md:hidden"
            onClick={() => setMobileOpen((o) => !o)}
            aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={mobileOpen}
          >
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <nav className="container-page animate-fade-in border-t border-line pb-5 pt-3 md:hidden" aria-label="Mobile">
          <ul className="space-y-1">
            {links.map((l) => (
              <li key={l.to}>
                <NavLink
                  to={l.to}
                  end={l.end}
                  className={({ isActive }) =>
                    cn('block rounded-xl px-4 py-3 text-base font-medium', isActive ? 'bg-brand/15 text-white' : 'text-white/70 hover:bg-white/5')
                  }
                >
                  {l.label}
                </NavLink>
              </li>
            ))}
          </ul>
          {!user && (
            <Link to="/login" className={buttonClasses({ className: 'mt-4 w-full' })}>
              Login
            </Link>
          )}
        </nav>
      )}
    </header>
  );
}

function MenuLink({ to, icon, children }: { to: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <Link to={to} className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-white/85 transition hover:bg-white/10">
      <span className="text-muted">{icon}</span>
      {children}
    </Link>
  );
}
