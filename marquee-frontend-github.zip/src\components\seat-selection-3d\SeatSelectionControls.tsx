import { useEffect, useRef, useState } from 'react';
import { Box, Hand, MonitorPlay, Minus, Plus, RotateCcw, RotateCw, Undo2, X } from 'lucide-react';
import type { AuditoriumCameraApi, ViewName } from './AuditoriumCamera';

interface Props {
  api: React.RefObject<AuditoriumCameraApi | null>;
  panMode: boolean;
  onPanMode: (pan: boolean) => void;
  /** Leave seat view / screen focus first, then run the action. */
  onCameraAction: () => void;
  hasVideo: boolean;
  screenInteractive: boolean;
  onToggleScreenInteractive: () => void;
}

const VIEWS: { id: ViewName; label: string }[] = [
  { id: 'rear', label: 'From the back' },
  { id: 'front', label: 'From the screen' },
  { id: 'left', label: 'Left side' },
  { id: 'right', label: 'Right side' },
  { id: 'top', label: 'Top view' },
];

/**
 * Deliberately small: rotate, zoom, one "View" menu, pan and reset. Everything
 * else is reachable by dragging, pinching or scrolling on the auditorium.
 */
export function SeatSelectionControls({ api, panMode, onPanMode, onCameraAction, hasVideo, screenInteractive, onToggleScreenInteractive }: Props) {
  const [open, setOpen] = useState(false);
  const wrap = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const close = (e: PointerEvent) => {
      if (!wrap.current?.contains(e.target as Node)) setOpen(false);
    };
    const esc = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('pointerdown', close);
    document.addEventListener('keydown', esc);
    return () => {
      document.removeEventListener('pointerdown', close);
      document.removeEventListener('keydown', esc);
    };
  }, [open]);

  const run = (fn: () => void) => () => {
    onCameraAction();
    fn();
  };

  return (
    <div ref={wrap} className="relative flex flex-col items-center gap-2">
      {open && (
        <div role="menu" aria-label="Camera views" className="mq3d-bar mq3d-pop absolute bottom-full mb-2 flex-col items-stretch gap-0 rounded-2xl p-1.5">
          {VIEWS.map((v) => (
            <button
              key={v.id}
              role="menuitem"
              type="button"
              className="mq3d-btn justify-start rounded-xl px-3 text-left"
              style={{ display: 'flex', borderRadius: 12 }}
              onClick={() => {
                run(() => api.current?.setView(v.id))();
                setOpen(false);
              }}
            >
              {v.label}
            </button>
          ))}
          {hasVideo && (
            <button
              role="menuitem"
              type="button"
              className="mq3d-btn justify-start px-3"
              style={{ display: 'flex', borderRadius: 12 }}
              onClick={() => {
                run(() => api.current?.setView('screen'))();
                setOpen(false);
              }}
            >
              Facing the screen
            </button>
          )}
        </div>
      )}

      <div className="mq3d-bar" role="toolbar" aria-label="Auditorium camera">
        <button type="button" className="mq3d-btn" onClick={run(() => api.current?.rotate('left'))} aria-label="Rotate left" title="Rotate left">
          <RotateCcw className="h-4 w-4" />
        </button>
        <button type="button" className="mq3d-btn" onClick={run(() => api.current?.rotate('right'))} aria-label="Rotate right" title="Rotate right">
          <RotateCw className="h-4 w-4" />
        </button>
        <span className="mq3d-sep" aria-hidden="true" />
        <button type="button" className="mq3d-btn" aria-haspopup="menu" aria-expanded={open} onClick={() => setOpen((o) => !o)} title="Choose a view">
          <span className="flex items-center gap-1.5">
            <Box className="h-4 w-4" />
            <span className="hidden sm:inline">View</span>
          </span>
        </button>
        <span className="mq3d-sep" aria-hidden="true" />
        <button type="button" className="mq3d-btn" onClick={run(() => api.current?.zoom('out'))} aria-label="Zoom out" title="Zoom out">
          <Minus className="h-4 w-4" />
        </button>
        <button type="button" className="mq3d-btn" onClick={run(() => api.current?.zoom('in'))} aria-label="Zoom in" title="Zoom in">
          <Plus className="h-4 w-4" />
        </button>
        <button type="button" className="mq3d-btn" aria-pressed={panMode} onClick={() => onPanMode(!panMode)} aria-label="Pan mode" title="Pan: drag to slide the view">
          <Hand className="h-4 w-4" />
        </button>
        <span className="mq3d-sep" aria-hidden="true" />
        <button type="button" className="mq3d-btn" onClick={run(() => api.current?.reset())} aria-label="Reset camera" title="Reset camera">
          <Undo2 className="h-4 w-4" />
        </button>
        {hasVideo && (
          <>
            <span className="mq3d-sep" aria-hidden="true" />
            <button
              type="button"
              className="mq3d-btn"
              aria-pressed={screenInteractive}
              onClick={onToggleScreenInteractive}
              title={screenInteractive ? 'Back to exploring' : 'Use the video controls on the screen'}
            >
              <span className="flex items-center gap-1.5">
                {screenInteractive ? <X className="h-4 w-4" /> : <MonitorPlay className="h-4 w-4" />}
                <span className="hidden md:inline">{screenInteractive ? 'Done' : 'Play on screen'}</span>
              </span>
            </button>
          </>
        )}
      </div>
    </div>
  );
}

