import { Cookie, Settings, ShieldCheck, X } from 'lucide-react';
import { useCookieConsent } from '@/context/CookieContext';

export function CookieConsentBanner() {
  const { isBannerOpen, acceptAll, acceptEssential, openSettings } = useCookieConsent();

  if (!isBannerOpen) return null;

  return (
    <div
      role="region"
      aria-label="Cookie consent banner"
      className="fixed inset-x-3 bottom-3 z-[90] sm:inset-x-6 sm:bottom-6 sm:max-w-2xl sm:ml-auto"
    >
      <div className="relative overflow-hidden rounded-2xl border border-line bg-surface/95 p-5 shadow-2xl shadow-black/80 backdrop-blur-xl transition-all animate-in fade-in slide-in-from-bottom-5 duration-300 sm:p-6">
        {/* Subtle accent gradient line */}
        <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-red-600 via-rose-500 to-amber-500" />

        <button
          onClick={acceptEssential}
          className="absolute right-3 top-3 rounded-full p-1.5 text-muted transition hover:bg-white/10 hover:text-white"
          aria-label="Close cookie consent banner (accept essential only)"
          title="Accept essential only"
        >
          <X className="h-4 w-4" />
        </button>

        <div className="flex items-start gap-4">
          <div className="hidden rounded-xl bg-red-500/10 p-2.5 text-red-500 sm:flex shrink-0">
            <Cookie className="h-6 w-6" />
          </div>

          <div className="min-w-0 flex-1">
            <h2 className="flex items-center gap-2 font-display text-lg font-bold text-white">
              <span className="sm:hidden">🍪</span> We use cookies
            </h2>

            <p className="mt-2 text-xs leading-relaxed text-muted sm:text-sm">
              Marquee uses essential cookies to keep you signed in, remember preferences, and provide core booking functionality. With your permission, we may use optional analytics cookies to understand how the website is used.
            </p>

            <div className="mt-4 flex flex-wrap items-center gap-2 pt-1 sm:gap-3">
              <button
                type="button"
                onClick={acceptAll}
                className="inline-flex items-center justify-center rounded-xl bg-red-600 px-4 py-2 text-xs font-semibold text-white shadow-lg shadow-red-600/30 transition hover:bg-red-500 active:scale-95 sm:text-sm"
              >
                Accept All
              </button>

              <button
                type="button"
                onClick={acceptEssential}
                className="inline-flex items-center justify-center rounded-xl border border-line bg-white/5 px-4 py-2 text-xs font-medium text-white transition hover:bg-white/10 active:scale-95 sm:text-sm"
              >
                <ShieldCheck className="mr-1.5 h-3.5 w-3.5 text-emerald-400" />
                Essential Only
              </button>

              <button
                type="button"
                onClick={openSettings}
                className="inline-flex items-center justify-center rounded-xl px-3 py-2 text-xs font-medium text-muted transition hover:text-white sm:text-sm"
              >
                <Settings className="mr-1.5 h-3.5 w-3.5" />
                Cookie Settings
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
