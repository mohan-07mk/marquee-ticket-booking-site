import type { Screen, Seat, Show } from '@/types';
import { hashString } from '@/utils/random';

/**
 * MOCK DATA - seat layout generator.
 * In Supabase you would store one row per seat (or per screen layout) and a
 * `booked_seats` table keyed by show_id. `buildSeatLayout` merges the two.
 */
export const rowLabel = (index: number) => String.fromCharCode(65 + index);
export const PREMIUM_ROWS = 3; // last N rows (back of the hall) are premium recliners

export const occupancyRate = (showId: string) => 0.12 + (hashString(showId) % 55) / 100;

export function buildSeatLayout(show: Show, screen: Screen, alsoOccupied: string[] = []): Seat[] {
  const rate = occupancyRate(show.id);
  const premiumFrom = screen.rows - PREMIUM_ROWS;
  const extra = new Set(alsoOccupied);
  const seats: Seat[] = [];

  for (let r = 0; r < screen.rows; r++) {
    for (let n = 1; n <= screen.seatsPerRow; n++) {
      const id = `${rowLabel(r)}${n}`;
      const type = r >= premiumFrom ? 'premium' : 'standard';
      const taken = extra.has(id) || hashString(`${show.id}:${id}`) % 100 < rate * 100;
      seats.push({
        id,
        row: rowLabel(r),
        number: n,
        type,
        status: taken ? 'occupied' : 'available',
        price: type === 'premium' ? show.premiumPrice : show.price,
      });
    }
  }
  return seats;
}
