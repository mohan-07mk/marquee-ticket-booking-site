import { useState } from 'react';
import { CalendarDays, IndianRupee, Receipt, TrendingUp } from 'lucide-react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { ChartCard, chartColors, tooltipStyle } from '@/components/admin/ChartCard';
import { DataTable, type Column } from '@/components/admin/DataTable';
import { StatCard } from '@/components/admin/StatCard';
import { ErrorState } from '@/components/ui/States';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { api } from '@/services/api';
import type { RankedRevenue } from '@/types';
import { cn } from '@/utils/cn';
import { formatCompactCurrency, formatCurrency } from '@/utils/format';

export default function Revenue() {
  useDocumentTitle('Revenue');
  const { data, loading, error, reload } = useAsync(() => api.admin.getRevenue(), []);
  const [range, setRange] = useState<7 | 14 | 30>(14);

  if (error) return <ErrorState message={error} onRetry={reload} />;

  const axis = { stroke: chartColors.axis, fontSize: 12, tickLine: false, axisLine: false } as const;
  const daily = data?.daily.slice(-range);
  const maxTheatre = Math.max(1, ...(data?.byTheatre.map((t) => t.revenue) ?? [1]));

  const theatreColumns: Column<RankedRevenue>[] = [
    { key: 'name', header: 'Theatre', mobile: 'title', cell: (r) => <span className="font-medium">{r.name}</span> },
    { key: 'bookings', header: 'Bookings', cell: (r) => r.bookings.toLocaleString('en-IN') },
    {
      key: 'share',
      header: 'Share of top theatre',
      className: 'w-56',
      cell: (r) => (
        <div className="flex items-center gap-3">
          <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/10">
            <div className="h-full rounded-full bg-brand" style={{ width: `${(r.revenue / maxTheatre) * 100}%` }} />
          </div>
        </div>
      ),
    },
    { key: 'revenue', header: 'Revenue', className: 'text-right', cell: (r) => <span className="font-semibold">{formatCurrency(r.revenue)}</span> },
  ];

  return (
    <div className="space-y-6">
      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4" aria-label="Revenue summary">
        <StatCard loading={loading} label="Total revenue" value={formatCompactCurrency(data?.total ?? 0)} icon={IndianRupee} />
        <StatCard loading={loading} label="This month" value={formatCompactCurrency(data?.thisMonth ?? 0)} icon={CalendarDays} />
        <StatCard loading={loading} label="Booked today" value={formatCompactCurrency(data?.today ?? 0)} icon={TrendingUp} />
        <StatCard loading={loading} label="Average per booking" value={formatCurrency(data?.avgPerBooking ?? 0)} icon={Receipt} />
      </section>

      <section className="rounded-3xl border border-line bg-surface p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h3 className="font-display text-2xl font-bold leading-none">Daily revenue</h3>
            <p className="mt-1.5 text-sm text-muted">Revenue booked each day</p>
          </div>
          <div role="group" aria-label="Date range" className="inline-flex rounded-xl border border-line p-1">
            {([7, 14, 30] as const).map((r) => (
              <button
                key={r}
                aria-pressed={range === r}
                onClick={() => setRange(r)}
                className={cn('rounded-lg px-3.5 py-1.5 text-sm font-medium transition', range === r ? 'bg-white text-black' : 'text-white/65 hover:text-white')}
              >
                {r} days
              </button>
            ))}
          </div>
        </div>
        <div className="mt-5 h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={daily} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
              <CartesianGrid stroke={chartColors.grid} vertical={false} />
              <XAxis dataKey="label" {...axis} interval="preserveStartEnd" />
              <YAxis {...axis} tickFormatter={(v) => formatCompactCurrency(Number(v))} width={60} />
              <Tooltip {...tooltipStyle} formatter={(v) => [formatCurrency(Number(v)), '']} separator="" />
              <Bar dataKey="revenue" fill={chartColors.brand} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>

      <div className="grid gap-6 xl:grid-cols-2">
        <ChartCard title="Monthly revenue" subtitle="Last 6 months" loading={loading}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data?.monthly} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
              <CartesianGrid stroke={chartColors.grid} vertical={false} />
              <XAxis dataKey="month" {...axis} />
              <YAxis {...axis} tickFormatter={(v) => formatCompactCurrency(Number(v))} width={60} />
              <Tooltip {...tooltipStyle} formatter={(v) => [formatCurrency(Number(v)), '']} separator="" />
              <Bar dataKey="revenue" fill={chartColors.soft} radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Revenue by movie" subtitle="Top 8 titles" loading={loading}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data?.byMovie} layout="vertical" margin={{ top: 0, right: 12, left: 0, bottom: 0 }}>
              <CartesianGrid stroke={chartColors.grid} horizontal={false} />
              <XAxis type="number" {...axis} tickFormatter={(v) => formatCompactCurrency(Number(v))} />
              <YAxis type="category" dataKey="name" width={120} {...axis} />
              <Tooltip {...tooltipStyle} formatter={(v) => [formatCurrency(Number(v)), '']} separator="" />
              <Bar dataKey="revenue" fill={chartColors.brand} radius={[0, 8, 8, 0]} barSize={14} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <section>
        <h3 className="mb-4 font-display text-2xl font-bold leading-none">Revenue by theatre</h3>
        <DataTable columns={theatreColumns} rows={data?.byTheatre ?? []} rowKey={(r) => r.id} loading={loading} pageSize={10} />
      </section>
    </div>
  );
}
