import type { ReactNode } from 'react';
import type { Seat, ShowDetails } from '@/types';
import { calcTotals } from '@/utils/pricing';
import { formatCurrency, formatLongDate, formatTime } from '@/utils/format';
import { Badge } from './ui/Badge';
import { TicketDivider } from './TicketDivider';

interface Props {
  details: ShowDetails;
  seats: Seat[];
  cta?: ReactNode;
  className?: string;
}

export function BookingSummary({ details, seats, cta, className }: Props) {
  const { movie, theatre, screen, show } = details;
  const { subtotal, convenienceFee, total } = calcTotals(seats);
  const standard = seats.filter((s) => s.type === 'standard');
  const premium = seats.filter((s) => s.type === 'premium');

  return (
    <aside
      aria-label="Booking summary"
      className={`relative overflow-hidden rounded-3xl border border-line bg-surface p-6 ${className ?? ''}`}
    >
      <div className="flex gap-4">
        <img src={movie.posterUrl} alt="" className="h-28 w-[76px] shrink-0 rounded-xl border border-line object-cover" />
        <div className="min-w-0">
          <h2 className="font-display text-2xl font-bold leading-tight">{movie.title}</h2>
          <div className="mt-2 flex flex-wrap gap-1.5">
            <Badge tone={show.format === 'IMAX' ? 'brand' : 'neutral'}>{show.format}</Badge>
            <Badge>{show.language}</Badge>
            <Badge>{movie.certificate}</Badge>
          </div>
        </div>
      </div>

      <dl className="mt-5 space-y-2.5 text-sm">
        <Row label="Theatre" value={theatre.name} />
        <Row label="Screen" value={screen.name} />
        <Row label="Date" value={formatLongDate(show.date)} />
        <Row label="Time" value={formatTime(show.time)} />
        <div className="flex items-start justify-between gap-4">
          <dt className="text-muted">Seats</dt>
          <dd className="flex max-w-[65%] flex-wrap justify-end gap-1.5">
            {seats.length ? (
              seats.map((s) => (
                <span
                  key={s.id}
                  className={`rounded-md border px-1.5 py-0.5 text-xs font-semibold ${s.type === 'premium' ? 'border-gold/50 text-gold' : 'border-white/25'}`}
                >
                  {s.label || `${s.row}${s.number}`}
                </span>
              ))
            ) : (
              <span className="text-muted">None selected</span>
            )}
          </dd>
        </div>
      </dl>

      <TicketDivider />

      <dl className="space-y-2.5 text-sm">
        {standard.length > 0 && <Row label={`Standard × ${standard.length}`} value={formatCurrency(standard.reduce((s, x) => s + x.price, 0))} />}
        {premium.length > 0 && <Row label={`Premium × ${premium.length}`} value={formatCurrency(premium.reduce((s, x) => s + x.price, 0))} />}
        {seats.length === 0 && <Row label="Tickets" value={formatCurrency(0)} />}
        <Row label="Ticket price" value={formatCurrency(subtotal)} muted />
        <Row label="Convenience fee" value={formatCurrency(convenienceFee)} muted />
        <div className="flex items-end justify-between border-t border-line pt-4">
          <dt className="font-medium">Total amount</dt>
          <dd className="font-display text-4xl font-extrabold leading-none">{formatCurrency(total)}</dd>
        </div>
      </dl>

      {cta && <div className="mt-6">{cta}</div>}
    </aside>
  );
}

function Row({ label, value, muted }: { label: string; value: string; muted?: boolean }) {
  return (
    <div className="flex items-start justify-between gap-4">
      <dt className="text-muted">{label}</dt>
      <dd className={muted ? 'text-white/70' : 'text-right font-medium'}>{value}</dd>
    </div>
  );
}
