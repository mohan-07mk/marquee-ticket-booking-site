-- ==============================================================================
-- MARQUEE CINEMAS - RAZORPAY PAYMENT & BOOKING SCHEMA MIGRATION
-- ==============================================================================

-- 1. Ensure UNIQUE constraint on booking_seats (show_id, seat_id) to prevent duplicate seat bookings
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'booking_seats_show_seat_unique'
  ) THEN
    ALTER TABLE booking_seats ADD CONSTRAINT booking_seats_show_seat_unique UNIQUE (show_id, seat_id);
  END IF;
END $$;

-- 2. Add Razorpay columns to bookings table if not existing
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS razorpay_order_id TEXT;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS razorpay_payment_id TEXT;
ALTER TABLE bookings ADD COLUMN IF NOT EXISTS payment_status TEXT DEFAULT 'pending';

-- 3. Add Razorpay columns to payments table if not existing
ALTER TABLE payments ADD COLUMN IF NOT EXISTS razorpay_order_id TEXT;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS razorpay_payment_id TEXT;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS razorpay_signature TEXT;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS user_id TEXT;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS show_id TEXT;
ALTER TABLE payments ADD COLUMN IF NOT EXISTS seat_ids TEXT[];
ALTER TABLE payments ADD COLUMN IF NOT EXISTS error_message TEXT;

-- 4. Create razorpay_orders table for tracking order initialization & state before payment completion
CREATE TABLE IF NOT EXISTS razorpay_orders (
  id TEXT PRIMARY KEY, -- Razorpay order_id (e.g. order_KzXXXXXX)
  created_at TIMESTAMPTZ DEFAULT now(),
  user_id TEXT NOT NULL,
  show_id TEXT NOT NULL,
  seat_ids TEXT[] NOT NULL,
  amount NUMERIC NOT NULL,
  currency TEXT DEFAULT 'INR',
  subtotal NUMERIC,
  convenience_fee NUMERIC,
  status TEXT DEFAULT 'created', -- 'created', 'paid', 'failed', 'conflict_refunded'
  customer_name TEXT,
  customer_email TEXT,
  booking_id TEXT
);

-- Index for fast lookup by order id and user id
CREATE INDEX IF NOT EXISTS idx_razorpay_orders_user ON razorpay_orders(user_id);
CREATE INDEX IF NOT EXISTS idx_bookings_razorpay_order ON bookings(razorpay_order_id);
CREATE INDEX IF NOT EXISTS idx_payments_razorpay_order ON payments(razorpay_order_id);
