import { CalendarDays, Clock, MapPin, Monitor } from 'lucide-react';
import type { Booking } from '@/types';
import { hashString, mulberry32 } from '@/utils/random';
import { formatCurrency, formatLongDate, formatTime } from '@/utils/format';
import { Badge } from './ui/Badge';

/**
 * Pseudo QR code, seeded from the booking id.
 * PLACEHOLDER: swap for a real QR (e.g. the `qrcode.react` package) that encodes
 * the booking id / a signed ticket URL so it can be scanned at the theatre.
 */
export function PseudoQR({ value, size = 168 }: { value: string; size?: number }) {
  const n = 25;
  const rand = mulberry32(hashString(value));
  const finder = (x: number, y: number) => {
    const inBox = (ox: number, oy: number) => x >= ox && x < ox + 7 && y >= oy && y < oy + 7;
    const corners: Array<[number, number]> = [
      [0, 0],
      [n - 7, 0],
      [0, n - 7],
    ];
    for (const [ox, oy] of corners) {
      if (inBox(ox, oy)) {
        const dx = x - ox;
        const dy = y - oy;
        const ring = Math.max(Math.abs(dx - 3), Math.abs(dy - 3));
        return ring === 3 || ring <= 1;
      }
    }
    return null;
  };
  const cells: JSX.Element[] = [];
  for (let y = 0; y < n; y++) {
    for (let x = 0; x < n; x++) {
      const reserved = finder(x, y);
      const on = reserved !== null ? reserved : rand() > 0.52;
      if (on) cells.push(<rect key={`${x}-${y}`} x={x + 2} y={y + 2} width="1" height="1" />);
    }
  }
  return (
    <svg viewBox={`0 0 ${n + 4} ${n + 4}`} width={size} height={size} role="img" aria-label={`QR code placeholder for booking ${value}`} className="rounded-xl bg-white">
      <g fill="#000" shapeRendering="crispEdges">
        {cells}
      </g>
    </svg>
  );
}

export function Ticket({ booking }: { booking: Booking }) {
  const cancelled = booking.status === 'cancelled';
  return (
    <div className="print-area relative flex flex-col overflow-hidden rounded-3xl border border-line bg-surface md:flex-row">
      {/* Main */}
      <div className="relative flex-1 p-6 md:p-8">
        <img src={booking.posterUrl} alt="" aria-hidden="true" className="absolute inset-0 h-full w-full scale-125 object-cover opacity-[0.12] blur-2xl" />
        <div className="relative flex gap-5">
          <img src={booking.posterUrl} alt={`${booking.movieTitle} poster`} className="hidden h-40 w-[106px] shrink-0 rounded-xl border border-line object-cover sm:block" />
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone="brand">{booking.format}</Badge>
              {cancelled && <Badge tone="danger">Cancelled</Badge>}
            </div>
            <h2 className="mt-2 font-display text-4xl font-extrabold leading-none sm:text-5xl">{booking.movieTitle}</h2>
            <dl className="mt-5 grid grid-cols-2 gap-x-6 gap-y-4 text-sm">
              <Item icon={<MapPin className="h-4 w-4" />} label="Theatre" value={booking.theatreName} />
              <Item icon={<Monitor className="h-4 w-4" />} label="Screen" value={booking.screenName} />
              <Item icon={<CalendarDays className="h-4 w-4" />} label="Date" value={formatLongDate(booking.date)} />
              <Item icon={<Clock className="h-4 w-4" />} label="Time" value={formatTime(booking.time)} />
            </dl>
            <div className="mt-5">
              <p className="text-xs text-muted">Seats</p>
              <div className="mt-1.5 flex flex-wrap gap-1.5">
                {booking.seats.map((s) => (
                  <span key={s} className="rounded-md border border-white/30 px-2 py-0.5 text-sm font-semibold">
                    {s}
                  </span>
                ))}
              </div>
            </div>
            <div className="mt-5 flex items-end justify-between gap-4 border-t border-line pt-4">
              <div>
                <p className="text-xs text-muted">Booking ID</p>
                <p className="font-display text-2xl font-bold tracking-wider">{booking.id}</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-muted">Amount paid</p>
                <p className="font-display text-3xl font-extrabold leading-none">{formatCurrency(booking.amount)}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Perforation */}
      <div className="relative h-0 md:h-auto md:w-0" aria-hidden="true">
        <div className="absolute inset-x-6 top-0 border-t-2 border-dashed border-line md:inset-x-auto md:inset-y-6 md:left-0 md:border-l-2 md:border-t-0" />
        <span className="absolute -left-3 -top-3 h-6 w-6 rounded-full border border-line bg-base md:left-0 md:-translate-x-1/2" />
        <span className="absolute -right-3 -top-3 h-6 w-6 rounded-full border border-line bg-base md:-bottom-3 md:left-0 md:right-auto md:top-auto md:-translate-x-1/2" />
      </div>

      {/* Stub */}
      <div className="flex flex-col items-center justify-center gap-3 p-6 md:w-72 md:p-8">
        <PseudoQR value={booking.id} />
        <p className="text-center text-xs text-muted">Show this code at the entrance. Please arrive 15 minutes early.</p>
      </div>
    </div>
  );
}

function Item({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div>
      <dt className="flex items-center gap-1.5 text-xs text-muted">
        {icon}
        {label}
      </dt>
      <dd className="mt-0.5 font-medium">{value}</dd>
    </div>
  );
}
