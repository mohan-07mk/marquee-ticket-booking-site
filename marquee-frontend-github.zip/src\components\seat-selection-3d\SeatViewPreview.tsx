import { Eye } from 'lucide-react';
import type { Seat } from '@/types';
import { Button } from '@/components/ui/Button';
import { formatCurrency } from '@/utils/format';
import { describeSeatView, FRONT_GAP, type AuditoriumLayout } from './seatLayout';

interface Props {
  layout: AuditoriumLayout;
  seat: Seat | null;
  inSeatView: boolean;
  onViewFromSeat: (seatId: string) => void;
}

/**
 * "What will I see from here?" panel: a top-down plan with the sightline to the
 * screen, plus a plain-language rating and a button that moves the 3D camera
 * to the seat's eye position.
 */
export function SeatViewPreview({ layout, seat, inSeatView, onViewFromSeat }: Props) {
  const info = seat ? describeSeatView(layout, seat.id) : null;
  const placement = seat ? layout.byId.get(seat.id) : undefined;

  // Plan geometry (viewBox 200 x 120)
  const X = (x: number) => 14 + ((x + layout.width / 2) / layout.width) * 172;
  const Z = (z: number) => 24 + ((z - FRONT_GAP + 1) / (layout.length - FRONT_GAP)) * 88;
  const screenLeft = X(-layout.screen.width / 2);
  const screenRight = X(layout.screen.width / 2);

  return (
    <div className="rounded-2xl border border-line bg-black/40 p-4" aria-live="polite">
      <div className="flex gap-4">
        <svg viewBox="0 0 200 120" className="h-[104px] w-[173px] shrink-0 rounded-xl bg-white/[0.03]" role="img" aria-label="Plan of the hall showing where this seat sits">
          <rect x={screenLeft} y="8" width={screenRight - screenLeft} height="4" rx="2" fill="#e11d2e" />
          {layout.placements.map((p) => (
            <circle key={p.seat.id} cx={X(p.x)} cy={Z(p.z)} r="1.7" fill={p.seat.type === 'premium' ? '#f5b94266' : '#ffffff33'} />
          ))}
          {placement && (
            <>
              <path d={`M ${X(placement.x)} ${Z(placement.z)} L ${screenLeft} 12 L ${screenRight} 12 Z`} fill="#e11d2e" opacity="0.16" />
              <circle cx={X(placement.x)} cy={Z(placement.z)} r="4" fill="#e11d2e" stroke="#fff" strokeWidth="1.2" />
            </>
          )}
        </svg>

        <div className="min-w-0 flex-1 text-sm">
          {seat && info ? (
            <>
              <p className="font-display text-2xl font-bold leading-none">
                Seat {seat.label || `${seat.row}${seat.number}`}
                <span className={`ml-2 align-middle text-xs font-sans font-medium ${seat.type === 'premium' ? 'text-gold' : 'text-white/60'}`}>
                  {seat.type === 'premium' ? 'Premium recliner' : 'Standard'}, {formatCurrency(seat.price)}
                </span>
              </p>
              <dl className="mt-2 space-y-0.5 text-white/70">
                <div className="flex justify-between gap-3">
                  <dt className="text-muted">Row {seat.row}</dt>
                  <dd>{info.zone}</dd>
                </div>
                <div className="flex justify-between gap-3">
                  <dt className="text-muted">Distance to screen</dt>
                  <dd>{info.distance.toFixed(1)} m</dd>
                </div>
                <div className="flex justify-between gap-3">
                  <dt className="text-muted">View</dt>
                  <dd className="font-medium text-white">{info.quality}</dd>
                </div>
              </dl>
            </>
          ) : (
            <p className="text-white/60">Hover or tap a seat to see where it sits and how the screen looks from there.</p>
          )}
        </div>
      </div>

      {seat && (
        <Button
          variant={inSeatView ? 'secondary' : 'outline'}
          size="sm"
          className="mt-3 w-full"
          leftIcon={<Eye className="h-4 w-4" />}
          onClick={() => onViewFromSeat(seat.id)}
          disabled={seat.status === 'occupied'}
        >
          {seat.status === 'occupied' ? 'This seat is booked' : `See the view from ${seat.label || `${seat.row}${seat.number}`}`}
        </Button>
      )}
    </div>
  );
}
