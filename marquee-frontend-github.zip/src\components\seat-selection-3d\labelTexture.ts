import { CanvasTexture, SRGBColorSpace } from 'three';

/**
 * Small canvas-drawn label textures (row letters, seat numbers). Drawing them
 * ourselves avoids loading a font file at runtime. Textures are cached.
 */
const cache = new Map<string, CanvasTexture>();

export function labelTexture(text: string, color = '#ffffff', weight = 700): CanvasTexture {
  const key = `${text}|${color}|${weight}`;
  const hit = cache.get(key);
  if (hit) return hit;

  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  ctx.clearRect(0, 0, 128, 128);
  ctx.fillStyle = color;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = `${weight} ${text.length > 2 ? 62 : 84}px "DM Sans", system-ui, sans-serif`;
  ctx.fillText(text, 64, 70);

  const texture = new CanvasTexture(canvas);
  texture.colorSpace = SRGBColorSpace;
  texture.anisotropy = 4;
  cache.set(key, texture);
  return texture;
}
