import { mulberry32 } from './random';

/**
 * Generates poster / backdrop artwork as inline SVG data URIs so the demo has
 * zero external image dependencies. In production, replace `posterUrl` and
 * `backdropUrl` with Supabase Storage (or CDN) URLs.
 */
type Palette = [string, string, string];

const PALETTES: Palette[] = [
  ['#3b0a12', '#e11d2e', '#ffb38a'],
  ['#08222e', '#1e90b4', '#9be7ff'],
  ['#1d1035', '#7c3aed', '#f0abfc'],
  ['#2b1a05', '#d97706', '#fde68a'],
  ['#062015', '#16a34a', '#bbf7d0'],
  ['#1b1b1b', '#71717a', '#f4f4f5'],
  ['#2a0a24', '#db2777', '#fbcfe8'],
  ['#0b1a3a', '#2563eb', '#bfdbfe'],
];

const escapeXml = (s: string) =>
  s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

function motif(kind: number, w: number, h: number, [c0, c1, c2]: Palette, rand: () => number) {
  switch (kind % 5) {
    case 0: {
      const bands = [0, 1, 2, 3, 4]
        .map((i) => `<rect x="0" y="${h * (0.4 + i * 0.038)}" width="${w}" height="${h * (0.008 + i * 0.007)}" fill="${c0}"/>`)
        .join('');
      return `<circle cx="${w * 0.5}" cy="${h * 0.38}" r="${w * 0.25}" fill="${c2}" opacity="0.95"/>${bands}`;
    }
    case 1: {
      return [0, 1, 2, 3, 4, 5]
        .map(
          (i) =>
            `<polygon points="${w * 0.5},${h * 0.85} ${w * (-0.1 + i * 0.22)},0 ${w * (0.02 + i * 0.22)},0" fill="${c2}" opacity="${0.1 + (i % 3) * 0.06}"/>`,
        )
        .join('');
    }
    case 2: {
      const n = 12;
      const bars = Array.from({ length: n }, (_, i) => {
        const bh = h * (0.14 + rand() * 0.3);
        return `<rect x="${(i * w) / n + 2}" y="${h * 0.78 - bh}" width="${w / n - 4}" height="${bh}" fill="${c0}" opacity="0.85"/>`;
      }).join('');
      return `<circle cx="${w * 0.72}" cy="${h * 0.2}" r="${w * 0.1}" fill="${c2}"/>${bars}`;
    }
    case 3: {
      return [1, 2, 3, 4, 5]
        .map((i) => `<circle cx="${w * 0.5}" cy="${h * 0.38}" r="${w * 0.07 * i}" fill="none" stroke="${c2}" stroke-width="${w * 0.006}" opacity="${0.95 - i * 0.14}"/>`)
        .join('');
    }
    default: {
      return `<circle cx="${w * 0.7}" cy="${h * 0.24}" r="${w * 0.09}" fill="${c2}"/>
        <polygon points="0,${h * 0.8} ${w * 0.3},${h * 0.42} ${w * 0.62},${h * 0.8}" fill="${c1}" opacity="0.75"/>
        <polygon points="${w * 0.3},${h * 0.8} ${w * 0.66},${h * 0.32} ${w},${h * 0.8}" fill="${c0}" opacity="0.9"/>`;
    }
  }
}

function wrapTitle(title: string): string[] {
  const words = title.toUpperCase().split(' ');
  const lines: string[] = [];
  let cur = '';
  for (const w of words) {
    if ((cur + ' ' + w).trim().length > 11 && cur) {
      lines.push(cur);
      cur = w;
    } else {
      cur = (cur + ' ' + w).trim();
    }
  }
  if (cur) lines.push(cur);
  return lines.slice(0, 4);
}

export function makeArt(title: string, seed: number, kind: 'poster' | 'backdrop' = 'poster'): string {
  const palette = PALETTES[seed % PALETTES.length];
  const [c0, c1] = palette;
  const w = kind === 'poster' ? 600 : 1600;
  const h = 900;
  const rand = mulberry32(seed * 9973 + 17);

  let text = '';
  if (kind === 'poster') {
    const lines = wrapTitle(title);
    const longest = Math.max(...lines.map((l) => l.length));
    const size = Math.min(w * 0.15, (w - 96) / (longest * 0.5));
    const startY = h * 0.9 - (lines.length - 1) * size * 0.95;
    text = lines
      .map(
        (l, i) =>
          `<text x="48" y="${startY + i * size * 0.95}" font-family="Impact, 'Arial Narrow', 'Helvetica Neue', Arial, sans-serif" font-weight="900" font-size="${size}" fill="#ffffff" letter-spacing="2">${escapeXml(l)}</text>`,
      )
      .join('');
  }

  const art =
    kind === 'backdrop'
      ? `<g transform="translate(${w * 0.2},0)">${motif(seed + 2, w * 0.8, h, palette, rand)}</g>`
      : motif(seed + 2, w, h, palette, rand);

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" preserveAspectRatio="xMidYMid slice">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${c1}"/><stop offset="0.7" stop-color="${c0}"/><stop offset="1" stop-color="#000"/></linearGradient>
    <linearGradient id="fade" x1="0" y1="0" x2="0" y2="1"><stop offset="0.5" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity="0.88"/></linearGradient>
  </defs>
  <rect width="${w}" height="${h}" fill="url(#bg)"/>
  ${art}
  <rect width="${w}" height="${h}" fill="url(#fade)"/>
  ${text}
</svg>`;

  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}
