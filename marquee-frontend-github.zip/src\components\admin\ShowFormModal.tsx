import { useMemo, useState, type FormEvent } from 'react';
import type { Format, Movie, Show, ShowStatus, Theatre } from '@/types';
import { useToast } from '@/context/ToastContext';
import { api } from '@/services/api';
import { todayKey } from '@/utils/format';
import { standardPrice } from '@/utils/pricing';
import { Button } from '../ui/Button';
import { Field, Input, Select } from '../ui/Field';
import { Modal } from '../ui/Modal';

interface Props {
  open: boolean;
  show: Show | null;
  movies: Movie[];
  theatres: Theatre[];
  onClose: () => void;
  onSaved: () => void;
}

export function ShowFormModal({ open, ...rest }: Props) {
  if (!open) return null;
  return <Inner key={rest.show?.id ?? 'new'} {...rest} />;
}

function Inner({ show, movies, theatres, onClose, onSaved }: Omit<Props, 'open'>) {
  const toast = useToast();
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const bookable = movies.filter((m) => m.status === 'now_showing');
  const activeTheatres = theatres.filter((t) => t.status === 'active');

  const [f, setF] = useState({
    movieId: show?.movieId ?? bookable[0]?.id ?? '',
    theatreId: show?.theatreId ?? activeTheatres[0]?.id ?? '',
    screenId: show?.screenId ?? activeTheatres[0]?.screens[0]?.id ?? '',
    date: show?.date ?? todayKey(),
    time: show?.time ?? '19:45',
    format: (show?.format ?? '2D') as Format,
    language: show?.language ?? bookable[0]?.languages[0] ?? '',
    price: String(show?.price ?? 190),
    status: (show?.status ?? 'active') as ShowStatus,
  });

  const movie = movies.find((m) => m.id === f.movieId);
  const theatre = theatres.find((t) => t.id === f.theatreId);
  const screen = theatre?.screens.find((s) => s.id === f.screenId);
  const formatOptions = useMemo(
    () => (screen && movie ? screen.formats.filter((x) => movie.formats.includes(x)) : []),
    [screen, movie],
  );
  const movieOptions = show && !bookable.some((m) => m.id === show.movieId) ? [...bookable, ...movies.filter((m) => m.id === show.movieId)] : bookable;
  const theatreOptions = show && !activeTheatres.some((t) => t.id === show.theatreId) ? [...activeTheatres, ...theatres.filter((t) => t.id === show.theatreId)] : activeTheatres;

  const pickMovie = (id: string) => {
    const m = movies.find((x) => x.id === id);
    const fmts = screen && m ? screen.formats.filter((x) => m.formats.includes(x)) : [];
    setF((p) => ({ ...p, movieId: id, language: m?.languages[0] ?? '', format: fmts[0] ?? p.format }));
  };
  const pickTheatre = (id: string) => {
    const t = theatres.find((x) => x.id === id);
    const s = t?.screens[0];
    const fmts = s && movie ? s.formats.filter((x) => movie.formats.includes(x)) : [];
    setF((p) => ({ ...p, theatreId: id, screenId: s?.id ?? '', format: fmts[0] ?? p.format }));
  };
  const pickScreen = (id: string) => {
    const s = theatre?.screens.find((x) => x.id === id);
    const fmts = s && movie ? s.formats.filter((x) => movie.formats.includes(x)) : [];
    setF((p) => ({ ...p, screenId: id, format: fmts.includes(p.format) ? p.format : (fmts[0] ?? p.format) }));
  };
  const suggestPrice = () => setF((p) => ({ ...p, price: String(standardPrice(p.format, p.theatreId, p.time)) }));

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const next: Record<string, string> = {};
    if (!f.movieId) next.movieId = 'Choose a movie.';
    if (!f.theatreId) next.theatreId = 'Choose a theatre.';
    if (!f.screenId) next.screenId = 'Choose a screen.';
    if (!f.date) next.date = 'Choose a date.';
    if (!f.time) next.time = 'Choose a start time.';
    if (formatOptions.length && !formatOptions.includes(f.format)) next.format = 'This screen can’t show the movie in that format.';
    const price = Number(f.price);
    if (!price || price < 50 || price > 2000) next.price = 'Enter a price between ₹50 and ₹2000.';
    setErrors(next);
    if (Object.keys(next).length) return;

    setSaving(true);
    try {
      const input = { movieId: f.movieId, theatreId: f.theatreId, screenId: f.screenId, date: f.date, time: f.time, format: f.format, language: f.language, price, status: f.status };
      if (show) await api.shows.update(show.id, input);
      else await api.shows.create(input);
      toast.success(show ? 'Show updated' : 'Show scheduled', `${movie?.title ?? 'Show'} at ${theatre?.name ?? ''}`);
      onSaved();
      onClose();
    } catch (err) {
      toast.error('Couldn’t save the show', err instanceof Error ? err.message : undefined);
      setSaving(false);
    }
  };

  return (
    <Modal
      open
      onClose={saving ? () => undefined : onClose}
      title={show ? 'Edit show' : 'Add show'}
      description="Premium seats are priced at about 1.5 times the standard price."
      size="lg"
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={saving}>
            Cancel
          </Button>
          <Button type="submit" form="show-form" loading={saving}>
            {show ? 'Save changes' : 'Add show'}
          </Button>
        </>
      }
    >
      <form id="show-form" onSubmit={submit} noValidate className="grid gap-5 sm:grid-cols-2">
        <Field label="Movie" htmlFor="s-movie" error={errors.movieId} className="sm:col-span-2">
          <Select id="s-movie" value={f.movieId} onChange={(e) => pickMovie(e.target.value)}>
            {movieOptions.map((m) => (
              <option key={m.id} value={m.id}>
                {m.title}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Theatre" htmlFor="s-theatre" error={errors.theatreId}>
          <Select id="s-theatre" value={f.theatreId} onChange={(e) => pickTheatre(e.target.value)}>
            {theatreOptions.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Screen" htmlFor="s-screen" error={errors.screenId}>
          <Select id="s-screen" value={f.screenId} onChange={(e) => pickScreen(e.target.value)}>
            {theatre?.screens.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} ({s.capacity} seats)
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Date" htmlFor="s-date" error={errors.date}>
          <Input id="s-date" type="date" value={f.date} invalid={!!errors.date} onChange={(e) => setF({ ...f, date: e.target.value })} />
        </Field>
        <Field label="Start time" htmlFor="s-time" error={errors.time}>
          <Input id="s-time" type="time" value={f.time} invalid={!!errors.time} onChange={(e) => setF({ ...f, time: e.target.value })} />
        </Field>
        <Field label="Format" htmlFor="s-format" error={errors.format}>
          <Select id="s-format" value={f.format} invalid={!!errors.format} onChange={(e) => setF({ ...f, format: e.target.value as Format })}>
            {(formatOptions.length ? formatOptions : (['2D', '3D', 'IMAX'] as Format[])).map((x) => (
              <option key={x}>{x}</option>
            ))}
          </Select>
        </Field>
        <Field label="Language" htmlFor="s-lang">
          <Select id="s-lang" value={f.language} onChange={(e) => setF({ ...f, language: e.target.value })}>
            {(movie?.languages ?? []).map((l) => (
              <option key={l}>{l}</option>
            ))}
          </Select>
        </Field>
        <Field label="Standard ticket price (₹)" htmlFor="s-price" error={errors.price} hint="Use “Suggest” to fill in the usual price for this format and time.">
          <div className="flex gap-2">
            <Input id="s-price" type="number" min={50} value={f.price} invalid={!!errors.price} onChange={(e) => setF({ ...f, price: e.target.value })} />
            <Button type="button" variant="outline" onClick={suggestPrice}>
              Suggest
            </Button>
          </div>
        </Field>
        <Field label="Status" htmlFor="s-status">
          <Select id="s-status" value={f.status} onChange={(e) => setF({ ...f, status: e.target.value as ShowStatus })}>
            <option value="active">Active</option>
            <option value="cancelled">Cancelled</option>
          </Select>
        </Field>
      </form>
    </Modal>
  );
}
