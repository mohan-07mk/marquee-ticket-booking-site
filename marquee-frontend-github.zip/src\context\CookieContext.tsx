import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';

export type ConsentValue = 'all' | 'essential' | 'custom';

interface CookieContextType {
  consent: ConsentValue | null;
  analyticsEnabled: boolean;
  isBannerOpen: boolean;
  isModalOpen: boolean;
  acceptAll: () => void;
  acceptEssential: () => void;
  saveCustom: (analytics: boolean) => void;
  openSettings: () => void;
  closeSettings: () => void;
}

const COOKIE_CONSENT_KEY = 'marquee_cookie_consent';

const CookieContext = createContext<CookieContextType | null>(null);

export function CookieProvider({ children }: { children: ReactNode }) {
  const [consent, setConsent] = useState<ConsentValue | null>(() => {
    try {
      const stored = localStorage.getItem(COOKIE_CONSENT_KEY);
      if (stored === 'all' || stored === 'essential' || stored === 'custom') {
        return stored;
      }
    } catch {
      /* ignore */
    }
    return null;
  });

  const [analyticsEnabled, setAnalyticsEnabled] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem(COOKIE_CONSENT_KEY);
      return stored === 'all';
    } catch {
      return false;
    }
  });

  const [isBannerOpen, setIsBannerOpen] = useState<boolean>(consent === null);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  useEffect(() => {
    if (consent === null) {
      setIsBannerOpen(true);
    } else {
      setIsBannerOpen(false);
    }
  }, [consent]);

  const acceptAll = useCallback(() => {
    try {
      localStorage.setItem(COOKIE_CONSENT_KEY, 'all');
    } catch {
      /* ignore */
    }
    setConsent('all');
    setAnalyticsEnabled(true);
    setIsBannerOpen(false);
    setIsModalOpen(false);
  }, []);

  const acceptEssential = useCallback(() => {
    try {
      localStorage.setItem(COOKIE_CONSENT_KEY, 'essential');
    } catch {
      /* ignore */
    }
    setConsent('essential');
    setAnalyticsEnabled(false);
    setIsBannerOpen(false);
    setIsModalOpen(false);
  }, []);

  const saveCustom = useCallback((analytics: boolean) => {
    const val: ConsentValue = analytics ? 'all' : 'essential';
    try {
      localStorage.setItem(COOKIE_CONSENT_KEY, val);
    } catch {
      /* ignore */
    }
    setConsent(val);
    setAnalyticsEnabled(analytics);
    setIsBannerOpen(false);
    setIsModalOpen(false);
  }, []);

  const openSettings = useCallback(() => {
    setIsModalOpen(true);
  }, []);

  const closeSettings = useCallback(() => {
    setIsModalOpen(false);
  }, []);

  const value = useMemo(
    () => ({
      consent,
      analyticsEnabled,
      isBannerOpen,
      isModalOpen,
      acceptAll,
      acceptEssential,
      saveCustom,
      openSettings,
      closeSettings,
    }),
    [consent, analyticsEnabled, isBannerOpen, isModalOpen, acceptAll, acceptEssential, saveCustom, openSettings, closeSettings]
  );

  return <CookieContext.Provider value={value}>{children}</CookieContext.Provider>;
}

export function useCookieConsent() {
  const ctx = useContext(CookieContext);
  if (!ctx) {
    throw new Error('useCookieConsent must be used within a CookieProvider');
  }
  return ctx;
}
