import type { ReactNode } from 'react';
import { AlertTriangle, RotateCw, WifiOff, type LucideIcon } from 'lucide-react';
import { Button } from './Button';

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
}: {
  icon: LucideIcon;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center rounded-3xl border border-dashed border-line px-6 py-16 text-center">
      <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-white/5 text-muted">
        <Icon className="h-7 w-7" />
      </div>
      <h3 className="text-lg font-semibold">{title}</h3>
      {description && <p className="mt-1 max-w-sm text-sm text-muted">{description}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

function isNetworkError(message?: string): boolean {
  if (!message) return false;
  const m = message.toLowerCase();
  return (
    m.includes('failed to fetch') ||
    m.includes('networkerror') ||
    m.includes('err_name_not_resolved') ||
    m.includes('err_internet_disconnected') ||
    m.includes('load failed') ||
    m.includes('network request failed')
  );
}

export function ErrorState({ message, onRetry }: { message?: string; onRetry?: () => void }) {
  const networkErr = isNetworkError(message);
  return (
    <div role="alert" className="flex flex-col items-center rounded-3xl border border-red-500/25 bg-red-500/5 px-6 py-14 text-center">
      <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-red-500/10 text-red-400">
        {networkErr ? <WifiOff className="h-7 w-7" /> : <AlertTriangle className="h-7 w-7" />}
      </div>
      <h3 className="text-lg font-semibold">
        {networkErr ? 'Service temporarily unavailable' : "We couldn't load this"}
      </h3>
      <p className="mt-1 max-w-md text-sm text-muted">
        {networkErr
          ? 'Our servers are temporarily unreachable. Please try again in a few minutes.'
          : (message ?? 'Check your connection and try again.')}
      </p>
      {onRetry && (
        <Button variant="outline" className="mt-5" leftIcon={<RotateCw className="h-4 w-4" />} onClick={onRetry}>
          Try again
        </Button>
      )}
    </div>
  );
}
