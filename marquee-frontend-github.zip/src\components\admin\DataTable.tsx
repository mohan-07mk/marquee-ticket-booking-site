import { useEffect, useState, type ReactNode } from 'react';
import { ChevronLeft, ChevronRight, SearchX } from 'lucide-react';
import { cn } from '@/utils/cn';
import { Button } from '../ui/Button';
import { Skeleton } from '../ui/Skeleton';
import { EmptyState } from '../ui/States';

export interface Column<T> {
  key: string;
  header: string;
  cell: (row: T) => ReactNode;
  className?: string;
  /** Mobile card: 'title' renders large at the top, 'actions' renders at the bottom, 'hide' omits it. */
  mobile?: 'title' | 'actions' | 'hide';
}

interface DataTableProps<T> {
  columns: Column<T>[];
  rows: T[];
  rowKey: (row: T) => string;
  loading?: boolean;
  pageSize?: number;
  emptyTitle?: string;
  emptyDescription?: string;
}

/**
 * Generic, responsive table. Renders a real <table> from md upwards and stacked cards on phones.
 * Filtering/searching is done by the page; this component only paginates.
 */
export function DataTable<T>({
  columns,
  rows,
  rowKey,
  loading,
  pageSize = 8,
  emptyTitle = 'Nothing here yet',
  emptyDescription = 'Try changing your search or filters.',
}: DataTableProps<T>) {
  const [page, setPage] = useState(1);
  const pages = Math.max(1, Math.ceil(rows.length / pageSize));

  useEffect(() => {
    if (page > pages) setPage(pages);
  }, [page, pages]);
  useEffect(() => setPage(1), [rows.length]);

  const slice = rows.slice((page - 1) * pageSize, page * pageSize);
  const title = columns.find((c) => c.mobile === 'title') ?? columns[0];
  const actions = columns.find((c) => c.mobile === 'actions');
  const details = columns.filter((c) => c !== title && c !== actions && c.mobile !== 'hide');

  if (loading) {
    return (
      <div className="space-y-3 rounded-3xl border border-line bg-surface p-4">
        {Array.from({ length: 6 }, (_, i) => (
          <Skeleton key={i} className="h-14 w-full" />
        ))}
      </div>
    );
  }

  if (!rows.length) {
    return <EmptyState icon={SearchX} title={emptyTitle} description={emptyDescription} />;
  }

  return (
    <div className="overflow-hidden rounded-3xl border border-line bg-surface">
      {/* Desktop table */}
      <div className="hidden overflow-x-auto md:block">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead>
            <tr className="border-b border-line bg-black/40 text-xs text-muted">
              {columns.map((c) => (
                <th key={c.key} scope="col" className={cn('whitespace-nowrap px-4 py-3.5 font-medium', c.className)}>
                  {c.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-line">
            {slice.map((row) => (
              <tr key={rowKey(row)} className="transition hover:bg-white/[0.03]">
                {columns.map((c) => (
                  <td key={c.key} className={cn('px-4 py-3 align-middle', c.className)}>
                    {c.cell(row)}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Mobile cards */}
      <ul className="divide-y divide-line md:hidden">
        {slice.map((row) => (
          <li key={rowKey(row)} className="space-y-3 p-4">
            <div className="font-medium">{title.cell(row)}</div>
            <dl className="space-y-1.5 text-sm">
              {details.map((c) => (
                <div key={c.key} className="flex items-start justify-between gap-4">
                  <dt className="text-muted">{c.header}</dt>
                  <dd className="text-right">{c.cell(row)}</dd>
                </div>
              ))}
            </dl>
            {actions && <div className="flex justify-end gap-1 pt-1">{actions.cell(row)}</div>}
          </li>
        ))}
      </ul>

      {/* Pagination */}
      <div className="flex items-center justify-between gap-3 border-t border-line px-4 py-3 text-sm text-muted">
        <p>
          Showing {(page - 1) * pageSize + 1} to {Math.min(page * pageSize, rows.length)} of {rows.length}
        </p>
        <div className="flex items-center gap-1.5">
          <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage((p) => p - 1)} aria-label="Previous page">
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <span className="min-w-[64px] text-center text-white/80">
            {page} / {pages}
          </span>
          <Button variant="outline" size="sm" disabled={page === pages} onClick={() => setPage((p) => p + 1)} aria-label="Next page">
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
