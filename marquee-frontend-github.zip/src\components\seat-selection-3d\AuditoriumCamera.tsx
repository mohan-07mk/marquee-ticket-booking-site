import { forwardRef, useEffect, useImperativeHandle, useRef, type ElementRef } from 'react';
import { OrbitControls } from '@react-three/drei';
import { useFrame, useThree } from '@react-three/fiber';
import gsap from 'gsap';
import { MOUSE, TOUCH, Vector3, type PerspectiveCamera } from 'three';
import { EYE_HEIGHT, type AuditoriumLayout } from './seatLayout';

export type ViewName = 'rear' | 'front' | 'left' | 'right' | 'top' | 'screen';

export interface AuditoriumCameraApi {
  setView: (view: ViewName) => void;
  rotate: (direction: 'left' | 'right') => void;
  zoom: (direction: 'in' | 'out') => void;
  reset: () => void;
  /** Move the camera to a seat's eye position, looking at the screen. */
  seatView: (seatId: string) => void;
  setPanMode: (pan: boolean) => void;
}

interface Props {
  layout: AuditoriumLayout;
  reducedMotion: boolean;
  /** Called when the user starts orbiting, so the UI can leave seat view / screen focus. */
  onUserMove?: () => void;
}

interface Pose {
  position: Vector3;
  target: Vector3;
  fov: number;
}

const MIN_DISTANCE = 3;
const SEAT_MIN_DISTANCE = 0.25;

export const AuditoriumCamera = forwardRef<AuditoriumCameraApi, Props>(function AuditoriumCamera({ layout, reducedMotion, onUserMove }, ref) {
  const controls = useRef<ElementRef<typeof OrbitControls>>(null);
  const camera = useThree((s) => s.camera) as PerspectiveCamera;
  const size = useThree((s) => s.size);
  const tween = useRef<gsap.core.Timeline | null>(null);
  const moving = useRef(false);
  const inSeatView = useRef(false);

  const { width, length, height, center } = layout;
  const maxDistance = Math.max(length, width) * 2.4;

  // Wider field of view on narrow (portrait) screens so the whole hall fits.
  const baseFov = size.width / size.height < 0.8 ? 58 : size.width / size.height < 1.2 ? 48 : 38;

  const poses = useRef<Record<Exclude<ViewName, 'screen'>, Pose>>({} as never);
  poses.current = {
    rear: { position: new Vector3(0, height * 0.95, length + 6.5), target: new Vector3(0, 2.6, center.z - 1), fov: baseFov },
    front: { position: new Vector3(0, height + 2.5, -9), target: new Vector3(0, 1.4, center.z), fov: baseFov },
    left: { position: new Vector3(-(width / 2 + length * 0.95), height * 0.55, center.z), target: new Vector3(0, 2.2, center.z), fov: baseFov },
    right: { position: new Vector3(width / 2 + length * 0.95, height * 0.55, center.z), target: new Vector3(0, 2.2, center.z), fov: baseFov },
    top: { position: new Vector3(0, length * 1.05 + 6, center.z + 0.01), target: new Vector3(0, 0, center.z), fov: baseFov },
  };

  const flyTo = (pose: Pose, seat = false, lowAngle = seat) => {
    const c = controls.current;
    if (!c) return;
    tween.current?.kill();
    inSeatView.current = seat;
    c.minDistance = seat ? SEAT_MIN_DISTANCE : MIN_DISTANCE;
    // Eye-level views look up at the screen, so allow polar angles below the horizon.
    c.maxPolarAngle = lowAngle ? Math.PI * 0.92 : Math.PI * 0.495;
    const duration = reducedMotion ? 0 : 1.25;
    moving.current = true;
    const tl = gsap.timeline({
      defaults: { duration, ease: 'power3.inOut' },
      onUpdate: () => {
        c.update();
        camera.updateProjectionMatrix();
      },
      onComplete: () => {
        moving.current = false;
      },
    });
    tl.to(camera.position, { x: pose.position.x, y: pose.position.y, z: pose.position.z }, 0)
      .to(c.target, { x: pose.target.x, y: pose.target.y, z: pose.target.z }, 0)
      .to(camera, { fov: pose.fov }, 0);
    tween.current = tl;
  };

  useImperativeHandle(
    ref,
    () => ({
      setView: (view) => {
        if (view === 'screen') {
          const row = layout.rows[Math.floor(layout.rows.length * 0.55)] ?? layout.rows[0];
          flyTo({
            position: new Vector3(0, (row?.y ?? 1) + EYE_HEIGHT + 0.2, (row?.z ?? center.z) + 1.5),
            target: new Vector3(0, layout.screen.centerY, layout.screen.z),
            fov: 50,
          }, false, true);
          return;
        }
        flyTo(poses.current[view]);
      },
      reset: () => flyTo(poses.current.rear),
      rotate: (direction) => {
        const c = controls.current;
        if (!c) return;
        tween.current?.kill();
        const offset = camera.position.clone().sub(c.target);
        const state = { angle: 0 };
        const to = (direction === 'left' ? 1 : -1) * (Math.PI / 5);
        moving.current = true;
        tween.current = gsap.timeline({ onComplete: () => (moving.current = false) }).to(state, {
          angle: to,
          duration: reducedMotion ? 0 : 0.7,
          ease: 'power2.inOut',
          onUpdate: () => {
            camera.position.copy(c.target).add(offset.clone().applyAxisAngle(new Vector3(0, 1, 0), state.angle));
            c.update();
          },
        });
      },
      zoom: (direction) => {
        const c = controls.current;
        if (!c) return;
        tween.current?.kill();
        const offset = camera.position.clone().sub(c.target);
        const next = Math.min(c.maxDistance, Math.max(c.minDistance, offset.length() * (direction === 'in' ? 0.72 : 1.35)));
        const end = offset.clone().setLength(next);
        moving.current = true;
        tween.current = gsap.timeline({ onComplete: () => (moving.current = false) }).to(camera.position, {
          x: c.target.x + end.x,
          y: c.target.y + end.y,
          z: c.target.z + end.z,
          duration: reducedMotion ? 0 : 0.45,
          ease: 'power2.out',
          onUpdate: () => c.update(),
        });
      },
      seatView: (seatId) => {
        const p = layout.byId.get(seatId);
        if (!p) return;
        const eye = new Vector3(p.x, p.y + EYE_HEIGHT + (p.seat.type === 'premium' ? 0.15 : 0), p.z + 0.05);
        const forward = new Vector3(0, layout.screen.centerY - eye.y, layout.screen.z - eye.z).normalize();
        flyTo({ position: eye, target: eye.clone().addScaledVector(forward, 0.6), fov: 62 }, true);
      },
      setPanMode: (pan) => {
        const c = controls.current;
        if (!c) return;
        c.mouseButtons.LEFT = pan ? MOUSE.PAN : MOUSE.ROTATE;
        c.touches.ONE = pan ? TOUCH.PAN : TOUCH.ROTATE;
      },
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [layout, reducedMotion, baseFov],
  );

  // Initial pose and re-fit when the layout or screen shape changes.
  useEffect(() => {
    const c = controls.current;
    if (!c || inSeatView.current) return;
    const pose = poses.current.rear;
    camera.position.copy(pose.position);
    c.target.copy(pose.target);
    camera.fov = pose.fov;
    camera.updateProjectionMatrix();
    c.update();
  }, [layout, camera, baseFov]);

  useEffect(() => () => void tween.current?.kill(), []);

  // Keep panning inside the hall so the audience never loses the auditorium.
  useFrame(() => {
    const c = controls.current;
    if (!c) return;
    const t = c.target;
    t.x = Math.min(width, Math.max(-width, t.x));
    t.y = Math.min(height, Math.max(0, t.y));
    t.z = Math.min(length + 4, Math.max(-3, t.z));
  });

  return (
    <OrbitControls
      ref={controls}
      makeDefault
      enableDamping
      dampingFactor={0.08}
      rotateSpeed={0.7}
      zoomSpeed={0.8}
      panSpeed={0.8}
      minDistance={MIN_DISTANCE}
      maxDistance={maxDistance}
      maxPolarAngle={Math.PI * 0.495}
      screenSpacePanning
      onStart={() => {
        tween.current?.kill();
        moving.current = false;
        onUserMove?.();
      }}
    />
  );
});
