const items = [
  { key: 'available', label: 'Available' },
  { key: 'selected', label: 'Selected' },
  { key: 'booked', label: 'Booked' },
  { key: 'premium', label: 'Premium recliner' },
  { key: 'unavailable', label: 'Unavailable' },
] as const;

/** Seat legend for the 3D auditorium. Swatches match the seat colours in the scene. */
export function SeatLegend() {
  return (
    <ul className="flex flex-wrap items-center justify-center gap-x-5 gap-y-2 text-sm text-white/75" aria-label="Seat legend">
      {items.map((i) => (
        <li key={i.key} className="flex items-center gap-2">
          <span className={`mq3d-swatch mq3d-swatch--${i.key}`} aria-hidden="true" />
          {i.label}
        </li>
      ))}
    </ul>
  );
}
