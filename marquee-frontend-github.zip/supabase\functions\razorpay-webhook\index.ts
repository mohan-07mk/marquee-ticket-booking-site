// supabase/functions/razorpay-webhook/index.ts
import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-razorpay-signature',
};

async function verifyWebhookSignature(bodyText: string, signature: string, secret: string): Promise<boolean> {
  const encoder = new TextEncoder();
  const keyData = encoder.encode(secret);
  const key = await crypto.subtle.importKey('raw', keyData, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const data = encoder.encode(bodyText);
  const signatureBuffer = await crypto.subtle.sign('HMAC', key, data);
  const hashArray = Array.from(new Uint8Array(signatureBuffer));
  const hexSignature = hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
  return hexSignature === signature;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const RAZORPAY_WEBHOOK_SECRET = Deno.env.get('RAZORPAY_WEBHOOK_SECRET');
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    const signature = req.headers.get('x-razorpay-signature');
    const bodyText = await req.text();

    // 1. Verify Webhook Signature if secret is configured
    if (RAZORPAY_WEBHOOK_SECRET && signature) {
      const isValid = await verifyWebhookSignature(bodyText, signature, RAZORPAY_WEBHOOK_SECRET);
      if (!isValid) {
        return new Response(
          JSON.stringify({ error: 'Invalid Razorpay Webhook Signature.' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
    }

    const payload = JSON.parse(bodyText);
    const event = payload.event;
    const entity = payload.payload?.payment?.entity || payload.payload?.order?.entity;

    if (!entity) {
      return new Response(
        JSON.stringify({ message: 'Event ignored: no payment or order entity found.' }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseAdmin = createClient(
      SUPABASE_URL || '',
      SUPABASE_SERVICE_ROLE_KEY || '',
      { auth: { persistSession: false } }
    );

    const paymentId = entity.id;
    const orderId = entity.order_id || entity.id;

    // 2. Idempotency Check: if payment is already recorded with current state, skip processing
    const { data: existingPayment } = await supabaseAdmin
      .from('payments')
      .select('*')
      .eq('id', paymentId)
      .maybeSingle();

    if (event === 'payment.captured' || event === 'order.paid') {
      if (existingPayment && existingPayment.status === 'paid') {
        return new Response(
          JSON.stringify({ status: 'already_processed', message: 'Payment capture already handled.' }),
          { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Check if booking already exists for this order
      const { data: existingBooking } = await supabaseAdmin
        .from('bookings')
        .select('*')
        .eq('razorpay_order_id', orderId)
        .maybeSingle();

      if (!existingBooking) {
        // Look up order metadata from razorpay_orders
        const { data: orderMeta } = await supabaseAdmin
          .from('razorpay_orders')
          .select('*')
          .eq('id', orderId)
          .maybeSingle();

        if (orderMeta) {
          // Check seat availability before creating booking via webhook
          const { data: takenSeats } = await supabaseAdmin
            .from('booking_seats')
            .select('seat_id')
            .eq('show_id', orderMeta.show_id)
            .in('seat_id', orderMeta.seat_ids);

          if (!takenSeats || takenSeats.length === 0) {
            // Retrieve show details
            const { data: show } = await supabaseAdmin.from('shows').select('*').eq('id', orderMeta.show_id).single();
            const { data: movie } = await supabaseAdmin.from('movies').select('*').eq('id', show?.movie_id).single();
            const { data: theatre } = await supabaseAdmin.from('theatres').select('*').eq('id', show?.theatre_id).single();
            const { data: screen } = await supabaseAdmin.from('screens').select('*').eq('id', show?.screen_id).single();
            const { data: dbSeats } = await supabaseAdmin.from('seats').select('*').eq('screen_id', show?.screen_id);

            const seatMap = new Map<string, any>();
            if (dbSeats) {
              for (const s of dbSeats) {
                seatMap.set(s.id, s);
              }
            }

            const seatLabels = (orderMeta.seat_ids || []).map((id: string) => {
              const s = seatMap.get(id);
              return s ? `${s.row_label || s.row_name}${s.seat_number}` : id;
            });

            const bookingRef = crypto.randomUUID();
            const subtotal = orderMeta.subtotal || orderMeta.amount - (orderMeta.seat_ids.length * 30);
            const convenienceFee = orderMeta.convenience_fee || orderMeta.seat_ids.length * 30;

            // Create booking row with UUID id
            await supabaseAdmin.from('bookings').insert({
              id: bookingRef,
              user_id: orderMeta.user_id,
              customer_name: orderMeta.customer_name || 'Guest',
              movie_id: movie?.id || show?.movie_id,
              movie_title: movie?.title || 'Movie',
              poster_url: movie?.poster_url || '',
              theatre_id: theatre?.id || show?.theatre_id,
              theatre_name: theatre?.name || 'Theatre',
              screen_name: screen?.name || 'Screen 1',
              show_id: orderMeta.show_id,
              date: show?.show_date || show?.date,
              time: show?.show_time || show?.time,
              format: show?.format || '2D',
              seats: seatLabels,
              subtotal,
              convenience_fee: convenienceFee,
              total_amount: orderMeta.amount,
              status: 'confirmed',
              payment_method: entity.method || 'razorpay',
              razorpay_order_id: orderId,
              razorpay_payment_id: paymentId,
              payment_status: 'paid',
            });

            // Insert booking_seats
            const bsInserts = orderMeta.seat_ids.map((seatId: string) => ({
              booking_id: bookingRef,
              show_id: orderMeta.show_id,
              seat_id: seatId,
              price: Math.round(subtotal / orderMeta.seat_ids.length),
            }));
            await supabaseAdmin.from('booking_seats').insert(bsInserts);

            // Trigger email
            if (orderMeta.customer_email) {
              try {
                await fetch(`${SUPABASE_URL}/functions/v1/send-booking-email`, {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
                  },
                  body: JSON.stringify({ bookingId: bookingRef, userEmail: orderMeta.customer_email }),
                });
              } catch (e) {
                console.warn('Webhook email trigger failed:', e);
              }
            }
          }
        }
      }

      // Record payment capture
      await supabaseAdmin.from('payments').upsert({
        id: paymentId,
        amount: (entity.amount || 0) / 100,
        status: 'paid',
        payment_method: entity.method || 'razorpay',
        razorpay_order_id: orderId,
        razorpay_payment_id: paymentId,
      });

      return new Response(
        JSON.stringify({ status: 'success', event }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    } else if (event === 'payment.failed') {
      await supabaseAdmin.from('payments').upsert({
        id: paymentId,
        amount: (entity.amount || 0) / 100,
        status: 'failed',
        payment_method: entity.method || 'razorpay',
        razorpay_order_id: orderId,
        razorpay_payment_id: paymentId,
        error_message: entity.error_description || 'Razorpay payment failed',
      });

      try {
        await supabaseAdmin.from('razorpay_orders').update({ status: 'failed' }).eq('id', orderId);
      } catch {
        /* ignore */
      }

      return new Response(
        JSON.stringify({ status: 'failure_recorded', event }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ status: 'ignored', event }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (err: any) {
    console.error('Unhandled error in razorpay-webhook:', err);
    return new Response(
      JSON.stringify({ error: err.message || 'Webhook internal error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
