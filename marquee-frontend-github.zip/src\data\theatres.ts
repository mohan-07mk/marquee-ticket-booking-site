import type { Format, Screen, Theatre } from '@/types';

/**
 * MOCK DATA - theatres + screens.
 * Replace with: supabase.from('theatres').select('*, screens(*)')
 */
export const SEATS_PER_ROW = 14;

export function makeScreens(theatreId: string, count: number, capacity: number, formatsFor?: (i: number) => Format[]): Screen[] {
  const rows = Math.max(5, Math.ceil(capacity / SEATS_PER_ROW));
  return Array.from({ length: count }, (_, i) => ({
    id: `${theatreId}-s${i + 1}`,
    theatreId,
    name: `Screen ${i + 1}`,
    rows,
    seatsPerRow: SEATS_PER_ROW,
    capacity: rows * SEATS_PER_ROW,
    formats: formatsFor ? formatsFor(i) : ['2D', '3D'],
  }));
}

const screen = (theatreId: string, n: number, rows: number, formats: Format[]): Screen => ({
  id: `${theatreId}-s${n}`,
  theatreId,
  name: `Screen ${n}`,
  rows,
  seatsPerRow: SEATS_PER_ROW,
  capacity: rows * SEATS_PER_ROW,
  formats,
});

export const theatres: Theatre[] = [
  {
    id: 't1',
    name: 'Aurora Cinemas',
    location: 'Grand Mall, Central Avenue',
    amenities: ['Dolby Atmos', 'Recliners', 'Food court', 'Parking'],
    status: 'active',
    screens: [
      screen('t1', 1, 12, ['IMAX', '2D']),
      screen('t1', 2, 10, ['3D', '2D']),
      screen('t1', 3, 9, ['2D']),
    ],
  },
  {
    id: 't2',
    name: 'Regal Screens Prime',
    location: 'Lakeview Plaza, Lake Road',
    amenities: ['Dolby Atmos', 'Wheelchair access', 'Parking'],
    status: 'active',
    screens: [
      screen('t2', 1, 10, ['3D', '2D']),
      screen('t2', 2, 9, ['2D']),
      screen('t2', 3, 9, ['2D']),
      screen('t2', 4, 10, ['3D', '2D']),
    ],
  },
  {
    id: 't3',
    name: 'Starlight Multiplex',
    location: 'Riverside Walk, Bridge Street',
    amenities: ['4K laser', 'Snack bar', 'Metro nearby'],
    status: 'active',
    screens: [screen('t3', 1, 10, ['2D', '3D']), screen('t3', 2, 8, ['2D']), screen('t3', 3, 8, ['2D'])],
  },
  {
    id: 't4',
    name: 'Cine Palace',
    location: 'Old Market Road',
    amenities: ['Single-screen classic', 'Balcony seating', 'Parking'],
    status: 'active',
    screens: [screen('t4', 1, 11, ['2D']), screen('t4', 2, 9, ['2D'])],
  },
  {
    id: 't5',
    name: 'Metro Max IMAX',
    location: 'Tech Park Road, Phase 2',
    amenities: ['IMAX with laser', 'Dolby Atmos', 'Recliners', 'Valet parking'],
    status: 'active',
    screens: [screen('t5', 1, 13, ['IMAX', '3D', '2D']), screen('t5', 2, 10, ['2D', '3D'])],
  },
  {
    id: 't6',
    name: 'Sunrise Cinemas',
    location: 'Green Valley Mall',
    amenities: ['Family lounge', 'Parking'],
    status: 'inactive',
    screens: [screen('t6', 1, 9, ['2D'])],
  },
];
