import { Component, lazy, Suspense, useEffect, useState, type ErrorInfo, type ReactNode } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { Box, ChevronLeft, CreditCard, Film, Layers } from 'lucide-react';

class View3DErrorBoundary extends Component<
  { onFallback: () => void; children: ReactNode },
  { hasError: boolean; error?: Error }
> {
  override state: { hasError: boolean; error?: Error } = { hasError: false };
  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }
  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('[SeatSelection3D Error]:', error, errorInfo);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="rounded-2xl border border-line bg-surface/50 p-8 text-center">
          <p className="text-base font-semibold text-white">3D Cinema view could not load on this device</p>
          <p className="mt-2 text-xs text-muted">
            {this.state.error?.message || 'WebGL or graphics context may not be supported.'}
          </p>
          <button
            type="button"
            className="mt-4 inline-flex items-center gap-2 rounded-xl bg-brand px-4 py-2 text-sm font-semibold text-white transition hover:bg-brand/90"
            onClick={this.props.onFallback}
          >
            Switch to 2D Map
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
import { BookingSummary } from '@/components/BookingSummary';
import { SeatLegend, SeatMap } from '@/components/SeatMap';
import { Button, buttonClasses } from '@/components/ui/Button';
import { Skeleton } from '@/components/ui/Skeleton';
import { EmptyState, ErrorState } from '@/components/ui/States';
import { useBooking } from '@/context/BookingContext';
import { useToast } from '@/context/ToastContext';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { api } from '@/services/api';
import type { Seat } from '@/types';
import { cn } from '@/utils/cn';
import { formatCurrency, formatLongDate, formatTime, hasShowStarted } from '@/utils/format';
import { calcTotals, MAX_SEATS_PER_BOOKING } from '@/utils/pricing';

const SeatSelection3D = lazy(() => import('@/components/seat-selection-3d/SeatSelection3D'));

export default function SeatSelection() {
  useDocumentTitle('Select seats');
  const [params] = useSearchParams();
  const showId = params.get('showId') ?? '';
  const navigate = useNavigate();
  const toast = useToast();
  const { draft, setDraft } = useBooking();
  const [selected, setSelected] = useState<Seat[]>([]);
  const [viewMode, setViewMode] = useState<'2d' | '3d'>('2d');

  const { data, loading, error, reload } = useAsync(async () => {
    const [details, layout] = await Promise.all([api.shows.getDetails(showId), api.seats.getLayout(showId)]);
    return { details, layout };
  }, [showId]);

  // Restore an in-progress selection (e.g. coming back from checkout), dropping seats taken since.
  useEffect(() => {
    if (!data || draft.showId !== showId) return;
    const stillFree = draft.seats.filter((s) => data.layout.find((l) => l.id === s.id)?.status === 'available');
    setSelected(stillFree);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data]);

  if (!showId || error) {
    return (
      <div className="container-page py-16">
        {error ? (
          <ErrorState message={error} onRetry={reload} />
        ) : (
          <EmptyState
            icon={Film}
            title="Pick a show first"
            description="Choose a movie, theatre and time to see the seat map."
            action={
              <Link to="/booking" className={buttonClasses()}>
                Choose a movie
              </Link>
            }
          />
        )}
      </div>
    );
  }

  if (loading || !data) {
    return (
      <div className="container-page grid gap-8 py-10 lg:grid-cols-[1fr_380px]">
        <Skeleton className="h-[560px]" />
        <Skeleton className="h-[560px]" />
      </div>
    );
  }

  const { details, layout } = data;
  const started = hasShowStarted(details.show.date, details.show.time);
  const selectedIds = selected.map((s) => s.id);
  const { total } = calcTotals(selected);

  const toggle = (seat: Seat) => {
    setSelected((prev) => {
      if (prev.some((s) => s.id === seat.id)) return prev.filter((s) => s.id !== seat.id);
      if (prev.length >= MAX_SEATS_PER_BOOKING) {
        toast.error(`You can book up to ${MAX_SEATS_PER_BOOKING} seats at a time`);
        return prev;
      }
      return [...prev, seat].sort((a, b) => a.row.localeCompare(b.row) || a.number - b.number);
    });
  };

  const proceed = () => {
    setDraft({ showId, seats: selected });
    navigate('/checkout');
  };

  const cta = (
    <Button size="lg" className="w-full" disabled={!selected.length || started} onClick={proceed} leftIcon={<CreditCard className="h-5 w-5" />}>
      {selected.length ? `Proceed to Payment, ${formatCurrency(total)}` : 'Select seats to continue'}
    </Button>
  );

  return (
    <div className="container-page py-8 pb-32 sm:py-12 lg:pb-12">
      <Link to={`/booking?movieId=${details.movie.id}&date=${details.show.date}`} className="mb-5 inline-flex items-center gap-1 text-sm text-muted transition hover:text-white">
        <ChevronLeft className="h-4 w-4" />
        Change showtime
      </Link>

      <header className="mb-8">
        <p className="text-sm text-muted">Step 2 of 3: choose your seats</p>
        <h1 className="mt-1 font-display text-4xl font-extrabold leading-none sm:text-6xl">{details.movie.title}</h1>
        <p className="mt-3 text-white/70">
          {details.theatre.name}, {details.screen.name}. {formatLongDate(details.show.date)} at {formatTime(details.show.time)}
        </p>
      </header>

      {started && (
        <div role="alert" className="mb-6 rounded-2xl border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-sm text-amber-200">
          This show has already started, so seats can’t be booked. Please pick another showtime.
        </div>
      )}

      <div className="grid items-start gap-8 lg:grid-cols-[1fr_380px]">
        <section className="rounded-3xl border border-line bg-surface p-4 sm:p-8" aria-label="Seat map">
          <div className="mb-6 flex items-center justify-between border-b border-line/60 pb-4">
            <div>
              <h2 className="text-sm font-semibold uppercase tracking-wider text-muted">Auditorium View</h2>
              <p className="text-xs text-white/50">Toggle between classic 2D map and interactive 3D hall</p>
            </div>
            <div className="inline-flex rounded-xl bg-black/40 p-1 border border-line">
              <button
                type="button"
                onClick={() => setViewMode('2d')}
                className={cn(
                  'flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition',
                  viewMode === '2d' ? 'bg-brand text-white shadow-sm' : 'text-muted hover:text-white',
                )}
              >
                <Layers className="h-3.5 w-3.5" />
                2D Map
              </button>
              <button
                type="button"
                onClick={() => setViewMode('3d')}
                className={cn(
                  'flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition',
                  viewMode === '3d' ? 'bg-brand text-white shadow-sm' : 'text-muted hover:text-white',
                )}
              >
                <Box className="h-3.5 w-3.5" />
                3D Cinema
              </button>
            </div>
          </div>

          {viewMode === '2d' ? (
            <>
              <SeatMap seats={layout} screen={details.screen} selectedIds={selectedIds} onToggle={toggle} />
              <div className="mt-8 border-t border-line pt-6">
                <SeatLegend />
              </div>
            </>
          ) : (
            <View3DErrorBoundary onFallback={() => setViewMode('2d')}>
              <Suspense fallback={<Skeleton className="h-[460px] w-full rounded-2xl" />}>
                <SeatSelection3D
                  seats={layout}
                  screen={details.screen}
                  selectedIds={selectedIds}
                  onToggle={toggle}
                  started={started}
                  movieTitle={details.movie.title}
                  screenSubtitle={`${details.theatre.name}, ${details.screen.name}`}
                  theatreId={details.theatre.id}
                  theatreScreenViewLink={details.theatre.screenViewLink}
                  movieTrailerUrl={details.movie.trailerUrl}
                />
              </Suspense>
            </View3DErrorBoundary>
          )}
        </section>

        <div className="lg:sticky lg:top-24">
          <BookingSummary details={details} seats={selected} cta={cta} />
        </div>
      </div>

      {/* Mobile sticky bar */}
      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-black/90 p-4 backdrop-blur-xl lg:hidden">
        <div className="mx-auto flex max-w-xl items-center justify-between gap-4">
          <div>
            <p className="text-xs text-muted">{selected.length ? `${selected.length} seat${selected.length > 1 ? 's' : ''}` : 'No seats yet'}</p>
            <p className="font-display text-3xl font-extrabold leading-none">{formatCurrency(total)}</p>
          </div>
          <Button size="lg" disabled={!selected.length || started} onClick={proceed}>
            Pay now
          </Button>
        </div>
      </div>
    </div>
  );
}
