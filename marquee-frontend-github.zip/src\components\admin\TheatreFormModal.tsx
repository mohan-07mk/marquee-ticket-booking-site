import { useState, type FormEvent } from 'react';
import type { ActiveStatus, Theatre } from '@/types';
import { useCinemaScreen } from '@/context/CinemaScreenContext';
import { useToast } from '@/context/ToastContext';
import { api } from '@/services/api';
import { parseYouTubeUrl } from '@/utils/youtube';
import { Button } from '../ui/Button';
import { Field, Input, Select } from '../ui/Field';
import { Modal } from '../ui/Modal';

interface Props {
  open: boolean;
  theatre: Theatre | null;
  onClose: () => void;
  onSaved: () => void;
}

export function TheatreFormModal({ open, theatre, onClose, onSaved }: Props) {
  if (!open) return null;
  return <Inner key={theatre?.id ?? 'new'} theatre={theatre} onClose={onClose} onSaved={onSaved} />;
}

function Inner({ theatre, onClose, onSaved }: Omit<Props, 'open'>) {
  const toast = useToast();
  const { saveVideoUrl } = useCinemaScreen();
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [f, setF] = useState({
    name: theatre?.name ?? '',
    location: theatre?.location ?? '',
    status: (theatre?.status ?? 'active') as ActiveStatus,
    screenCount: String(theatre?.screens.length ?? 2),
    capacity: String(theatre?.screens[0]?.capacity ?? 140),
    screenViewLink: theatre?.screenViewLink ?? '',
  });

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const next: Record<string, string> = {};
    if (!f.name.trim()) next.name = 'Enter the theatre name.';
    if (!f.location.trim()) next.location = 'Enter the location.';
    const screens = Number(f.screenCount);
    const capacity = Number(f.capacity);
    if (!Number.isInteger(screens) || screens < 1 || screens > 12) next.screenCount = 'Use 1 to 12 screens.';
    if (!Number.isInteger(capacity) || capacity < 70 || capacity > 300) next.capacity = 'Use 70 to 300 seats per screen.';
    if (f.screenViewLink.trim() && !parseYouTubeUrl(f.screenViewLink.trim())) {
      next.screenViewLink = 'Please enter a valid YouTube link (e.g. https://www.youtube.com/watch?v=...).';
    }
    setErrors(next);
    if (Object.keys(next).length) return;

    setSaving(true);
    try {
      const input = {
        name: f.name.trim(),
        location: f.location.trim(),
        status: f.status,
        screenCount: screens,
        capacityPerScreen: capacity,
        screenViewLink: f.screenViewLink.trim(),
      };
      if (input.screenViewLink) {
        saveVideoUrl(input.screenViewLink);
      }
      if (theatre) await api.theatres.update(theatre.id, input);
      else await api.theatres.create(input);
      toast.success(theatre ? 'Theatre updated' : 'Theatre added', input.name);
      onSaved();
      onClose();
    } catch (err) {
      toast.error('Couldn’t save the theatre', err instanceof Error ? err.message : undefined);
      setSaving(false);
    }
  };

  return (
    <Modal
      open
      onClose={saving ? () => undefined : onClose}
      title={theatre ? 'Edit theatre' : 'Add theatre'}
      description="Seat capacity is rounded up to full rows of 14."
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={saving}>
            Cancel
          </Button>
          <Button type="submit" form="theatre-form" loading={saving}>
            {theatre ? 'Save changes' : 'Add theatre'}
          </Button>
        </>
      }
    >
      <form id="theatre-form" onSubmit={submit} noValidate className="grid gap-5 sm:grid-cols-2">
        <Field label="Theatre name" htmlFor="t-name" error={errors.name} className="sm:col-span-2">
          <Input id="t-name" value={f.name} invalid={!!errors.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        </Field>
        <Field label="Location" htmlFor="t-loc" error={errors.location} className="sm:col-span-2">
          <Input id="t-loc" value={f.location} invalid={!!errors.location} onChange={(e) => setF({ ...f, location: e.target.value })} />
        </Field>
        <Field label="Number of screens" htmlFor="t-screens" error={errors.screenCount}>
          <Input id="t-screens" type="number" min={1} max={12} value={f.screenCount} invalid={!!errors.screenCount} onChange={(e) => setF({ ...f, screenCount: e.target.value })} />
        </Field>
        <Field label="Seats per screen" htmlFor="t-cap" error={errors.capacity}>
          <Input id="t-cap" type="number" min={70} max={300} value={f.capacity} invalid={!!errors.capacity} onChange={(e) => setF({ ...f, capacity: e.target.value })} />
        </Field>
        <Field
          label="Screen View Link (YouTube Link for 3D Screen)"
          htmlFor="t-screenlink"
          error={errors.screenViewLink}
          hint="Paste a YouTube URL here. This video will play on the cinema screen in the 3D auditorium."
          className="sm:col-span-2"
        >
          <Input
            id="t-screenlink"
            placeholder="https://www.youtube.com/watch?v=..."
            value={f.screenViewLink}
            invalid={!!errors.screenViewLink}
            onChange={(e) => setF({ ...f, screenViewLink: e.target.value })}
          />
        </Field>
        <Field label="Status" htmlFor="t-status" className="sm:col-span-2">
          <Select id="t-status" value={f.status} onChange={(e) => setF({ ...f, status: e.target.value as ActiveStatus })}>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </Select>
        </Field>
      </form>
    </Modal>
  );
}
