// supabase/functions/send-booking-email/index.ts
import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY');
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    const { bookingId, userEmail: reqUserEmail } = await req.json();

    if (!bookingId) {
      return new Response(
        JSON.stringify({ error: 'bookingId parameter is required.' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseAdmin = createClient(
      SUPABASE_URL || '',
      SUPABASE_SERVICE_ROLE_KEY || '',
      { auth: { persistSession: false } }
    );

    // Fetch booking details from DB
    const { data: booking, error: bookingErr } = await supabaseAdmin
      .from('bookings')
      .select('*')
      .eq('id', bookingId)
      .single();

    if (bookingErr || !booking) {
      return new Response(
        JSON.stringify({ error: `Booking ${bookingId} not found.` }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Determine verified recipient email
    let recipientEmail = reqUserEmail;
    if (!recipientEmail && booking.user_id) {
      try {
        const { data: userProfile } = await supabaseAdmin.auth.admin.getUserById(booking.user_id);
        recipientEmail = userProfile?.user?.email || null;
      } catch (authErr) {
        console.warn('[send-booking-email] Could not fetch user profile via admin:', authErr);
      }
    }

    if (!recipientEmail) {
      console.warn(`[send-booking-email] Recipient email could not be resolved for booking ${bookingId}`);
      return new Response(
        JSON.stringify({ error: 'Recipient email could not be resolved.' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`[send-booking-email] Preparing email for booking ${booking.id} (${booking.booking_reference}) to recipient: ${recipientEmail}`);

    // Fetch language from show/movie if needed
    let language = booking.language || 'English';
    if (!booking.language && booking.show_id) {
      const { data: show } = await supabaseAdmin.from('shows').select('language').eq('id', booking.show_id).maybeSingle();
      if (show?.language) language = show.language;
    }

    const seatsFormatted = Array.isArray(booking.seats) ? booking.seats.join(', ') : booking.seats;
    const formatCurrency = (amt: number) => `₹${Number(amt || 0).toLocaleString('en-IN')}`;

    const htmlContent = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Booking Confirmation - ${booking.movie_title}</title>
  <style>
    body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #0f172a; color: #f8fafc; margin: 0; padding: 20px; }
    .container { max-width: 600px; margin: 0 auto; background: #1e293b; border-radius: 16px; overflow: hidden; border: 1px solid #334155; }
    .header { background: linear-gradient(135deg, #e50914 0%, #b91c1c 100%); padding: 30px 20px; text-align: center; }
    .header h1 { margin: 0; font-size: 28px; color: #ffffff; text-transform: uppercase; letter-spacing: 1px; }
    .header p { margin: 5px 0 0; color: #fecdd3; font-size: 14px; }
    .body { padding: 30px 24px; }
    .badge { display: inline-block; background-color: #10b981; color: #ffffff; font-size: 12px; font-weight: bold; padding: 4px 12px; border-radius: 20px; text-transform: uppercase; margin-bottom: 20px; }
    .details-table { width: 100%; border-collapse: collapse; margin-bottom: 24px; }
    .details-table td { padding: 10px 0; border-bottom: 1px solid #334155; font-size: 14px; }
    .details-table td.label { color: #94a3b8; font-weight: 500; width: 40%; }
    .details-table td.value { color: #f8fafc; font-weight: 600; width: 60%; text-align: right; }
    .price-breakdown { background: #0f172a; padding: 16px; border-radius: 12px; margin-top: 20px; }
    .price-row { display: flex; justify-content: space-between; font-size: 14px; margin-bottom: 8px; color: #cbd5e1; }
    .price-row.total { font-size: 18px; font-weight: bold; color: #ffffff; border-top: 1px dashed #334155; padding-top: 10px; margin-top: 10px; }
    .footer { text-align: center; padding: 20px; font-size: 12px; color: #64748b; border-top: 1px solid #334155; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Marquee Cinemas</h1>
      <p>Booking Confirmed!</p>
    </div>
    <div class="body">
      <div style="text-align: center;">
        <span class="badge">Payment Status: ${booking.payment_status || 'CONFIRMED'}</span>
      </div>

      <table class="details-table">
        <tr>
          <td class="label">Booking Reference</td>
          <td class="value">${booking.booking_reference || booking.id}</td>
        </tr>
        <tr>
          <td class="label">Movie</td>
          <td class="value">${booking.movie_title}</td>
        </tr>
        <tr>
          <td class="label">Theatre</td>
          <td class="value">${booking.theatre_name}</td>
        </tr>
        <tr>
          <td class="label">Screen</td>
          <td class="value">${booking.screen_name}</td>
        </tr>
        <tr>
          <td class="label">Date & Time</td>
          <td class="value">${booking.date} at ${booking.time}</td>
        </tr>
        <tr>
          <td class="label">Language & Format</td>
          <td class="value">${language} (${booking.format})</td>
        </tr>
        <tr>
          <td class="label">Seats</td>
          <td class="value">${seatsFormatted}</td>
        </tr>
        <tr>
          <td class="label">Payment ID</td>
          <td class="value">${booking.razorpay_payment_id || 'N/A'}</td>
        </tr>
      </table>

      <div class="price-breakdown">
        <div class="price-row">
          <span>Ticket Price</span>
          <span>${formatCurrency(booking.subtotal)}</span>
        </div>
        <div class="price-row">
          <span>Convenience Fee</span>
          <span>${formatCurrency(booking.convenience_fee)}</span>
        </div>
        <div class="price-row total">
          <span>Total Amount</span>
          <span>${formatCurrency(booking.total_amount)}</span>
        </div>
      </div>
    </div>
    <div class="footer">
      <p>Thank you for booking with Marquee Cinemas!</p>
      <p>Show this email or ticket in your account at the entry gate.</p>
    </div>
  </div>
</body>
</html>
    `;

    if (!RESEND_API_KEY) {
      console.warn('[send-booking-email] RESEND_API_KEY is missing. Email skipped.');
      return new Response(
        JSON.stringify({
          success: true,
          delivered: false,
          message: 'RESEND_API_KEY is missing in Edge Function secrets.',
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Call Resend API with dynamic recipient email
    const resendRes = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: 'Marquee Cinemas <onboarding@resend.dev>',
        to: [recipientEmail],
        subject: `Booking Confirmation: ${booking.movie_title} [${booking.booking_reference || booking.id}]`,
        html: htmlContent,
      }),
    });

    const resendData = await resendRes.json();

    if (!resendRes.ok) {
      console.error('[send-booking-email] Resend API error:', resendData);
      return new Response(
        JSON.stringify({ error: 'Resend email delivery failed', details: resendData }),
        { status: 502, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({
        success: true,
        delivered: true,
        emailId: resendData.id,
        recipient: recipientEmail,
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (err: any) {
    console.error('[send-booking-email] Unhandled error:', err);
    return new Response(
      JSON.stringify({ error: err.message || 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
