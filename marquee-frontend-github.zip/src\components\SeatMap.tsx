import { Fragment, useMemo } from 'react';
import { X } from 'lucide-react';
import type { Screen, Seat } from '@/types';
import { cn } from '@/utils/cn';
import { formatCurrency } from '@/utils/format';

interface SeatMapProps {
  seats: Seat[];
  screen: Screen;
  selectedIds: string[];
  onToggle: (seat: Seat) => void;
}

export function SeatMap({ seats, screen, selectedIds, onToggle }: SeatMapProps) {
  const rows = useMemo(() => {
    const map = new Map<string, Seat[]>();
    seats.forEach((s) => map.set(s.row, [...(map.get(s.row) ?? []), s]));
    return [...map.entries()];
  }, [seats]);

  const firstPremiumRow = rows.find(([, list]) => list[0].type === 'premium')?.[0];
  const standardPrice = seats.find((s) => s.type === 'standard')?.price;
  const premiumPrice = seats.find((s) => s.type === 'premium')?.price;
  const aisleAfter = Math.floor(screen.seatsPerRow / 2);
  const selected = new Set(selectedIds);

  return (
    <div className="overflow-x-auto pb-2">
      <div className="mx-auto min-w-[340px] max-w-3xl">
        {/* Screen indicator */}
        <div className="mx-auto mb-10 w-[86%]" aria-hidden="true">
          <svg viewBox="0 0 400 34" className="w-full overflow-visible">
            <path d="M4 30 Q200 -4 396 30" fill="none" stroke="#e11d2e" strokeWidth="3.5" strokeLinecap="round" style={{ filter: 'drop-shadow(0 6px 14px rgba(225,29,46,.8))' }} />
          </svg>
          <div className="-mt-1 h-10 bg-gradient-to-b from-brand/25 to-transparent [clip-path:polygon(2%_0,98%_0,100%_100%,0_100%)]" />
          <p className="-mt-3 text-center text-xs text-muted">Screen is this way</p>
        </div>

        <div className="space-y-1.5 sm:space-y-2">
          {rows.map(([row, list]) => {
            const type = list[0].type;
            return (
              <Fragment key={row}>
                {row === rows[0][0] && standardPrice !== undefined && <ZoneLabel label="Standard" price={standardPrice} />}
                {row === firstPremiumRow && premiumPrice !== undefined && <ZoneLabel label="Premium recliners" price={premiumPrice} premium />}
                <div className="flex items-center gap-1 sm:gap-1.5" role="group" aria-label={`Row ${row}`}>
                  <span className="w-5 shrink-0 text-center text-xs font-medium text-muted">{row}</span>
                  {list.map((seat) => {
                    const isSelected = selected.has(seat.id);
                    const occupied = seat.status === 'occupied';
                    return (
                      <Fragment key={seat.id}>
                        <button
                          type="button"
                          disabled={occupied}
                          onClick={() => onToggle(seat)}
                          aria-pressed={isSelected}
                          aria-label={`Seat ${seat.id}, ${type}, ${occupied ? 'occupied' : isSelected ? 'selected' : 'available'}, ${formatCurrency(seat.price)}`}
                          title={occupied ? `${seat.id} is taken` : `${seat.id}, ${formatCurrency(seat.price)}`}
                          className={cn(
                            'relative flex aspect-square min-w-0 flex-1 items-center justify-center rounded-t-[9px] rounded-b-[4px] border text-[9px] font-semibold transition duration-150 sm:text-[11px]',
                            occupied && 'cursor-not-allowed border-transparent bg-white/[0.06] text-white/20',
                            !occupied && !isSelected && type === 'standard' && 'border-white/30 text-white/60 hover:border-white hover:bg-white/15 hover:text-white',
                            !occupied && !isSelected && type === 'premium' && 'border-gold/70 text-gold/80 hover:bg-gold/20 hover:text-gold',
                            isSelected && 'scale-105 border-brand bg-brand text-white shadow-[0_0_16px_rgba(225,29,46,.65)]',
                          )}
                        >
                          {occupied ? <X className="h-3 w-3" /> : seat.number}
                        </button>
                        {seat.number === aisleAfter && <span className="w-2.5 shrink-0 sm:w-6" aria-hidden="true" />}
                      </Fragment>
                    );
                  })}
                  <span className="w-5 shrink-0 text-center text-xs font-medium text-muted">{row}</span>
                </div>
              </Fragment>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function ZoneLabel({ label, price, premium }: { label: string; price: number; premium?: boolean }) {
  return (
    <div className={cn('flex items-center gap-3 pb-1 pt-3 text-xs', premium ? 'text-gold' : 'text-muted')}>
      <span className="h-px flex-1 bg-current opacity-25" />
      <span className="font-medium">
        {label}, {formatCurrency(price)}
      </span>
      <span className="h-px flex-1 bg-current opacity-25" />
    </div>
  );
}

export function SeatLegend() {
  const items = [
    { label: 'Available', cls: 'border-white/30' },
    { label: 'Selected', cls: 'border-brand bg-brand' },
    { label: 'Occupied', cls: 'border-transparent bg-white/[0.06]' },
    { label: 'Premium', cls: 'border-gold/70' },
  ];
  return (
    <ul className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-white/75">
      {items.map((i) => (
        <li key={i.label} className="flex items-center gap-2">
          <span className={cn('h-5 w-5 rounded-t-[7px] rounded-b-[3px] border', i.cls)} />
          {i.label}
        </li>
      ))}
    </ul>
  );
}
