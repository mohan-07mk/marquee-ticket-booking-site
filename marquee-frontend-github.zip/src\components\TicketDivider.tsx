/** Dashed tear-off line with half-circle notches. Parent card needs `relative overflow-hidden` and horizontal padding of 1.5rem (p-6). */
export function TicketDivider() {
  return (
    <div className="relative -mx-6 my-5" aria-hidden="true">
      <div className="mx-4 border-t-2 border-dashed border-line" />
      <span className="absolute -left-3 -top-3 h-6 w-6 rounded-full border border-line bg-base" />
      <span className="absolute -right-3 -top-3 h-6 w-6 rounded-full border border-line bg-base" />
    </div>
  );
}
