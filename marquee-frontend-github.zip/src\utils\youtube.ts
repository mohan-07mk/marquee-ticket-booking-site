export interface YouTubeInfo {
  id: string;
  embedUrl: string;
  thumbnailUrl: string;
  watchUrl: string;
}

/**
 * Converts YouTube watch URLs, short URLs, or embed URLs into a clean YouTube embed URL.
 * Returns null if the URL is empty or invalid.
 */
export function getYouTubeEmbedUrl(url: string | undefined | null): string | null {
  if (!url || typeof url !== 'string') return null;
  const trimmed = url.trim();
  if (!trimmed) return null;

  // Already an embed URL
  if (trimmed.includes('youtube.com/embed/')) {
    const match = trimmed.match(/youtube\.com\/embed\/([a-zA-Z0-9_-]+)/);
    return match ? `https://www.youtube.com/embed/${match[1]}?autoplay=1` : trimmed;
  }

  // watch?v= format (standard or mobile)
  if (trimmed.includes('youtube.com/watch') || trimmed.includes('m.youtube.com/watch')) {
    try {
      const parsed = new URL(trimmed);
      const v = parsed.searchParams.get('v');
      if (v) return `https://www.youtube.com/embed/${v}?autoplay=1`;
    } catch {
      const match = trimmed.match(/[?&]v=([a-zA-Z0-9_-]+)/);
      if (match) return `https://www.youtube.com/embed/${match[1]}?autoplay=1`;
    }
  }

  // youtu.be/ format
  if (trimmed.includes('youtu.be/')) {
    const match = trimmed.match(/youtu\.be\/([a-zA-Z0-9_-]+)/);
    if (match) return `https://www.youtube.com/embed/${match[1]}?autoplay=1`;
  }

  // Standard http/https URL fallback
  if (trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
    return trimmed;
  }

  return null;
}

export function parseYouTubeUrl(url: string | undefined | null): YouTubeInfo | null {
  if (!url || typeof url !== 'string') return null;
  const trimmed = url.trim();
  if (!trimmed) return null;

  let id: string | null = null;
  if (trimmed.includes('youtube.com/embed/')) {
    const m = trimmed.match(/youtube\.com\/embed\/([a-zA-Z0-9_-]+)/);
    id = m ? m[1] : null;
  } else if (trimmed.includes('youtube.com/watch') || trimmed.includes('m.youtube.com/watch')) {
    try {
      const parsed = new URL(trimmed);
      id = parsed.searchParams.get('v');
    } catch {
      const m = trimmed.match(/[?&]v=([a-zA-Z0-9_-]+)/);
      id = m ? m[1] : null;
    }
  } else if (trimmed.includes('youtube.com/shorts/')) {
    const m = trimmed.match(/youtube\.com\/shorts\/([a-zA-Z0-9_-]+)/);
    id = m ? m[1] : null;
  } else if (trimmed.includes('youtu.be/')) {
    const m = trimmed.match(/youtu\.be\/([a-zA-Z0-9_-]+)/);
    id = m ? m[1] : null;
  }

  if (!id) return null;

  return {
    id,
    embedUrl: `https://www.youtube.com/embed/${id}?autoplay=1&enablejsapi=1&mute=1&playsinline=1`,
    thumbnailUrl: `https://img.youtube.com/vi/${id}/hqdefault.jpg`,
    watchUrl: `https://www.youtube.com/watch?v=${id}`,
  };
}
