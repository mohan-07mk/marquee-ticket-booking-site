// supabase/functions/verify-razorpay-payment/index.ts
import { serve } from 'https://deno.land/std@0.177.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

function generateBookingReference(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = '';
  const randomValues = new Uint8Array(8);
  crypto.getRandomValues(randomValues);
  for (let i = 0; i < 8; i++) {
    code += chars[randomValues[i] % chars.length];
  }
  return `MQ-${code}`;
}

function getSafeDomain(email: string | null | undefined): string {
  if (!email || !email.includes('@')) return 'none';
  const parts = email.split('@');
  return `***@${parts[1]}`;
}

async function verifyHmacSignature(orderId: string, paymentId: string, signature: string, secret: string): Promise<boolean> {
  const encoder = new TextEncoder();
  const keyData = encoder.encode(secret);
  const key = await crypto.subtle.importKey('raw', keyData, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const data = encoder.encode(`${orderId}|${paymentId}`);
  const signatureBuffer = await crypto.subtle.sign('HMAC', key, data);
  const hashArray = Array.from(new Uint8Array(signatureBuffer));
  const hexSignature = hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
  return hexSignature === signature;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const RAZORPAY_KEY_ID = Deno.env.get('RAZORPAY_KEY_ID');
    const RAZORPAY_KEY_SECRET = Deno.env.get('RAZORPAY_KEY_SECRET');
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

    if (!RAZORPAY_KEY_SECRET) {
      return new Response(
        JSON.stringify({ error: 'RAZORPAY_KEY_SECRET secret is missing.' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 1. Extract Authenticated Supabase User & Resolve Auth Email Server-Side
    let user: any = null;
    let verifiedUserEmail: string | null = null;
    let isJwtResolved = false;

    const authHeader = req.headers.get('Authorization');
    const supabaseAdmin = createClient(
      SUPABASE_URL || '',
      SUPABASE_SERVICE_ROLE_KEY || '',
      { auth: { persistSession: false } }
    );

    if (authHeader) {
      const token = authHeader.replace('Bearer ', '').trim();
      const anonKey = Deno.env.get('SUPABASE_ANON_KEY') || '';
      if (token && token !== anonKey && !token.startsWith('sb_publishable_')) {
        try {
          const { data: userData, error: userErr } = await supabaseAdmin.auth.getUser(token);
          if (userData?.user) {
            user = userData.user;
            isJwtResolved = true;
            verifiedUserEmail = userData.user.email || null;
          } else if (userErr) {
            console.warn('[DIAGNOSTIC] JWT getUser error:', userErr.message);
          }
        } catch (err: any) {
          console.warn('[DIAGNOSTIC] JWT parse exception:', err.message);
        }
      }
    }

    // Double check email server-side via auth.admin.getUserById if userId exists
    if (user?.id) {
      try {
        const { data: adminUserData, error: adminErr } = await supabaseAdmin.auth.admin.getUserById(user.id);
        if (adminUserData?.user?.email) {
          verifiedUserEmail = adminUserData.user.email;
        } else if (adminErr) {
          console.warn('[DIAGNOSTIC] admin.getUserById error:', adminErr.message);
        }
      } catch (adminEx: any) {
        console.warn('[DIAGNOSTIC] admin.getUserById exception:', adminEx.message);
      }
    }

    console.log(`[DIAGNOSTIC] userId: ${user?.id || 'NULL'}, JWT resolved: ${isJwtResolved}, Auth email found: ${!!verifiedUserEmail}, domain: ${getSafeDomain(verifiedUserEmail)}`);

    // 2. Parse Body & Validate Parameters
    const body = await req.json();
    const {
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      showId,
      seatIds,
      paymentMethod = 'upi',
      customerName = 'Guest',
    } = body;

    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
      return new Response(
        JSON.stringify({ error: 'razorpay_order_id, razorpay_payment_id, and razorpay_signature are required.' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 3. Verify Server-Side HMAC SHA256 Signature
    const isValidSignature = await verifyHmacSignature(
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
      RAZORPAY_KEY_SECRET
    );

    if (!isValidSignature) {
      return new Response(
        JSON.stringify({ error: 'Payment signature verification failed. Tampered or invalid signature.' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 4. Idempotency Check: if booking already confirmed for this order, return existing booking
    const { data: existingBooking } = await supabaseAdmin
      .from('bookings')
      .select('*')
      .eq('razorpay_order_id', razorpay_order_id)
      .maybeSingle();

    if (existingBooking) {
      console.log(`[DIAGNOSTIC] Booking already confirmed: ${existingBooking.id}, reference: ${existingBooking.booking_reference}, booking.user_id: ${existingBooking.user_id}`);

      const recipientEmail = verifiedUserEmail || null;
      if (recipientEmail) {
        try {
          await fetch(`${SUPABASE_URL}/functions/v1/send-booking-email`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
            },
            body: JSON.stringify({
              bookingId: existingBooking.id,
              userEmail: recipientEmail,
            }),
          });
        } catch {
          /* ignore */
        }
      }

      return new Response(
        JSON.stringify({
          success: true,
          bookingId: existingBooking.id,
          bookingReference: existingBooking.booking_reference,
          message: 'Booking already confirmed for this order.',
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Retrieve order metadata from razorpay_orders if available
    const { data: orderMeta } = await supabaseAdmin
      .from('razorpay_orders')
      .select('*')
      .eq('id', razorpay_order_id)
      .maybeSingle();

    const finalShowId = showId || orderMeta?.show_id;
    const finalSeatIds = (seatIds && seatIds.length > 0) ? seatIds : orderMeta?.seat_ids || [];

    if (!finalShowId || !finalSeatIds || finalSeatIds.length === 0) {
      return new Response(
        JSON.stringify({ error: 'Show and seats context missing for payment verification.' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch Show details
    const { data: show, error: showErr } = await supabaseAdmin
      .from('shows')
      .select('*')
      .eq('id', finalShowId)
      .single();

    if (showErr || !show) {
      return new Response(
        JSON.stringify({ error: 'Show details not found.' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { data: movie } = await supabaseAdmin.from('movies').select('*').eq('id', show.movie_id).single();
    const { data: theatre } = await supabaseAdmin.from('theatres').select('*').eq('id', show.theatre_id).single();
    const { data: screen } = await supabaseAdmin.from('screens').select('*').eq('id', show.screen_id).single();

    // 5. Double Booking Check right before confirmation
    const { data: takenSeats } = await supabaseAdmin
      .from('booking_seats')
      .select('seat_id')
      .eq('show_id', finalShowId)
      .in('seat_id', finalSeatIds);

    if (takenSeats && takenSeats.length > 0) {
      console.warn(`[DIAGNOSTIC] Conflict: payment ${razorpay_payment_id} succeeded but seats taken.`);

      let refundSuccess = false;
      let refundDetails = null;

      try {
        const authString = btoa(`${RAZORPAY_KEY_ID}:${RAZORPAY_KEY_SECRET}`);
        const refRes = await fetch(`https://api.razorpay.com/v1/payments/${razorpay_payment_id}/refund`, {
          method: 'POST',
          headers: {
            Authorization: `Basic ${authString}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            notes: { reason: 'Seat unavailable conflict' },
          }),
        });
        if (refRes.ok) {
          refundSuccess = true;
          refundDetails = await refRes.json();
        }
      } catch (refundErr) {
        console.error('Failed to trigger automatic Razorpay refund:', refundErr);
      }

      await supabaseAdmin.from('payments').upsert({
        id: razorpay_payment_id,
        amount: orderMeta?.amount || 0,
        status: refundSuccess ? 'refunded' : 'conflict_refund_pending',
        payment_method: paymentMethod,
        razorpay_order_id,
        razorpay_payment_id,
        error_message: 'Seat already booked right before payment completion.',
      });

      return new Response(
        JSON.stringify({
          success: false,
          error: 'Unfortunately, your selected seats were booked by another user right before payment completion. ' +
            (refundSuccess ? 'An automatic refund has been initiated to your payment method.' : 'Our team will process your refund shortly.'),
          refunded: refundSuccess,
          refundDetails,
        }),
        { status: 409, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 6. Map screen seats to compute pricing and seat labels
    const { data: dbSeats } = await supabaseAdmin.from('seats').select('*').eq('screen_id', show.screen_id);
    const seatMap = new Map<string, any>();
    if (dbSeats) {
      for (const s of dbSeats) {
        seatMap.set(s.id, s);
      }
    }

    const pricePerStandard = show.price || show.ticket_price || 170;
    const pricePerPremium = show.premium_price || Math.round((pricePerStandard * 1.5) / 10) * 10;
    let subtotal = 0;
    const seatLabels: string[] = [];

    for (const seatId of finalSeatIds) {
      const dbSeat = seatMap.get(seatId);
      const isPremium = dbSeat ? (dbSeat.seat_type === 'premium' || dbSeat.type === 'premium') : false;
      subtotal += isPremium ? pricePerPremium : pricePerStandard;
      const label = dbSeat ? `${dbSeat.row_label || dbSeat.row_name}${dbSeat.seat_number}` : seatId;
      seatLabels.push(label);
    }

    const convenienceFee = finalSeatIds.length * 30;
    const totalAmount = subtotal + convenienceFee;

    // Generate valid UUID for bookings.id AND unique MQ-XXXXXXXX for booking_reference
    const bookingRef = crypto.randomUUID();
    const bookingReference = generateBookingReference();

    console.log(`[DIAGNOSTIC] Creating booking row - id: ${bookingRef}, booking_reference: ${bookingReference}, booking.user_id: ${user?.id || 'NULL'}`);

    // 7. Create Confirmed Booking row with user_id belonging to authenticated user
    const { data: newBooking, error: bookingErr } = await supabaseAdmin
      .from('bookings')
      .insert({
        id: bookingRef,
        booking_reference: bookingReference,
        user_id: user?.id || null,
        customer_name: customerName || user?.user_metadata?.name || verifiedUserEmail?.split('@')[0] || 'Guest',
        movie_id: movie?.id || show.movie_id,
        movie_title: movie?.title || 'Movie',
        poster_url: movie?.poster_url || '',
        theatre_id: theatre?.id || show.theatre_id,
        theatre_name: theatre?.name || 'Theatre',
        screen_name: screen?.name || 'Screen 1',
        show_id: finalShowId,
        date: show.show_date || show.date || new Date().toISOString().split('T')[0],
        time: show.show_time || show.time || '12:00',
        format: show.format || '2D',
        seats: seatLabels,
        subtotal,
        convenience_fee: convenienceFee,
        total_amount: totalAmount,
        status: 'confirmed',
        payment_method: paymentMethod,
        razorpay_order_id,
        razorpay_payment_id,
        payment_status: 'paid',
      })
      .select()
      .single();

    if (bookingErr) {
      console.error('[DIAGNOSTIC] Failed to create booking row:', bookingErr.message);
      const { data: concBooking } = await supabaseAdmin
        .from('bookings')
        .select('*')
        .eq('razorpay_order_id', razorpay_order_id)
        .maybeSingle();

      if (concBooking) {
        return new Response(
          JSON.stringify({
            success: true,
            bookingId: concBooking.id,
            bookingReference: concBooking.booking_reference,
            message: 'Booking confirmed.',
          }),
          { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      return new Response(
        JSON.stringify({ error: 'Failed to record confirmed booking: ' + bookingErr.message }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // 8. Create booking_seats records
    const seatInserts = finalSeatIds.map((seatId: string) => {
      const dbSeat = seatMap.get(seatId);
      const isPremium = dbSeat ? (dbSeat.seat_type === 'premium' || dbSeat.type === 'premium') : false;
      return {
        booking_id: bookingRef,
        show_id: finalShowId,
        seat_id: seatId,
        price: isPremium ? pricePerPremium : pricePerStandard,
      };
    });

    const { error: bsErr } = await supabaseAdmin.from('booking_seats').insert(seatInserts);
    if (bsErr) {
      console.error('[DIAGNOSTIC] Failed to insert booking seats:', bsErr.message);
    }

    // 9. Create payment record safely
    const { error: pErr } = await supabaseAdmin.from('payments').upsert({
      id: razorpay_payment_id,
      booking_id: bookingRef,
      amount: totalAmount,
      status: 'paid',
      payment_method: paymentMethod,
      razorpay_order_id,
      razorpay_payment_id,
      razorpay_signature,
    });

    if (pErr) {
      console.error('[DIAGNOSTIC] Error creating payment record:', pErr.message);
    }

    // Update order status in razorpay_orders
    try {
      await supabaseAdmin.from('razorpay_orders').update({ status: 'paid', booking_id: bookingRef }).eq('id', razorpay_order_id);
    } catch {
      /* ignore */
    }

    // 10. Send Booking Confirmation Email using verified server-side recipient email
    const recipientEmail = verifiedUserEmail || null;
    let isEmailInvoked = false;

    if (recipientEmail) {
      isEmailInvoked = true;
      try {
        console.log(`[DIAGNOSTIC] Invoking send-booking-email for bookingId: ${bookingRef}, recipient domain: ${getSafeDomain(recipientEmail)}`);
        const emailRes = await fetch(`${SUPABASE_URL}/functions/v1/send-booking-email`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
          },
          body: JSON.stringify({
            bookingId: bookingRef,
            userEmail: recipientEmail,
          }),
        });
        const emailResult = await emailRes.json();
        console.log(`[DIAGNOSTIC] send-booking-email response status: ${emailRes.status}, result:`, emailResult);
      } catch (emailErr: any) {
        console.warn(`[DIAGNOSTIC] Non-blocking warning: send-booking-email exception:`, emailErr.message);
      }
    } else {
      console.log(`[DIAGNOSTIC] No verified recipient email found for user; send-booking-email NOT invoked.`);
    }

    return new Response(
      JSON.stringify({
        success: true,
        bookingId: bookingRef,
        bookingReference: bookingReference,
        message: 'Payment verified and booking confirmed successfully.',
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (err: any) {
    console.error('[DIAGNOSTIC] Unhandled error in verify-razorpay-payment:', err.message);
    return new Response(
      JSON.stringify({ error: err.message || 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
