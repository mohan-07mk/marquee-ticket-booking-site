/**
 * DATA ACCESS LAYER (Supabase)
 * ------------------------------------------------------------------
 * Every page talks to `api.*` and nothing else. Function signatures
 * mirror the original mock layer so no page needs to change.
 *
 * NOTE: The Supabase DB uses snake_case columns. We map to the camelCase
 * types used throughout the frontend.
 */
import { supabase } from '@/lib/supabase';
import type {
  ActiveStatus,
  Booking,
  BookingStatus,
  DashboardData,
  DailyPoint,
  Format,
  Movie,
  MovieStatus,
  PaymentMethod,
  RankedRevenue,
  RevenueReport,
  Seat,
  Screen,
  Show,
  ShowDetails,
  Theatre,
  User,
  UserStatus,
} from '@/types';
import { addDays, toDateKey } from '@/utils/format';
import { makeArt } from '@/utils/poster';
import { calcTotals, premiumPriceFor } from '@/utils/pricing';

/* ------------------------------------------------------------------ */
/* Column mapping helpers                                               */
/* ------------------------------------------------------------------ */

function mapMovie(row: Record<string, unknown>): Movie {
  const languagesRaw = row.languages ?? (row.language ? [row.language] : ['English']);
  const formatsRaw = row.formats ?? ['2D'];
  const genresRaw = row.genres ?? [];

  return {
    id: row.id as string,
    title: (row.title ?? '') as string,
    description: (row.description ?? '') as string,
    genres: (Array.isArray(genresRaw) ? genresRaw : []) as string[],
    languages: (Array.isArray(languagesRaw) ? languagesRaw : ['English']) as string[],
    formats: (Array.isArray(formatsRaw) ? formatsRaw : ['2D']) as Format[],
    durationMin: Number(row.duration ?? 120),
    releaseDate: (row.release_date ?? '') as string,
    rating: Number(row.rating ?? 0),
    certificate: (row.certificate ?? 'UA') as string,
    posterUrl: (row.poster_url ?? '') as string,
    backdropUrl: (row.backdrop_url ?? '') as string,
    trailerUrl: (row.trailer_url ?? '') as string,
    cast: (Array.isArray(row.cast_list) ? row.cast_list : Array.isArray(row.cast) ? row.cast : []) as string[],
    director: (row.director ?? '') as string,
    status: (row.status ?? 'now_showing') as MovieStatus,
    popularity: Number(row.popularity ?? 50),
  };
}

function mapScreen(row: Record<string, unknown>): Screen {
  return {
    id: row.id as string,
    theatreId: (row.theatre_id ?? '') as string,
    name: (row.name ?? '') as string,
    capacity: Number(row.capacity ?? 0),
    rows: Number(row.rows ?? 10),
    seatsPerRow: Number(row.seats_per_row ?? 14),
    formats: (Array.isArray(row.formats) ? row.formats : ['2D']) as Format[],
  };
}

function mapTheatre(row: Record<string, unknown>): Theatre {
  const screensRaw = (row.screens ?? []) as Record<string, unknown>[];
  let storedLink: string | null = null;
  try {
    if (typeof window !== 'undefined') {
      storedLink = localStorage.getItem(`marquee.theatre_screen_link_${row.id}`) || localStorage.getItem('marquee.cinema_screen_video');
    }
  } catch {}
  return {
    id: row.id as string,
    name: (row.name ?? '') as string,
    location: (row.location ?? row.address ?? '') as string,
    amenities: (Array.isArray(row.amenities) ? row.amenities : ['Parking']) as string[],
    screens: screensRaw.map(mapScreen),
    status: (row.status ?? 'active') as ActiveStatus,
    screenViewLink: (row.screen_view_link as string) || (row.screenViewLink as string) || storedLink || undefined,
  };
}

function mapShow(row: Record<string, unknown>): Show {
  return {
    id: row.id as string,
    movieId: (row.movie_id ?? '') as string,
    theatreId: (row.theatre_id ?? '') as string,
    screenId: (row.screen_id ?? '') as string,
    date: (row.show_date ?? row.date ?? '') as string,
    time: (row.show_time ?? row.time ?? '') as string,
    format: (row.format ?? '2D') as Format,
    language: (row.language ?? '') as string,
    price: Number(row.price ?? 0),
    premiumPrice: Number(row.premium_price ?? 0),
    status: (row.status ?? 'active') as 'active' | 'cancelled',
  };
}

function mapBooking(row: Record<string, unknown>): Booking {
  return {
    id: row.id as string,
    userId: (row.user_id ?? '') as string,
    customerName: (row.customer_name ?? 'Guest') as string,
    movieId: (row.movie_id ?? '') as string,
    movieTitle: (row.movie_title ?? '') as string,
    posterUrl: (row.poster_url ?? '') as string,
    theatreId: (row.theatre_id ?? '') as string,
    theatreName: (row.theatre_name ?? '') as string,
    screenName: (row.screen_name ?? '') as string,
    showId: (row.show_id ?? '') as string,
    date: (row.date ?? row.show_date ?? '') as string,
    time: (row.time ?? row.show_time ?? '') as string,
    format: (row.format ?? '2D') as Format,
    seats: (Array.isArray(row.seats) ? row.seats : []) as string[],
    subtotal: Number(row.subtotal ?? 0),
    convenienceFee: Number(row.convenience_fee ?? 0),
    amount: Number(row.total_amount ?? row.amount ?? 0),
    status: (row.status ?? 'confirmed') as BookingStatus,
    paymentMethod: (row.payment_method ?? 'upi') as PaymentMethod,
    createdAt: (row.created_at ?? new Date().toISOString()) as string,
  };
}

function mapUser(row: Record<string, unknown>): User {
  const email = (row.email ?? '') as string;
  const name = (row.name || (email ? email.split('@')[0] : 'User')) as string;

  return {
    id: row.id as string,
    name,
    email,
    phone: (row.phone ?? '') as string,
    role: (row.role ?? 'customer') as 'customer' | 'admin',
    status: (row.status ?? 'active') as UserStatus,
    joinedAt: ((row.joined_at ?? row.created_at ?? '') as string).slice(0, 10),
    totalBookings: row.total_bookings as number | undefined,
  };
}

/* ------------------------------------------------------------------ */
/* Seat layout builder (from DB seats table)                           */
/* ------------------------------------------------------------------ */

function buildSeatLayoutFromDB(
  dbSeats: Record<string, unknown>[],
  show: Show,
  bookedSeatIds: Set<string>,
): Seat[] {
  return dbSeats.map((s) => {
    const rawId = (s.id ?? '') as string;
    const type = (s.seat_type ?? s.type ?? 'standard') as 'standard' | 'premium';
    const rowLabel = (s.row_label ?? s.row_name ?? 'A') as string;
    const seatNum = Number(s.seat_number ?? 1);
    const label = (s.label as string) || `${rowLabel}${seatNum}`;
    const isOccupied = bookedSeatIds.has(rawId);

    return {
      id: rawId,
      label,
      row: rowLabel,
      number: seatNum,
      type,
      status: isOccupied ? 'occupied' : 'available',
      price: type === 'premium' ? show.premiumPrice : show.price,
    };
  });
}

/* ------------------------------------------------------------------ */
/* Storage helpers                                                      */
/* ------------------------------------------------------------------ */

async function uploadToStorage(
  bucket: string,
  path: string,
  file: File,
): Promise<string> {
  const { error } = await supabase.storage.from(bucket).upload(path, file, {
    cacheControl: '3600',
    upsert: true,
  });
  if (error) throw new Error(`Upload failed: ${error.message}`);
  const { data } = supabase.storage.from(bucket).getPublicUrl(path);
  return data.publicUrl;
}

/* ------------------------------------------------------------------ */
/* Movies                                                              */
/* ------------------------------------------------------------------ */
export type MovieInput = Omit<Movie, 'id' | 'posterUrl' | 'backdropUrl' | 'trailerUrl' | 'cast' | 'director' | 'popularity'> &
  Partial<Pick<Movie, 'posterUrl' | 'backdropUrl' | 'trailerUrl' | 'cast' | 'director' | 'popularity'>> & {
    posterFile?: File;
    backdropFile?: File;
  };

const movies = {
  async list(opts: { includeInactive?: boolean } = {}): Promise<Movie[]> {
    let query = supabase.from('movies').select('*');
    if (!opts.includeInactive) query = query.neq('status', 'inactive');
    const { data, error } = await query;
    if (error) throw new Error(error.message);
    return (data ?? []).map(mapMovie);
  },

  async get(id: string): Promise<Movie> {
    const { data, error } = await supabase.from('movies').select('*').eq('id', id).single();
    if (error) throw new Error('This movie could not be found.');
    return mapMovie(data);
  },

  async create(input: MovieInput): Promise<Movie> {
    let posterUrl = input.posterUrl ?? '';
    let backdropUrl = input.backdropUrl ?? '';

    if (input.posterFile) {
      const ext = input.posterFile.name.split('.').pop() ?? 'jpg';
      posterUrl = await uploadToStorage('movie-assets', `posters/${Date.now()}.${ext}`, input.posterFile);
    }
    if (input.backdropFile) {
      const ext = input.backdropFile.name.split('.').pop() ?? 'jpg';
      backdropUrl = await uploadToStorage('movie-assets', `backdrops/${Date.now()}.${ext}`, input.backdropFile);
    }

    if (!posterUrl) posterUrl = makeArt(input.title, Date.now() % 8, 'poster');
    if (!backdropUrl) backdropUrl = makeArt(input.title, Date.now() % 8, 'backdrop');

    // ONLY use actual database column names: duration (NOT duration_min), cast_list (NOT cast)
    const insertPayload: Record<string, unknown> = {
      title: input.title,
      description: input.description,
      duration: input.durationMin,
      release_date: input.releaseDate,
      rating: input.rating,
      poster_url: posterUrl,
      backdrop_url: backdropUrl,
      trailer_url: input.trailerUrl ?? '',
      status: input.status,
      language: input.languages?.[0] ?? 'English',
      languages: input.languages ?? ['English'],
      genres: input.genres ?? [],
      formats: input.formats ?? ['2D'],
      certificate: input.certificate ?? 'UA',
      cast_list: input.cast ?? [],
      director: input.director ?? '',
      popularity: input.popularity ?? 50,
    };

    const { data, error } = await supabase
      .from('movies')
      .insert(insertPayload)
      .select()
      .single();

    if (error) throw new Error(error.message);
    return mapMovie(data);
  },

  async update(id: string, patch: Partial<Movie> & { posterFile?: File; backdropFile?: File }): Promise<Movie> {
    const updates: Record<string, unknown> = {};
    if (patch.title !== undefined) updates.title = patch.title;
    if (patch.description !== undefined) updates.description = patch.description;
    if (patch.genres !== undefined) updates.genres = patch.genres;
    if (patch.languages !== undefined) {
      updates.languages = patch.languages;
      updates.language = patch.languages[0] ?? 'English';
    }
    if (patch.formats !== undefined) updates.formats = patch.formats;
    if (patch.durationMin !== undefined) {
      updates.duration = patch.durationMin;
    }
    if (patch.releaseDate !== undefined) updates.release_date = patch.releaseDate;
    if (patch.rating !== undefined) updates.rating = patch.rating;
    if (patch.certificate !== undefined) updates.certificate = patch.certificate;
    if (patch.trailerUrl !== undefined) updates.trailer_url = patch.trailerUrl;
    if (patch.cast !== undefined) updates.cast_list = patch.cast;
    if (patch.director !== undefined) updates.director = patch.director;
    if (patch.status !== undefined) updates.status = patch.status;
    if (patch.popularity !== undefined) updates.popularity = patch.popularity;

    if (patch.posterFile) {
      const ext = patch.posterFile.name.split('.').pop() ?? 'jpg';
      updates.poster_url = await uploadToStorage('movie-assets', `posters/${id}-${Date.now()}.${ext}`, patch.posterFile);
    } else if (patch.posterUrl !== undefined) {
      updates.poster_url = patch.posterUrl;
    }
    if (patch.backdropFile) {
      const ext = patch.backdropFile.name.split('.').pop() ?? 'jpg';
      updates.backdrop_url = await uploadToStorage('movie-assets', `backdrops/${id}-${Date.now()}.${ext}`, patch.backdropFile);
    } else if (patch.backdropUrl !== undefined) {
      updates.backdrop_url = patch.backdropUrl;
    }

    const { data, error } = await supabase.from('movies').update(updates).eq('id', id).select().single();
    if (error) throw new Error(error.message);
    return mapMovie(data);
  },

  async remove(id: string): Promise<void> {
    const { error } = await supabase.from('movies').delete().eq('id', id);
    if (error) throw new Error(error.message);
  },

  async setStatus(id: string, status: MovieStatus): Promise<Movie> {
    return movies.update(id, { status });
  },
};

/* ------------------------------------------------------------------ */
/* Theatres                                                            */
/* ------------------------------------------------------------------ */
export interface TheatreInput {
  name: string;
  location: string;
  status: ActiveStatus;
  screenCount: number;
  capacityPerScreen: number;
  screenViewLink?: string;
}

const theatres = {
  async list(opts: { includeInactive?: boolean } = {}): Promise<Theatre[]> {
    let query = supabase.from('theatres').select('*, screens(*)');
    if (!opts.includeInactive) query = query.eq('status', 'active');
    const { data, error } = await query;
    if (error) throw new Error(error.message);
    return (data ?? []).map(mapTheatre);
  },

  async create(input: TheatreInput): Promise<Theatre> {
    const { data: theatre, error: theatreErr } = await supabase
      .from('theatres')
      .insert({
        name: input.name,
        location: input.location,
        address: input.location,
        status: input.status,
        amenities: ['Parking'],
      })
      .select()
      .single();

    if (theatreErr) throw new Error(theatreErr.message);

    if (input.screenViewLink) {
      try {
        if (typeof window !== 'undefined') {
          localStorage.setItem(`marquee.theatre_screen_link_${theatre.id}`, input.screenViewLink);
          localStorage.setItem('marquee.cinema_screen_video', input.screenViewLink);
        }
      } catch {}
    }

    const seatsPerRow = 14;
    const rows = Math.max(5, Math.ceil(input.capacityPerScreen / seatsPerRow));
    const screenInserts = Array.from({ length: input.screenCount }, (_, i) => ({
      theatre_id: theatre.id,
      name: `Screen ${i + 1}`,
      capacity: rows * seatsPerRow,
      rows,
      seats_per_row: seatsPerRow,
      formats: ['2D', '3D'],
    }));

    const { data: screensData, error: screensErr } = await supabase
      .from('screens')
      .insert(screenInserts)
      .select();

    if (screensErr) throw new Error(screensErr.message);

    for (const screen of (screensData ?? [])) {
      const seatInserts: Record<string, unknown>[] = [];
      const premiumFrom = rows - 3;
      for (let r = 0; r < rows; r++) {
        const rowLabel = String.fromCharCode(65 + r);
        for (let n = 1; n <= seatsPerRow; n++) {
          const seatType = r >= premiumFrom ? 'premium' : 'standard';
          seatInserts.push({
            id: crypto.randomUUID(),
            screen_id: screen.id,
            row_label: rowLabel,
            seat_number: n,
            seat_type: seatType,
          });
        }
      }
      if (seatInserts.length) {
        await supabase.from('seats').insert(seatInserts);
      }
    }

    return {
      ...mapTheatre(theatre),
      screens: (screensData ?? []).map(mapScreen),
    };
  },

  async update(id: string, input: TheatreInput): Promise<Theatre> {
    if (input.screenViewLink !== undefined) {
      try {
        if (typeof window !== 'undefined') {
          if (input.screenViewLink) {
            localStorage.setItem(`marquee.theatre_screen_link_${id}`, input.screenViewLink);
            localStorage.setItem('marquee.cinema_screen_video', input.screenViewLink);
          } else {
            localStorage.removeItem(`marquee.theatre_screen_link_${id}`);
          }
        }
      } catch {}
    }

    const payload: Record<string, unknown> = {
      name: input.name,
      location: input.location,
      address: input.location,
      status: input.status,
    };
    if (input.screenViewLink !== undefined) {
      payload.screen_view_link = input.screenViewLink;
    }

    let { error } = await supabase
      .from('theatres')
      .update(payload)
      .eq('id', id);

    if (error && error.message?.includes('screen_view_link')) {
      delete payload.screen_view_link;
      const retry = await supabase.from('theatres').update(payload).eq('id', id);
      error = retry.error;
    }

    if (error) throw new Error(error.message);

    const { data, error: fetchErr } = await supabase
      .from('theatres')
      .select('*, screens(*)')
      .eq('id', id)
      .single();

    if (fetchErr) throw new Error(fetchErr.message);
    return mapTheatre(data);
  },

  async remove(id: string): Promise<void> {
    const { error } = await supabase.from('theatres').delete().eq('id', id);
    if (error) throw new Error(error.message);
  },
};

/* ------------------------------------------------------------------ */
/* Shows                                                               */
/* ------------------------------------------------------------------ */
export interface ShowFilters {
  movieId?: string;
  theatreId?: string;
  date?: string;
}
export type ShowInput = Omit<Show, 'id' | 'premiumPrice' | 'seatsLeft' | 'capacity'>;

const shows = {
  async list(filters: ShowFilters = {}): Promise<Show[]> {
    let query = supabase.from('shows').select('*');
    if (filters.movieId) query = query.eq('movie_id', filters.movieId);
    if (filters.theatreId) query = query.eq('theatre_id', filters.theatreId);
    if (filters.date) query = query.eq('show_date', filters.date);

    const { data, error } = await query;
    if (error) throw new Error(error.message);

    const mapped = (data ?? []).map(mapShow);
    mapped.sort((a, b) => `${a.date} ${a.time}`.localeCompare(`${b.date} ${b.time}`));

    if (filters.movieId) {
      const showIds = mapped.map((s) => s.id);
      if (showIds.length) {
        const { data: bookedData } = await supabase
          .from('booking_seats')
          .select('show_id, seat_id')
          .in('show_id', showIds);

        const bookedByShow = new Map<string, number>();
        for (const row of (bookedData ?? [])) {
          bookedByShow.set(row.show_id, (bookedByShow.get(row.show_id) ?? 0) + 1);
        }

        const screenIds = [...new Set(mapped.map((s) => s.screenId))];
        const { data: screens } = await supabase
          .from('screens')
          .select('id, capacity')
          .in('id', screenIds);

        const capMap = new Map<string, number>();
        for (const s of (screens ?? [])) capMap.set(s.id, s.capacity);

        return mapped.map((s) => ({
          ...s,
          capacity: capMap.get(s.screenId) ?? 0,
          seatsLeft: (capMap.get(s.screenId) ?? 0) - (bookedByShow.get(s.id) ?? 0),
        }));
      }
    }

    return mapped;
  },

  async getDetails(showId: string): Promise<ShowDetails> {
    const { data: showRow, error: showErr } = await supabase
      .from('shows')
      .select('*')
      .eq('id', showId)
      .single();

    if (showErr) throw new Error('This show could not be found.');

    const show = mapShow(showRow);

    const [movieRes, theatreRes] = await Promise.all([
      supabase.from('movies').select('*').eq('id', show.movieId).single(),
      supabase.from('theatres').select('*, screens(*)').eq('id', show.theatreId).single(),
    ]);

    if (movieRes.error || theatreRes.error) throw new Error('This show could not be found.');

    const movie = mapMovie(movieRes.data);
    const theatre = mapTheatre(theatreRes.data);
    const screen = theatre.screens.find((s) => s.id === show.screenId);
    if (!screen) throw new Error('This show could not be found.');

    const { data: bookedData } = await supabase
      .from('booking_seats')
      .select('seat_id')
      .eq('show_id', showId);

    const booked = (bookedData ?? []).length;

    return {
      show: { ...show, capacity: screen.capacity, seatsLeft: screen.capacity - booked },
      movie,
      theatre,
      screen,
    };
  },

  async create(input: ShowInput & { premiumPrice?: number }): Promise<Show> {
    const { data, error } = await supabase
      .from('shows')
      .insert({
        movie_id: input.movieId,
        theatre_id: input.theatreId,
        screen_id: input.screenId,
        show_date: input.date,
        show_time: input.time,
        format: input.format,
        language: input.language,
        price: input.price,
        premium_price: input.premiumPrice ?? premiumPriceFor(input.price),
        status: input.status,
      })
      .select()
      .single();

    if (error) throw new Error(error.message);
    return mapShow(data);
  },

  async update(id: string, patch: Partial<Show>): Promise<Show> {
    const updates: Record<string, unknown> = {};
    if (patch.movieId !== undefined) updates.movie_id = patch.movieId;
    if (patch.theatreId !== undefined) updates.theatre_id = patch.theatreId;
    if (patch.screenId !== undefined) updates.screen_id = patch.screenId;
    if (patch.date !== undefined) updates.show_date = patch.date;
    if (patch.time !== undefined) updates.show_time = patch.time;
    if (patch.format !== undefined) updates.format = patch.format;
    if (patch.language !== undefined) updates.language = patch.language;
    if (patch.price !== undefined) {
      updates.price = patch.price;
      updates.premium_price = patch.premiumPrice ?? premiumPriceFor(patch.price);
    }
    if (patch.status !== undefined) updates.status = patch.status;

    const { data, error } = await supabase.from('shows').update(updates).eq('id', id).select().single();
    if (error) throw new Error(error.message);
    return mapShow(data);
  },

  async remove(id: string): Promise<void> {
    const { error } = await supabase.from('shows').delete().eq('id', id);
    if (error) throw new Error(error.message);
  },
};

/* ------------------------------------------------------------------ */
/* Seats                                                               */
/* ------------------------------------------------------------------ */
const seats = {
  async getLayout(showId: string): Promise<Seat[]> {
    const { data: showRow, error: showErr } = await supabase
      .from('shows')
      .select('*')
      .eq('id', showId)
      .single();

    if (showErr) throw new Error('This show could not be found.');
    const show = mapShow(showRow);

    let { data: seatRows } = await supabase
      .from('seats')
      .select('*')
      .eq('screen_id', show.screenId);

    const { data: bookedRows } = await supabase
      .from('booking_seats')
      .select('seat_id')
      .eq('show_id', showId);

    const bookedIds = new Set((bookedRows ?? []).map((r) => r.seat_id));

    console.log('[api.seats.getLayout] show_id:', showId, 'screen_id:', show.screenId, 'seatCount:', seatRows?.length);

    // If screen currently has 0 seats in DB, generate seats dynamically with valid UUIDs
    if (!seatRows || seatRows.length === 0) {
      const { data: screenRow } = await supabase
        .from('screens')
        .select('*')
        .eq('id', show.screenId)
        .single();

      const totalRows = Math.max(1, Number(screenRow?.rows ?? 10));
      const seatsPerRow = Math.max(1, Number(screenRow?.seats_per_row ?? 14));
      const premiumFrom = totalRows - 3;
      const inserts: Record<string, unknown>[] = [];

      for (let r = 0; r < totalRows; r++) {
        const rowLabel = String.fromCharCode(65 + r);
        for (let n = 1; n <= seatsPerRow; n++) {
          const seatType = r >= premiumFrom ? 'premium' : 'standard';
          inserts.push({
            id: crypto.randomUUID(),
            screen_id: show.screenId,
            row_label: rowLabel,
            seat_number: n,
            seat_type: seatType,
          });
        }
      }

      if (inserts.length) {
        try {
          const { data: insertedSeats } = await supabase.from('seats').insert(inserts).select();
          if (insertedSeats && insertedSeats.length) {
            seatRows = insertedSeats;
          } else {
            seatRows = inserts;
          }
        } catch {
          seatRows = inserts;
        }
      }
    }

    return buildSeatLayoutFromDB(seatRows ?? [], show, bookedIds);
  },
};

/* ------------------------------------------------------------------ */
/* Bookings                                                            */
/* ------------------------------------------------------------------ */
export interface CreateBookingInput {
  showId: string;
  seats: Seat[];
  paymentMethod: PaymentMethod;
  userId?: string;
  customerName?: string;
  simulateFailure?: boolean;
}

export interface CreateRazorpayOrderInput {
  showId: string;
  seats: Seat[];
}

export interface VerifyRazorpayPaymentInput {
  razorpay_order_id: string;
  razorpay_payment_id: string;
  razorpay_signature: string;
  showId: string;
  seats: Seat[];
  paymentMethod: PaymentMethod;
  customerName?: string;
}

const bookings = {
  async listForUser(userId: string): Promise<Booking[]> {
    const { data, error } = await supabase
      .from('bookings')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) throw new Error(error.message);
    return (data ?? []).map(mapBooking);
  },

  async listAll(): Promise<Booking[]> {
    const { data, error } = await supabase
      .from('bookings')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw new Error(error.message);
    return (data ?? []).map(mapBooking);
  },

  async get(id: string): Promise<Booking> {
    const { data, error } = await supabase
      .from('bookings')
      .select('*')
      .eq('id', id)
      .single();

    if (error) throw new Error('This booking could not be found.');
    return mapBooking(data);
  },

  async create(input: CreateBookingInput): Promise<Booking> {
    if (input.simulateFailure) {
      throw new Error('Your bank declined this payment. Try a different card or payment method.');
    }

    const { data: showRow, error: showErr } = await supabase
      .from('shows')
      .select('*')
      .eq('id', input.showId)
      .single();

    if (showErr) throw new Error('This show could not be found.');
    const show = mapShow(showRow);

    const [movieRes, theatreRes] = await Promise.all([
      supabase.from('movies').select('*').eq('id', show.movieId).single(),
      supabase.from('theatres').select('*, screens(*)').eq('id', show.theatreId).single(),
    ]);

    if (movieRes.error || theatreRes.error) throw new Error('This show could not be found.');
    const movie = mapMovie(movieRes.data);
    const theatre = mapTheatre(theatreRes.data);
    const screen = theatre.screens.find((s) => s.id === show.screenId);

    const seatIds = input.seats.map((s) => s.id);
    const { data: existing } = await supabase
      .from('booking_seats')
      .select('seat_id')
      .eq('show_id', input.showId)
      .in('seat_id', seatIds);

    if (existing && existing.length > 0) {
      const takenIds = existing.map((r) => r.seat_id);
      throw new Error(`Seat ${takenIds.join(', ')} was just booked by someone else. Please pick different seats.`);
    }

    const { subtotal, convenienceFee, total } = calcTotals(input.seats);
    const bookingRef = crypto.randomUUID();
    const bookingReference = `MQ-${Math.random().toString(36).substring(2, 10).toUpperCase()}`;
    const seatLabels = input.seats.map((s) => s.label || `${s.row}${s.number}`);

    console.log('[api.bookings.create] Generated bookingRef UUID:', bookingRef, 'Reference:', bookingReference, 'show_id:', input.showId, 'seat_ids:', seatIds);

    const { data: bookingRow, error: bookingErr } = await supabase
      .from('bookings')
      .insert({
        id: bookingRef,
        booking_reference: bookingReference,
        user_id: input.userId || null,
        customer_name: input.customerName ?? 'Guest',
        movie_id: movie.id,
        movie_title: movie.title,
        poster_url: movie.posterUrl,
        theatre_id: theatre.id,
        theatre_name: theatre.name,
        screen_name: screen?.name ?? '',
        show_id: input.showId,
        date: show.date,
        time: show.time,
        format: show.format,
        seats: seatLabels,
        subtotal,
        convenience_fee: convenienceFee,
        total_amount: total,
        status: 'confirmed',
        payment_method: input.paymentMethod,
      })
      .select()
      .single();

    if (bookingErr) {
      console.error('[api.bookings.create] Error creating booking row:', bookingErr);
      if (bookingErr.message.includes('unique') || bookingErr.message.includes('duplicate')) {
        throw new Error('Some seats were just booked by someone else. Please pick different seats.');
      }
      throw new Error(bookingErr.message);
    }

    const bsInserts = seatIds.map((seatId) => ({
      booking_id: bookingRef,
      show_id: input.showId,
      seat_id: seatId,
    }));

    const { error: bsErr } = await supabase.from('booking_seats').insert(bsInserts);
    if (bsErr) {
      console.error('[api.bookings.create] Error inserting booking seats:', bsErr);
      await supabase.from('bookings').delete().eq('id', bookingRef);
      if (bsErr.message.includes('unique') || bsErr.message.includes('duplicate')) {
        throw new Error('Some seats were just booked by someone else. Please pick different seats.');
      }
      throw new Error(bsErr.message);
    }

    await supabase.from('payments').insert({
      booking_id: bookingRef,
      amount: total,
      payment_method: input.paymentMethod,
      status: 'paid',
    });

    return mapBooking(bookingRow);
  },

  async createRazorpayOrder(input: CreateRazorpayOrderInput) {
    const seatIds = input.seats.map((s) => s.id);
    console.log('[api.bookings.createRazorpayOrder] show_id:', input.showId, 'seat_ids:', seatIds);

    // Pass active user session token if available
    const { data: sessionData } = await supabase.auth.getSession();
    const accessToken = sessionData.session?.access_token;
    const headers: Record<string, string> = {};
    if (accessToken) {
      headers['Authorization'] = `Bearer ${accessToken}`;
    }

    // Call Supabase Edge Function create-razorpay-order
    const { data, error } = await supabase.functions.invoke('create-razorpay-order', {
      body: { showId: input.showId, seatIds },
      headers,
    });

    if (!error && data?.success) {
      return data as {
        orderId: string;
        amount: number;
        currency: string;
        keyId?: string;
        subtotal: number;
        convenienceFee: number;
        total: number;
      };
    }

    if (error) {
      let edgeMsg = data?.error;
      if (!edgeMsg && 'context' in error) {
        try {
          const res = (error as any).context;
          if (res && typeof res.json === 'function') {
            const body = await res.json();
            edgeMsg = body?.error || body?.message;
          }
        } catch {
          /* ignore */
        }
      }
      if (!error.message?.includes('FunctionsFetchError') && !error.message?.includes('Failed to send')) {
        throw new Error(edgeMsg || error.message);
      }
    }

    // Direct database validation fallback if edge function is in local dev environment
    const { error: showErr } = await supabase
      .from('shows')
      .select('*')
      .eq('id', input.showId)
      .single();

    if (showErr) throw new Error('This show could not be found.');

    const { data: existing } = await supabase
      .from('booking_seats')
      .select('seat_id')
      .eq('show_id', input.showId)
      .in('seat_id', seatIds);

    if (existing && existing.length > 0) {
      const takenIds = existing.map((r) => r.seat_id).join(', ');
      throw new Error(`Seat(s) ${takenIds} are already booked for this show. Please pick different seats.`);
    }

    const { subtotal, convenienceFee, total } = calcTotals(input.seats);
    const keyId = (import.meta.env.VITE_RAZORPAY_KEY_ID as string) || 'rzp_test_mock_key';

    return {
      orderId: `order_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      amount: total * 100,
      currency: 'INR',
      keyId,
      subtotal,
      convenienceFee,
      total,
    };
  },

  async verifyRazorpayPayment(input: VerifyRazorpayPaymentInput) {
    const seatIds = input.seats.map((s) => s.id);

    // Pass active user session token if available
    const { data: sessionData } = await supabase.auth.getSession();
    const accessToken = sessionData.session?.access_token;
    const headers: Record<string, string> = {};
    if (accessToken) {
      headers['Authorization'] = `Bearer ${accessToken}`;
    }

    console.log('[api.bookings.verifyRazorpayPayment] show_id:', input.showId, 'seat_ids:', seatIds, 'User token attached:', !!accessToken);

    // Call Supabase Edge Function verify-razorpay-payment
    const { data, error } = await supabase.functions.invoke('verify-razorpay-payment', {
      body: {
        razorpay_order_id: input.razorpay_order_id,
        razorpay_payment_id: input.razorpay_payment_id,
        razorpay_signature: input.razorpay_signature,
        showId: input.showId,
        seatIds,
        paymentMethod: input.paymentMethod,
        customerName: input.customerName,
      },
      headers,
    });

    if (!error && data?.success) {
      return { bookingId: data.bookingId as string };
    }

    if (error) {
      let edgeMsg = data?.error;
      if (!edgeMsg && 'context' in error) {
        try {
          const res = (error as any).context;
          if (res && typeof res.json === 'function') {
            const body = await res.json();
            edgeMsg = body?.error || body?.message;
          }
        } catch {
          /* ignore */
        }
      }
      if (!error.message?.includes('FunctionsFetchError') && !error.message?.includes('Failed to send')) {
        throw new Error(edgeMsg || error.message);
      }
    }

    // Direct fallback if edge function is in local dev environment
    const booking = await bookings.create({
      showId: input.showId,
      seats: input.seats,
      paymentMethod: input.paymentMethod,
      customerName: input.customerName,
    });

    try {
      await supabase.from('bookings').update({
        razorpay_order_id: input.razorpay_order_id,
        razorpay_payment_id: input.razorpay_payment_id,
        payment_status: 'paid',
      }).eq('id', booking.id);

      await supabase.from('payments').upsert({
        id: input.razorpay_payment_id,
        booking_id: booking.id,
        amount: booking.amount,
        status: 'paid',
        payment_method: input.paymentMethod,
        razorpay_order_id: input.razorpay_order_id,
        razorpay_payment_id: input.razorpay_payment_id,
        razorpay_signature: input.razorpay_signature,
      });
    } catch {
      /* ignore if columns not migrated yet */
    }

    return { bookingId: booking.id };
  },

  async setStatus(id: string, status: BookingStatus): Promise<Booking> {
    const { data, error } = await supabase
      .from('bookings')
      .update({ status })
      .eq('id', id)
      .select()
      .single();

    if (error) throw new Error(error.message);

    if (status === 'cancelled') {
      await supabase.from('booking_seats').delete().eq('booking_id', id);
    }

    return mapBooking(data);
  },
};

/* ------------------------------------------------------------------ */
/* Users                                                               */
/* ------------------------------------------------------------------ */
const users = {
  async list(): Promise<User[]> {
    const { data, error } = await supabase.from('profiles').select('*').order('created_at', { ascending: false });
    if (error) throw new Error(error.message);

    const mapped = (data ?? []).map(mapUser);

    const { data: bookingCounts } = await supabase
      .from('bookings')
      .select('user_id')
      .neq('status', 'cancelled');

    const countMap = new Map<string, number>();
    for (const row of (bookingCounts ?? [])) {
      if (row.user_id) {
        countMap.set(row.user_id, (countMap.get(row.user_id) ?? 0) + 1);
      }
    }

    return mapped.map((u) => ({ ...u, totalBookings: countMap.get(u.id) ?? 0 }));
  },

  async setStatus(id: string, status: UserStatus): Promise<User> {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .update({ status })
        .eq('id', id)
        .select()
        .single();

      if (!error && data) return mapUser(data);
    } catch {
      /* ignore if status column is missing */
    }

    const { data } = await supabase.from('profiles').select('*').eq('id', id).single();
    const user = data ? mapUser(data) : ({ id, name: 'User', email: '', phone: '', role: 'customer', status, joinedAt: '' } as User);
    return { ...user, status };
  },
};

/* ------------------------------------------------------------------ */
/* OAuth Redirect Helper                                              */
/* ------------------------------------------------------------------ */
export function getAuthRedirectUrl(): string {
  const envUrl = import.meta.env.VITE_SITE_URL || import.meta.env.VITE_REDIRECT_URL;
  if (envUrl) {
    return envUrl.trim().replace(/\/$/, '');
  }
  if (typeof window !== 'undefined' && window.location && window.location.origin) {
    return window.location.origin;
  }
  return 'https://dainty-cocada-99dd91.netlify.app';
}

const auth = {
  async login(email: string, password: string): Promise<User> {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw new Error(error.message);

    const { data: profile, error: profileErr } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', data.user.id)
      .single();

    if (profileErr) throw new Error('Profile not found. Please contact support.');
    return mapUser(profile);
  },

  async register(input: { name: string; email: string; phone: string; password: string }): Promise<User> {
    const { data, error } = await supabase.auth.signUp({
      email: input.email,
      password: input.password,
      options: {
        data: {
          name: input.name,
          phone: input.phone,
        },
      },
    });

    if (error) throw new Error(error.message);
    if (!data.user) throw new Error('Registration failed. Please try again.');

    try {
      await supabase
        .from('profiles')
        .update({ name: input.name, phone: input.phone })
        .eq('id', data.user.id);
    } catch {
      /* ignore if update fails */
    }

    const { data: profile } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', data.user.id)
      .single();

    return profile ? mapUser(profile) : {
      id: data.user.id,
      name: input.name,
      email: input.email,
      phone: input.phone,
      role: 'customer',
      status: 'active',
      joinedAt: new Date().toISOString().slice(0, 10),
    };
  },

  async forgotPassword(email: string): Promise<void> {
    const redirectUrl = getAuthRedirectUrl();
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${redirectUrl}/reset-password`,
    });
    if (error) throw new Error(error.message);
  },

  async loginWithGoogle(): Promise<User> {
    const redirectUrl = getAuthRedirectUrl();
    const { error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: redirectUrl,
      },
    });
    if (error) throw new Error(error.message);

    return {} as User;
  },

  async logout(): Promise<void> {
    const { error } = await supabase.auth.signOut();
    if (error) throw new Error(error.message);
  },

  async getSession(): Promise<User | null> {
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return null;

    const { data: profile } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', session.user.id)
      .single();

    if (profile) {
      const user = mapUser(profile);
      const provider = session.user.app_metadata?.provider || session.user.identities?.[0]?.provider;
      if (user.role === 'admin' && provider === 'google') {
        localStorage.setItem('marquee.auth_error', 'Admins must log in using Email and Password.');
        await supabase.auth.signOut();
        throw new Error('Admins must log in using Email and Password.');
      }
      return user;
    }

    const name = session.user.user_metadata?.full_name || session.user.user_metadata?.name || session.user.email?.split('@')[0] || 'User';
    const email = session.user.email || '';
    const phone = session.user.user_metadata?.phone || '';

    try {
      const { data: newProfile } = await supabase
        .from('profiles')
        .upsert({
          id: session.user.id,
          name,
          email,
          phone,
          role: 'customer',
          status: 'active',
        })
        .select()
        .single();
      if (newProfile) return mapUser(newProfile);
    } catch {
      /* ignore upsert error if RLS blocks direct insert */
    }

    return {
      id: session.user.id,
      name,
      email,
      phone,
      role: 'customer',
      status: 'active',
      joinedAt: (session.user.created_at ?? new Date().toISOString()).slice(0, 10),
    };
  },
};

/* ------------------------------------------------------------------ */
/* Admin analytics                                                     */
/* ------------------------------------------------------------------ */
const shortLabel = (key: string) =>
  new Date(`${key}T00:00:00`).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });

function buildDailySeries(bookingsList: Booking[], days: number): DailyPoint[] {
  const today = new Date();
  const dayOf = (iso: string) => toDateKey(new Date(iso));

  return Array.from({ length: days }, (_, i) => {
    const key = toDateKey(addDays(today, i - (days - 1)));
    const dayBookings = bookingsList.filter((b) => dayOf(b.createdAt) === key);
    return {
      date: key,
      label: shortLabel(key),
      bookings: dayBookings.length,
      revenue: dayBookings.reduce((s, b) => s + b.amount, 0),
    };
  });
}

function buildRank(list: Booking[], keyOf: (b: Booking) => [string, string]): RankedRevenue[] {
  const map = new Map<string, RankedRevenue>();
  for (const b of list) {
    const [id, name] = keyOf(b);
    const row = map.get(id) ?? { id, name, bookings: 0, revenue: 0 };
    row.bookings += 1;
    row.revenue += b.amount;
    map.set(id, row);
  }
  return [...map.values()].sort((a, b) => b.revenue - a.revenue);
}

const pct = (now: number, before: number) => (before === 0 ? 0 : Math.round(((now - before) / before) * 100));

const admin = {
  async getDashboard(): Promise<DashboardData> {
    const { data: allBookings } = await supabase
      .from('bookings')
      .select('*')
      .neq('status', 'cancelled')
      .order('created_at', { ascending: false });

    const valid = (allBookings ?? []).map(mapBooking);

    const { count: movieCount } = await supabase.from('movies').select('*', { count: 'exact', head: true });
    const { count: userCount } = await supabase.from('profiles').select('*', { count: 'exact', head: true });

    const last28 = buildDailySeries(valid, 28);
    const recent = last28.slice(14);
    const prev = last28.slice(0, 14);
    const sum = (arr: DailyPoint[], k: 'bookings' | 'revenue') => arr.reduce((s, p) => s + p[k], 0);

    return {
      totals: {
        movies: movieCount ?? 0,
        users: userCount ?? 0,
        bookings: valid.length,
        revenue: valid.reduce((s, b) => s + b.amount, 0),
      },
      deltas: {
        bookings: pct(sum(recent, 'bookings'), sum(prev, 'bookings')),
        revenue: pct(sum(recent, 'revenue'), sum(prev, 'revenue')),
      },
      daily: recent,
      popularMovies: buildRank(valid, (b) => [b.movieId, b.movieTitle])
        .sort((a, b) => b.bookings - a.bookings)
        .slice(0, 6),
      recentBookings: valid.slice(0, 6),
    };
  },

  async getRevenue(): Promise<RevenueReport> {
    const { data: allBookings } = await supabase
      .from('bookings')
      .select('*')
      .neq('status', 'cancelled');

    const valid = (allBookings ?? []).map(mapBooking);
    const now = new Date();
    const todayStr = toDateKey(now);
    const monthKey = todayStr.slice(0, 7);
    const total = valid.reduce((s, b) => s + b.amount, 0);
    const dayOf = (iso: string) => toDateKey(new Date(iso));

    const monthly = Array.from({ length: 6 }, (_, i) => {
      const d = new Date(now.getFullYear(), now.getMonth() - (5 - i), 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const list = valid.filter((b) => dayOf(b.createdAt).startsWith(key));
      return {
        month: d.toLocaleDateString('en-IN', { month: 'short', year: '2-digit' }),
        bookings: list.length,
        revenue: list.reduce((s, b) => s + b.amount, 0),
      };
    });

    return {
      total,
      today: valid.filter((b) => dayOf(b.createdAt) === todayStr).reduce((s, b) => s + b.amount, 0),
      thisMonth: valid.filter((b) => dayOf(b.createdAt).startsWith(monthKey)).reduce((s, b) => s + b.amount, 0),
      avgPerBooking: valid.length ? Math.round(total / valid.length) : 0,
      daily: buildDailySeries(valid, 30),
      monthly,
      byMovie: buildRank(valid, (b) => [b.movieId, b.movieTitle]).slice(0, 8),
      byTheatre: buildRank(valid, (b) => [b.theatreId, b.theatreName]),
    };
  },
};

export const api = { movies, theatres, shows, seats, bookings, users, auth, admin };
