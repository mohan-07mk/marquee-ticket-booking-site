import { Link, useSearchParams } from 'react-router-dom';
import { ChevronLeft, Clock, Star } from 'lucide-react';
import { MovieGrid } from '@/components/MovieGrid';
import { ShowtimePicker } from '@/components/ShowtimePicker';
import { Badge } from '@/components/ui/Badge';
import { Skeleton } from '@/components/ui/Skeleton';
import { ErrorState } from '@/components/ui/States';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { api } from '@/services/api';
import { formatDuration } from '@/utils/format';

/** /booking : theatre + showtime selection for one movie (movie and date come from the URL). */
export default function Booking() {
  const [params, setParams] = useSearchParams();
  const movieId = params.get('movieId');
  const date = params.get('date') ?? undefined;
  useDocumentTitle('Choose a theatre');

  const movie = useAsync(() => (movieId ? api.movies.get(movieId) : Promise.resolve(null)), [movieId]);
  const list = useAsync(() => api.movies.list(), []);

  if (!movieId) {
    const nowShowing = (list.data ?? []).filter((m) => m.status === 'now_showing');
    return (
      <div className="container-page py-10 sm:py-14">
        <h1 className="font-display text-5xl font-extrabold leading-none sm:text-7xl">Book tickets</h1>
        <p className="mb-8 mt-3 text-muted">Choose a movie to see theatres and showtimes.</p>
        {list.error ? <ErrorState message={list.error} onRetry={list.reload} /> : <MovieGrid movies={nowShowing} loading={list.loading} />}
      </div>
    );
  }

  return (
    <div className="container-page py-8 sm:py-12">
      <Link to={`/movies/${movieId}`} className="mb-6 inline-flex items-center gap-1 text-sm text-muted transition hover:text-white">
        <ChevronLeft className="h-4 w-4" />
        Back to movie
      </Link>

      {movie.error ? (
        <ErrorState message={movie.error} onRetry={movie.reload} />
      ) : movie.loading || !movie.data ? (
        <Skeleton className="mb-10 h-40 w-full" />
      ) : (
        <>
          <header className="mb-10 flex gap-5 rounded-3xl border border-line bg-surface p-4 sm:p-5">
            <img src={movie.data.posterUrl} alt={`${movie.data.title} poster`} className="h-32 w-[86px] shrink-0 rounded-xl border border-line object-cover sm:h-40 sm:w-[106px]" />
            <div className="min-w-0">
              <p className="text-sm text-muted">Step 1 of 3: choose a theatre and time</p>
              <h1 className="mt-1 font-display text-4xl font-extrabold leading-none sm:text-5xl">{movie.data.title}</h1>
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <Badge>{movie.data.certificate}</Badge>
                {movie.data.genres.map((g) => (
                  <Badge key={g}>{g}</Badge>
                ))}
                <span className="inline-flex items-center gap-1 text-sm text-white/75">
                  <Clock className="h-4 w-4 text-muted" />
                  {formatDuration(movie.data.durationMin)}
                </span>
                {movie.data.rating > 0 && (
                  <span className="inline-flex items-center gap-1 text-sm text-white/75">
                    <Star className="h-4 w-4 fill-gold text-gold" />
                    {movie.data.rating.toFixed(1)}
                  </span>
                )}
              </div>
            </div>
          </header>

          <ShowtimePicker
            movieId={movieId}
            initialDate={date}
            onDateChange={(d) => setParams({ movieId, date: d }, { replace: true })}
          />
        </>
      )}
    </div>
  );
}
