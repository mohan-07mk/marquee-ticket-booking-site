import { useMemo, useState } from 'react';
import { Eye, Search } from 'lucide-react';
import { AdminPageHeader, Toolbar } from '@/components/admin/AdminPageHeader';
import { DataTable, type Column } from '@/components/admin/DataTable';
import { StatusBadge } from '@/components/ui/Badge';
import { Button } from '@/components/ui/Button';
import { ConfirmDialog } from '@/components/ui/ConfirmDialog';
import { Input, Select } from '@/components/ui/Field';
import { Modal } from '@/components/ui/Modal';
import { ErrorState } from '@/components/ui/States';
import { useToast } from '@/context/ToastContext';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { api } from '@/services/api';
import type { Booking } from '@/types';
import { formatCurrency, formatDate, formatLongDate, formatTime } from '@/utils/format';

export default function BookingsAdmin() {
  useDocumentTitle('Manage bookings');
  const toast = useToast();
  const { data, loading, error, reload } = useAsync(() => api.bookings.listAll(), []);
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('all');
  const [viewing, setViewing] = useState<Booking | null>(null);
  const [confirmCancel, setConfirmCancel] = useState(false);
  const [busy, setBusy] = useState(false);

  const rows = useMemo(() => {
    const term = q.trim().toLowerCase();
    return (data ?? [])
      .filter((b) => !term || `${b.id} ${b.customerName} ${b.movieTitle} ${b.theatreName}`.toLowerCase().includes(term))
      .filter((b) => status === 'all' || b.status === status);
  }, [data, q, status]);

  const cancel = async () => {
    if (!viewing) return;
    setBusy(true);
    try {
      await api.bookings.setStatus(viewing.id, 'cancelled');
      toast.success('Booking cancelled', viewing.id);
      setConfirmCancel(false);
      setViewing(null);
      reload();
    } catch (e) {
      toast.error('Couldn’t cancel the booking', e instanceof Error ? e.message : undefined);
    } finally {
      setBusy(false);
    }
  };

  const columns: Column<Booking>[] = [
    { key: 'id', header: 'Booking ID', mobile: 'title', cell: (b) => <span className="font-semibold">{b.id}</span> },
    { key: 'customer', header: 'Customer', cell: (b) => b.customerName },
    { key: 'movie', header: 'Movie', cell: (b) => <span className="line-clamp-1">{b.movieTitle}</span> },
    { key: 'show', header: 'Show', cell: (b) => `${formatDate(b.date)}, ${formatTime(b.time)}` },
    { key: 'seats', header: 'Seats', cell: (b) => b.seats.join(', ') },
    { key: 'amount', header: 'Amount', cell: (b) => <span className="font-semibold">{formatCurrency(b.amount)}</span> },
    { key: 'status', header: 'Status', cell: (b) => <StatusBadge status={b.status} /> },
    {
      key: 'actions',
      header: 'Actions',
      mobile: 'actions',
      className: 'text-right',
      cell: (b) => (
        <Button variant="ghost" size="icon" aria-label={`View booking ${b.id}`} onClick={() => setViewing(b)}>
          <Eye className="h-4 w-4" />
        </Button>
      ),
    },
  ];

  return (
    <>
      <AdminPageHeader title="Booking management" description="Look up any booking by ID, customer, movie or theatre." />
      <Toolbar>
        <Input aria-label="Search bookings" placeholder="Search ID, customer, movie or theatre" icon={<Search className="h-4 w-4" />} value={q} onChange={(e) => setQ(e.target.value)} className="lg:w-96" />
        <Select aria-label="Status" value={status} onChange={(e) => setStatus(e.target.value)} className="lg:w-52">
          <option value="all">All statuses</option>
          <option value="confirmed">Confirmed</option>
          <option value="completed">Completed</option>
          <option value="cancelled">Cancelled</option>
        </Select>
      </Toolbar>

      {error ? <ErrorState message={error} onRetry={reload} /> : <DataTable columns={columns} rows={rows} rowKey={(b) => b.id} loading={loading && !data} pageSize={10} emptyTitle="No bookings found" />}

      <Modal
        open={!!viewing}
        onClose={() => setViewing(null)}
        title={viewing ? `Booking ${viewing.id}` : 'Booking'}
        footer={
          viewing?.status === 'confirmed' ? (
            <>
              <Button variant="ghost" onClick={() => setViewing(null)}>
                Close
              </Button>
              <Button variant="danger" onClick={() => setConfirmCancel(true)}>
                Cancel booking
              </Button>
            </>
          ) : (
            <Button variant="ghost" onClick={() => setViewing(null)}>
              Close
            </Button>
          )
        }
      >
        {viewing && (
          <div className="space-y-5">
            <div className="flex gap-4">
              <img src={viewing.posterUrl} alt="" className="h-28 w-[76px] rounded-xl border border-line object-cover" />
              <div>
                <h3 className="font-display text-2xl font-bold leading-tight">{viewing.movieTitle}</h3>
                <div className="mt-2">
                  <StatusBadge status={viewing.status} />
                </div>
              </div>
            </div>
            <dl className="grid gap-x-8 gap-y-3 text-sm sm:grid-cols-2">
              {[
                ['Customer', viewing.customerName],
                ['Theatre', `${viewing.theatreName}, ${viewing.screenName}`],
                ['Show date', formatLongDate(viewing.date)],
                ['Show time', `${formatTime(viewing.time)} (${viewing.format})`],
                ['Seats', viewing.seats.join(', ')],
                ['Payment', viewing.paymentMethod.toUpperCase()],
                ['Ticket price', formatCurrency(viewing.subtotal)],
                ['Convenience fee', formatCurrency(viewing.convenienceFee)],
                ['Total paid', formatCurrency(viewing.amount)],
                ['Booked on', formatDate(viewing.createdAt.slice(0, 10))],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between gap-4 border-b border-line/60 pb-2">
                  <dt className="text-muted">{k}</dt>
                  <dd className="text-right font-medium">{v}</dd>
                </div>
              ))}
            </dl>
          </div>
        )}
      </Modal>

      <ConfirmDialog
        open={confirmCancel}
        title="Cancel this booking?"
        description="The seats will be released and the booking marked as cancelled. The customer isn’t notified in this demo."
        confirmLabel="Cancel booking"
        loading={busy}
        onConfirm={cancel}
        onCancel={() => setConfirmCancel(false)}
      />
    </>
  );
}
