/**
 * Shared domain types.
 * These mirror the tables you will create in Supabase later
 * (movies, theatres, screens, shows, bookings, profiles) so swapping the
 * mock data for real queries needs minimal changes.
 */

export type Format = '2D' | '3D' | 'IMAX';
export type MovieStatus = 'now_showing' | 'coming_soon' | 'inactive';
export type ActiveStatus = 'active' | 'inactive';

export interface Movie {
  id: string;
  title: string;
  description: string;
  genres: string[];
  languages: string[];
  formats: Format[];
  durationMin: number;
  releaseDate: string; // YYYY-MM-DD
  rating: number; // 0 - 10
  certificate: string; // U, UA, A
  posterUrl: string;
  backdropUrl: string;
  trailerUrl: string;
  cast: string[];
  director: string;
  status: MovieStatus;
  popularity: number;
}

export interface Screen {
  id: string;
  theatreId: string;
  name: string;
  capacity: number;
  rows: number;
  seatsPerRow: number;
  formats: Format[];
  screenViewLink?: string;
}

export interface Theatre {
  id: string;
  name: string;
  location: string;
  amenities: string[];
  screens: Screen[];
  status: ActiveStatus;
  screenViewLink?: string;
}

export type ShowStatus = 'active' | 'cancelled';

export interface Show {
  id: string;
  movieId: string;
  theatreId: string;
  screenId: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm (24h)
  format: Format;
  language: string;
  price: number; // standard seat
  premiumPrice: number;
  status: ShowStatus;
  /** Filled in by the data layer, not stored on the show row. */
  seatsLeft?: number;
  capacity?: number;
}

export type SeatType = 'standard' | 'premium';
export type SeatStatus = 'available' | 'occupied';

export interface Seat {
  id: string; // actual seat UUID e.g. "1250936b-4b1f-43bf-8e57-94dcdca260c6"
  label?: string; // UI label e.g. "G7"
  row: string;
  number: number;
  type: SeatType;
  status: SeatStatus;
  price: number;
}

export type PaymentMethod = 'upi' | 'card' | 'netbanking';
export type BookingStatus = 'confirmed' | 'completed' | 'cancelled';

export interface Booking {
  id: string;
  userId: string;
  customerName: string;
  movieId: string;
  movieTitle: string;
  posterUrl: string;
  theatreId: string;
  theatreName: string;
  screenName: string;
  showId: string;
  date: string;
  time: string;
  format: Format;
  seats: string[];
  subtotal: number;
  convenienceFee: number;
  amount: number;
  status: BookingStatus;
  paymentMethod: PaymentMethod;
  razorpayOrderId?: string;
  razorpayPaymentId?: string;
  createdAt: string; // ISO
}

export type UserStatus = 'active' | 'blocked';

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: 'customer' | 'admin';
  status: UserStatus;
  joinedAt: string;
  totalBookings?: number;
}

/** A show together with everything needed to render a booking summary. */
export interface ShowDetails {
  show: Show;
  movie: Movie;
  theatre: Theatre;
  screen: Screen;
}

/** Chart / report shapes returned by the admin analytics calls. */
export interface DailyPoint {
  date: string;
  label: string;
  bookings: number;
  revenue: number;
}
export interface MonthlyPoint {
  month: string;
  bookings: number;
  revenue: number;
}
export interface RankedRevenue {
  id: string;
  name: string;
  bookings: number;
  revenue: number;
}
export interface DashboardData {
  totals: { movies: number; users: number; bookings: number; revenue: number };
  deltas: { bookings: number; revenue: number };
  daily: DailyPoint[];
  popularMovies: RankedRevenue[];
  recentBookings: Booking[];
}
export interface RevenueReport {
  total: number;
  today: number;
  thisMonth: number;
  avgPerBooking: number;
  daily: DailyPoint[];
  monthly: MonthlyPoint[];
  byMovie: RankedRevenue[];
  byTheatre: RankedRevenue[];
}
