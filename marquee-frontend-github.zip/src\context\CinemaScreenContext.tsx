import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from 'react';
import { parseYouTubeUrl, type YouTubeInfo } from '@/utils/youtube';

/**
 * FRONTEND DEMO ONLY.
 * Holds the cinema-screen video in React state so the admin editor and the 3D
 * auditorium share it while the app is open. It is NOT saved anywhere: a page
 * refresh returns to the default screen. Permanent storage is a backend task
 * (see "Cinema screen persistence" in README.md).
 */
interface CinemaScreenState {
  /** The saved URL exactly as the admin entered it ('' means default screen). */
  videoUrl: string;
  /** Parsed video, or null when the default screen is showing. */
  video: YouTubeInfo | null;
  /** Returns false (and changes nothing) if the URL is not a valid YouTube link. */
  saveVideoUrl: (url: string) => boolean;
  resetToDefault: () => void;
}

const CinemaScreenContext = createContext<CinemaScreenState | null>(null);

const STORAGE_KEY = 'marquee.cinema_screen_video';

export function CinemaScreenProvider({ children }: { children: ReactNode }) {
  const [videoUrl, setVideoUrl] = useState(() => {
    try {
      if (typeof window !== 'undefined') {
        return localStorage.getItem(STORAGE_KEY) || '';
      }
    } catch {}
    return '';
  });

  const saveVideoUrl = useCallback((url: string) => {
    const info = parseYouTubeUrl(url);
    if (!info && url.trim().length > 0) return false;
    const clean = url.trim();
    setVideoUrl(clean);
    try {
      if (typeof window !== 'undefined') {
        if (clean) localStorage.setItem(STORAGE_KEY, clean);
        else localStorage.removeItem(STORAGE_KEY);
      }
    } catch {}
    return true;
  }, []);

  const resetToDefault = useCallback(() => {
    setVideoUrl('');
    try {
      if (typeof window !== 'undefined') {
        localStorage.removeItem(STORAGE_KEY);
      }
    } catch {}
  }, []);

  const value = useMemo<CinemaScreenState>(
    () => ({ videoUrl, video: videoUrl ? parseYouTubeUrl(videoUrl) : null, saveVideoUrl, resetToDefault }),
    [videoUrl, saveVideoUrl, resetToDefault],
  );
  return <CinemaScreenContext.Provider value={value}>{children}</CinemaScreenContext.Provider>;
}

const defaultState: CinemaScreenState = {
  videoUrl: '',
  video: null,
  saveVideoUrl: () => false,
  resetToDefault: () => {},
};

export function useCinemaScreen() {
  const ctx = useContext(CinemaScreenContext);
  return ctx ?? defaultState;
}
