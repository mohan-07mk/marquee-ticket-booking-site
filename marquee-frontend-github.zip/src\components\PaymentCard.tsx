import type { ReactNode } from 'react';
import type { LucideIcon } from 'lucide-react';
import type { PaymentMethod } from '@/types';
import { cn } from '@/utils/cn';

interface PaymentCardProps {
  id: PaymentMethod;
  title: string;
  description: string;
  icon: LucideIcon;
  selected: boolean;
  onSelect: (id: PaymentMethod) => void;
  children?: ReactNode;
}

/** Selectable payment-method panel. The form for the method expands beneath its header when selected. */
export function PaymentCard({ id, title, description, icon: Icon, selected, onSelect, children }: PaymentCardProps) {
  return (
    <div
      className={cn(
        'overflow-hidden rounded-2xl border transition duration-200',
        selected ? 'border-brand bg-brand/[0.06]' : 'border-line bg-surface hover:border-white/30',
      )}
    >
      <button
        type="button"
        role="radio"
        aria-checked={selected}
        onClick={() => onSelect(id)}
        className="flex w-full items-center gap-4 p-4 text-left sm:p-5"
      >
        <span className={cn('grid h-11 w-11 shrink-0 place-items-center rounded-xl', selected ? 'bg-brand text-white' : 'bg-white/10 text-white/80')}>
          <Icon className="h-5 w-5" />
        </span>
        <span className="flex-1">
          <span className="block font-semibold">{title}</span>
          <span className="block text-sm text-muted">{description}</span>
        </span>
        <span className={cn('grid h-5 w-5 place-items-center rounded-full border-2', selected ? 'border-brand' : 'border-white/30')}>
          {selected && <span className="h-2.5 w-2.5 rounded-full bg-brand" />}
        </span>
      </button>
      {selected && children && <div className="animate-fade-in border-t border-line/70 p-4 sm:p-5">{children}</div>}
    </div>
  );
}
