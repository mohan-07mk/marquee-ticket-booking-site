import { Link, useParams, useSearchParams } from 'react-router-dom';
import { Download, Home, Ticket as TicketIcon } from 'lucide-react';
import { Ticket } from '@/components/Ticket';
import { Button, buttonClasses } from '@/components/ui/Button';
import { Skeleton } from '@/components/ui/Skeleton';
import { EmptyState, ErrorState } from '@/components/ui/States';
import { useAsync } from '@/hooks/useAsync';
import { useDocumentTitle } from '@/hooks/useDocumentTitle';
import { api } from '@/services/api';

export default function BookingSuccess() {
  useDocumentTitle('Booking confirmed');
  const routeParams = useParams<{ bookingId?: string }>();
  const [searchParams] = useSearchParams();
  const id = routeParams.bookingId || searchParams.get('id');
  const { data, loading, error, reload } = useAsync(() => (id ? api.bookings.get(id) : Promise.resolve(null)), [id]);

  if (!id) {
    return (
      <div className="container-page py-16">
        <EmptyState
          icon={TicketIcon}
          title="No booking to show"
          description="Open a ticket from My Bookings, or book a new show."
          action={
            <Link to="/my-bookings" className={buttonClasses()}>
              My bookings
            </Link>
          }
        />
      </div>
    );
  }
  if (error) {
    return (
      <div className="container-page py-16">
        <ErrorState message={error} onRetry={reload} />
      </div>
    );
  }
  if (loading || !data) {
    return (
      <div className="container-page max-w-4xl py-12">
        <Skeleton className="mx-auto mb-8 h-32 w-full max-w-md" />
        <Skeleton className="h-72 w-full" />
      </div>
    );
  }

  const cancelled = data.status === 'cancelled';

  return (
    <div className="container-page max-w-4xl py-10 sm:py-14">
      <div className="no-print mb-10 flex flex-col items-center text-center">
        {!cancelled && (
          <div className="relative mb-5 grid h-20 w-20 place-items-center">
            <span className="absolute inset-0 animate-ring-pulse rounded-full bg-emerald-500/30" />
            <span className="relative grid h-20 w-20 place-items-center rounded-full bg-emerald-500">
              <svg viewBox="0 0 24 24" className="h-10 w-10" fill="none" stroke="#fff" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="M5 12.5l4.5 4.5L19 7.5" strokeDasharray="30" strokeDashoffset="30" className="animate-draw-check" />
              </svg>
            </span>
          </div>
        )}
        <h1 className="font-display text-5xl font-extrabold leading-none sm:text-7xl">{cancelled ? 'Booking cancelled' : 'You’re all set'}</h1>
        <p className="mt-3 max-w-md text-muted">
          {cancelled
            ? 'This booking was cancelled, so the ticket below is no longer valid.'
            : 'Your booking is confirmed. Show the QR code at the entrance, and find this ticket any time in My Bookings.'}
        </p>
      </div>

      <Ticket booking={data} />

      <div className="no-print mt-8 flex flex-wrap items-center justify-center gap-3">
        <Button size="lg" leftIcon={<Download className="h-5 w-5" />} onClick={() => window.print()}>
          Download Ticket
        </Button>
        <Link to="/" className={buttonClasses({ variant: 'outline', size: 'lg' })}>
          <Home className="h-5 w-5" />
          Back to Home
        </Link>
        <Link to="/my-bookings" className={buttonClasses({ variant: 'ghost', size: 'lg' })}>
          My Bookings
        </Link>
      </div>
    </div>
  );
}
