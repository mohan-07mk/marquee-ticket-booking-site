import { memo, useEffect, useMemo, useRef } from 'react';
import { useFrame, type ThreeEvent } from '@react-three/fiber';
import gsap from 'gsap';
import { MathUtils, type Group, type Mesh, type MeshBasicMaterial } from 'three';
import type { Seat } from '@/types';
import { labelTexture } from './labelTexture';
import type { SeatPlacement } from './seatLayout';
import { getSeatGeometries, haloGeometry, type SeatMaterialMap, type SeatVisual } from './seatModels';

interface Props {
  placement: SeatPlacement;
  visual: SeatVisual;
  materials: SeatMaterialMap;
  reducedMotion: boolean;
  onHover: (seat: Seat | null) => void;
  onSelect: (seat: Seat) => void;
}

const interactive = (v: SeatVisual) => v === 'available' || v === 'selected';

/**
 * One clickable 3D seat. Hover lifts it and draws a soft halo; selecting pops
 * it with a springy GSAP tween and turns it brand red.
 */
function CinemaSeat3DImpl({ placement, visual, materials, reducedMotion, onHover, onSelect }: Props) {
  const { seat, x, y, z } = placement;
  const premium = seat.type === 'premium';
  const geo = useMemo(() => getSeatGeometries(premium), [premium]);
  const mats = materials[`${premium ? 'premium' : 'standard'}:${visual}`];

  const group = useRef<Group>(null);
  const halo = useRef<Mesh>(null);
  const hovered = useRef(false);
  const anim = useRef({ hover: 0, sel: visual === 'selected' ? 1 : 0 });
  const phase = useMemo(() => Math.random() * Math.PI * 2, []);

  // Selection pop.
  useEffect(() => {
    const target = visual === 'selected' ? 1 : 0;
    if (reducedMotion) {
      anim.current.sel = target;
      return;
    }
    const tween = gsap.to(anim.current, { sel: target, duration: target ? 0.6 : 0.25, ease: target ? 'back.out(2.6)' : 'power2.out' });
    return () => {
      tween.kill();
    };
  }, [visual, reducedMotion]);

  // Halo colour follows state.
  useEffect(() => {
    const m = halo.current?.material as MeshBasicMaterial | undefined;
    m?.color.set(visual === 'selected' ? '#e11d2e' : '#ffffff');
  }, [visual]);

  useFrame((state, delta) => {
    const g = group.current;
    if (!g) return;
    const a = anim.current;
    a.hover = MathUtils.damp(a.hover, hovered.current && interactive(visual) ? 1 : 0, 14, delta);
    g.position.y = y + a.hover * 0.035 + a.sel * 0.05;
    const s = 1 + a.sel * 0.035;
    g.scale.set(s, s, s);

    const h = halo.current;
    if (h) {
      const pulse = reducedMotion ? 0.7 : 0.62 + 0.2 * Math.sin(state.clock.elapsedTime * 3 + phase);
      const opacity = Math.max(a.hover * 0.38, a.sel * pulse);
      h.visible = opacity > 0.01;
      (h.material as MeshBasicMaterial).opacity = opacity;
    }
  });

  const handlers = {
    onPointerOver: (e: ThreeEvent<PointerEvent>) => {
      e.stopPropagation();
      hovered.current = true;
      onHover(seat);
    },
    onPointerOut: () => {
      hovered.current = false;
      onHover(null);
    },
    onClick: (e: ThreeEvent<MouseEvent>) => {
      e.stopPropagation();
      if (e.delta > 6) return; // it was a camera drag, not a tap
      onSelect(seat);
    },
  };

  const plateColor = visual === 'selected' ? '#ffffff' : visual === 'available' ? (premium ? '#f5b942' : '#e9ebf0') : '#6a6d75';
  const plateText = visual === 'booked' ? '×' : String(seat.number);
  const plate = useMemo(() => labelTexture(plateText, plateColor), [plateText, plateColor]);
  const [bx, by, bz] = geo.backPosition;

  return (
    <group position={[x, y, z]} ref={group} {...handlers}>
      <mesh geometry={geo.fabric} material={mats.fabric} castShadow receiveShadow />
      <mesh geometry={geo.trim} material={mats.trim} castShadow receiveShadow />

      {/* Seat number on both faces of the backrest so it reads from any side. */}
      <group position={[bx, by, bz]} rotation={[geo.backTilt, 0, 0]}>
        <mesh position={[0, geo.plateY, geo.backDepth + 0.004]}>
          <planeGeometry args={[0.17, 0.17]} />
          <meshBasicMaterial map={plate} transparent toneMapped={false} depthWrite={false} />
        </mesh>
        <mesh position={[0, geo.plateY, -geo.backDepth - 0.004]} rotation={[0, Math.PI, 0]}>
          <planeGeometry args={[0.17, 0.17]} />
          <meshBasicMaterial map={plate} transparent toneMapped={false} depthWrite={false} />
        </mesh>
      </group>

      <mesh ref={halo} geometry={haloGeometry} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.012, 0.02]} scale={[1.15, 1.35, 1]} visible={false} raycast={() => null}>
        <meshBasicMaterial transparent opacity={0} depthWrite={false} toneMapped={false} />
      </mesh>
    </group>
  );
}

export const CinemaSeat3D = memo(CinemaSeat3DImpl);
